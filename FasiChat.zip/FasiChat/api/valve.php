<?php
/**
 * API — Gestion du Valve (tableau d'affichage)
 * GET  : lister les annonces
 * POST : publier une annonce (Apparitaire uniquement)
 * PUT  : modifier une annonce (Apparitaire uniquement)
 * DELETE : supprimer une annonce (Apparitaire uniquement)
 */
require_once __DIR__ . '/../middlewares/auth_middleware.php';
require_once __DIR__ . '/../classes/Valve.php';
require_once __DIR__ . '/../classes/Apparitaire.php';

exigerAuthentification();

$methode = $_SERVER['REQUEST_METHOD'];
$userId  = Session::getId();
$role    = Session::getRole();
$valve   = new Valve();

// ---- GET : Lister annonces ----
if ($methode === 'GET') {
    $categorie = isset($_GET['categorie']) ? nettoyerEntree($_GET['categorie']) : null;
    $annonces  = $valve->getAnnonces($categorie);
    $compteurs = $valve->getCompteurs();

    // Incrémenter les vues si on consulte une annonce précise
    if (isset($_GET['id'])) {
        $valve->incrementerVues((int)$_GET['id']);
    }

    jsonResponse(['ok' => true, 'annonces' => $annonces, 'compteurs' => $compteurs]);
}

// ---- POST : Publier une annonce ----
if ($methode === 'POST') {
    exigerRole(['apparitaire']);

    $titre           = nettoyerEntree($_POST['titre'] ?? '');
    $contenu         = nettoyerEntree($_POST['contenu'] ?? '');
    $categorie       = nettoyerEntree($_POST['categorie'] ?? 'information');
    $dateExpiration  = nettoyerEntree($_POST['date_expiration'] ?? '') ?: null;

    if (empty($titre) || empty($contenu)) {
        jsonResponse(['ok' => false, 'erreur' => 'Le titre et le contenu sont obligatoires'], 400);
    }

    $fichierId = null;
    if (!empty($_FILES['fichier']['name'])) {
        require_once __DIR__ . '/../classes/Fichier.php';
        $fichier = Document::depuisUpload($_FILES['fichier'], $userId);
        if ($fichier) $fichierId = $fichier->getId();
    }

    $apparitaire = getUtilisateurCourant();
    $succes = $apparitaire->publierAnnonce($titre, $contenu, $categorie, $dateExpiration, $fichierId);

    if (!$succes) {
        jsonResponse(['ok' => false, 'erreur' => "Erreur lors de la publication"], 500);
    }
    jsonResponse(['ok' => true, 'message' => 'Annonce publiée sur le Valve.']);
}

// ---- PUT : Modifier une annonce ----
if ($methode === 'PUT') {
    exigerRole(['apparitaire']);
    parse_str(file_get_contents('php://input'), $data);

    $id             = (int)($data['id'] ?? 0);
    $titre          = nettoyerEntree($data['titre'] ?? '');
    $contenu        = nettoyerEntree($data['contenu'] ?? '');
    $categorie      = nettoyerEntree($data['categorie'] ?? 'information');
    $dateExpiration = nettoyerEntree($data['date_expiration'] ?? '') ?: null;

    if ($id <= 0 || empty($titre) || empty($contenu)) {
        jsonResponse(['ok' => false, 'erreur' => 'Données manquantes'], 400);
    }

    $apparitaire = getUtilisateurCourant();
    $succes = $apparitaire->modifierAnnonce($id, $titre, $contenu, $categorie, $dateExpiration);
    jsonResponse(['ok' => $succes]);
}

// ---- DELETE : Supprimer une annonce ----
if ($methode === 'DELETE') {
    exigerRole(['apparitaire']);
    parse_str(file_get_contents('php://input'), $data);

    $id = (int)($data['id'] ?? $_GET['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse(['ok' => false, 'erreur' => 'ID manquant'], 400);
    }

    $apparitaire = getUtilisateurCourant();
    $succes = $apparitaire->supprimerAnnonce($id);
    jsonResponse(['ok' => $succes]);
}

jsonResponse(['ok' => false, 'erreur' => 'Méthode non autorisée'], 405);
