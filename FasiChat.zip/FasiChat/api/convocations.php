<?php
/**
 * API — Gestion des convocations
 * GET : lister les convocations reçues / envoyées
 * POST : envoyer une convocation (Doyen ou ViceDoyen)
 */
require_once __DIR__ . '/../middlewares/auth_middleware.php';
require_once __DIR__ . '/../classes/AdminBase.php';
require_once __DIR__ . '/../classes/Doyen.php';
require_once __DIR__ . '/../classes/ViceDoyen.php';
require_once __DIR__ . '/../classes/Convocation.php';

exigerAuthentification();

$methode = $_SERVER['REQUEST_METHOD'];
$userId  = Session::getId();
$role    = Session::getRole();

// ---- GET ----
if ($methode === 'GET') {
    $sens = $_GET['sens'] ?? 'recues';

    if ($sens === 'recues') {
        if (!in_array($role, ['enseignant','assistant'], true)) {
            jsonResponse(['ok' => false, 'erreur' => 'Accès refusé'], 403);
        }
        $convocations = Convocation::getParDestinataire($userId);
        $nonLues      = Convocation::compterNonLues($userId);
        jsonResponse(['ok' => true, 'convocations' => $convocations, 'non_lues' => $nonLues]);
    }

    if ($sens === 'envoyees') {
        if (!in_array($role, ['doyen','vicedoyen'], true)) {
            jsonResponse(['ok' => false, 'erreur' => 'Accès refusé'], 403);
        }
        $utilisateur  = getUtilisateurCourant();
        $convocations = $utilisateur->getConvocationsEnvoyees();
        jsonResponse(['ok' => true, 'convocations' => $convocations]);
    }
}

// ---- POST : Envoyer une convocation ----
if ($methode === 'POST') {
    if (!in_array($role, ['doyen','vicedoyen'], true)) {
        jsonResponse(['ok' => false, 'erreur' => 'Seul le Doyen ou le Vice-Doyen peut convoquer'], 403);
    }

    $objet        = nettoyerEntree($_POST['objet'] ?? '');
    $dateReunion  = nettoyerEntree($_POST['date_reunion'] ?? '');
    $heureReunion = nettoyerEntree($_POST['heure_reunion'] ?? '');
    $lieu         = nettoyerEntree($_POST['lieu'] ?? '');
    $message      = nettoyerEntree($_POST['message'] ?? '');

    if (empty($objet) || empty($dateReunion) || empty($heureReunion) || empty($lieu)) {
        jsonResponse(['ok' => false, 'erreur' => 'Tous les champs obligatoires doivent être remplis'], 400);
    }

    // Valider la date
    $dt = DateTime::createFromFormat('Y-m-d', $dateReunion);
    if (!$dt) {
        jsonResponse(['ok' => false, 'erreur' => 'Format de date invalide (YYYY-MM-DD attendu)'], 400);
    }

    $utilisateur = getUtilisateurCourant();
    $succes      = $utilisateur->convoquer($objet, $dateReunion, $heureReunion, $lieu, $message);

    if (!$succes) {
        jsonResponse(['ok' => false, 'erreur' => "Erreur lors de l'envoi de la convocation"], 500);
    }

    // Compter les destinataires
    $db = BaseDeDonnees::getInstance();
    $nbDest = (int)$db->executer(
        'SELECT COUNT(*) FROM utilisateurs WHERE role IN ("enseignant","assistant") AND actif = 1'
    )->fetchColumn();

    jsonResponse(['ok' => true, 'nb_destinataires' => $nbDest,
        'message' => "Convocation envoyée à {$nbDest} destinataires."]);
}

// ---- PUT : Marquer comme lue ----
if ($methode === 'PUT') {
    parse_str(file_get_contents('php://input'), $data);
    $convocationId = (int)($data['convocation_id'] ?? 0);
    if ($convocationId > 0) {
        Convocation::marquerLue($convocationId, $userId);
        jsonResponse(['ok' => true]);
    }
    jsonResponse(['ok' => false, 'erreur' => 'ID manquant'], 400);
}

jsonResponse(['ok' => false, 'erreur' => 'Méthode non autorisée'], 405);
