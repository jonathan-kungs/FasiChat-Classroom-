<?php
/**
 * API — Gestion des utilisateurs
 * GET  : lister, chercher
 * POST : créer un utilisateur (Doyen uniquement)
 * PUT  : modifier un utilisateur
 * DELETE : désactiver un utilisateur (Doyen uniquement)
 */
require_once __DIR__ . '/../middlewares/auth_middleware.php';
require_once __DIR__ . '/../classes/Doyen.php';

exigerAuthentification();

$methode = $_SERVER['REQUEST_METHOD'];
$userId  = Session::getId();
$role    = Session::getRole();
$db      = BaseDeDonnees::getInstance();

// ---- GET ----
if ($methode === 'GET') {
    $roleFiltre = isset($_GET['role']) ? nettoyerEntree($_GET['role']) : null;
    $recherche  = isset($_GET['q']) ? nettoyerEntree($_GET['q']) : null;

    $sql    = 'SELECT u.id, u.matricule, u.nom, u.prenom, u.email, u.role, u.actif, u.en_ligne,
                      p.nom AS promotion_nom
               FROM utilisateurs u
               LEFT JOIN promotions p ON p.id = u.promotion_id
               WHERE u.actif = 1';
    $params = [];

    if ($roleFiltre) {
        $sql           .= ' AND u.role = :role';
        $params[':role'] = $roleFiltre;
    }
    if ($recherche) {
        $sql            .= ' AND (u.nom LIKE :q OR u.prenom LIKE :q OR u.matricule LIKE :q)';
        $params[':q']    = '%' . $recherche . '%';
    }
    $sql .= ' ORDER BY u.role, u.nom, u.prenom LIMIT 100';

    $utilisateurs = $db->executer($sql, $params)->fetchAll();
    jsonResponse(['ok' => true, 'utilisateurs' => $utilisateurs]);
}

// ---- POST : Créer un utilisateur ----
if ($methode === 'POST') {
    exigerRole(['doyen']);

    $matricule   = nettoyerEntree($_POST['matricule'] ?? '');
    $nom         = nettoyerEntree($_POST['nom'] ?? '');
    $prenom      = nettoyerEntree($_POST['prenom'] ?? '');
    $email       = nettoyerEntree($_POST['email'] ?? '');
    $motDePasse  = $_POST['mot_de_passe'] ?? '';
    $roleNouvel  = nettoyerEntree($_POST['role'] ?? '');
    $promotionId = !empty($_POST['promotion_id']) ? (int)$_POST['promotion_id'] : null;

    $rolesValides = ['etudiant','enseignant','assistant','doyen','vicedoyen','apparitaire'];
    if (empty($matricule) || empty($nom) || empty($prenom) || empty($motDePasse)
        || !in_array($roleNouvel, $rolesValides, true)) {
        jsonResponse(['ok' => false, 'erreur' => 'Données manquantes ou invalides'], 400);
    }

    if (strlen($motDePasse) < 6) {
        jsonResponse(['ok' => false, 'erreur' => 'Le mot de passe doit faire au moins 6 caractères'], 400);
    }

    $hash = Utilisateur::hacherMotDePasse($motDePasse);
    try {
        $db->executer(
            'INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, promotion_id)
             VALUES (:mat, :nom, :prenom, :email, :mdp, :role, :promo)',
            [':mat'=>$matricule,':nom'=>$nom,':prenom'=>$prenom,':email'=>$email ?: null,
             ':mdp'=>$hash,':role'=>$roleNouvel,':promo'=>$promotionId]
        );
        jsonResponse(['ok' => true, 'id' => (int)$db->dernierInsertId()]);
    } catch (PDOException $e) {
        jsonResponse(['ok' => false, 'erreur' => 'Matricule ou email déjà utilisé'], 409);
    }
}

// ---- DELETE : Désactiver ----
if ($methode === 'DELETE') {
    exigerRole(['doyen']);
    parse_str(file_get_contents('php://input'), $data);
    $cibleId = (int)($data['id'] ?? 0);
    if ($cibleId === $userId) {
        jsonResponse(['ok' => false, 'erreur' => 'Impossible de se désactiver soi-même'], 400);
    }
    $db->executer('UPDATE utilisateurs SET actif = 0 WHERE id = :id', [':id' => $cibleId]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['ok' => false, 'erreur' => 'Méthode non autorisée'], 405);
