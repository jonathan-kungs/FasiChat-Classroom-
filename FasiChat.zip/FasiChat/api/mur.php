<?php
/**
 * API — Mur pédagogique
 * GET  : lister les posts d'un cours
 * POST : publier sur le mur (enseignant/assistant)
 * DELETE : supprimer un post (auteur uniquement)
 */
require_once __DIR__ . '/../middlewares/auth_middleware.php';
require_once __DIR__ . '/../classes/Cours.php';

exigerAuthentification();

$methode = $_SERVER['REQUEST_METHOD'];
$userId  = Session::getId();
$role    = Session::getRole();
$db      = BaseDeDonnees::getInstance();

// ---- GET ----
if ($methode === 'GET') {
    $coursId = (int)($_GET['cours_id'] ?? 0);
    if ($coursId <= 0) jsonResponse(['ok' => false, 'erreur' => 'cours_id requis'], 400);

    $mur   = new MurPedagogique($coursId);
    $posts = $mur->getPosts();
    jsonResponse(['ok' => true, 'posts' => $posts]);
}

// ---- POST ----
if ($methode === 'POST') {
    if (!in_array($role, ['enseignant','assistant'], true)) {
        jsonResponse(['ok' => false, 'erreur' => 'Accès refusé — enseignants/assistants uniquement'], 403);
    }

    $coursId = (int)($_POST['cours_id'] ?? 0);
    $contenu = nettoyerEntree($_POST['contenu'] ?? '');

    if ($coursId <= 0 || empty($contenu)) {
        jsonResponse(['ok' => false, 'erreur' => 'cours_id et contenu requis'], 400);
    }

    $fichierId = null;
    if (!empty($_FILES['fichier']['name'])) {
        require_once __DIR__ . '/../classes/Fichier.php';
        $fichier = Document::depuisUpload($_FILES['fichier'], $userId);
        if ($fichier) $fichierId = $fichier->getId();
    }

    $db->executer(
        'INSERT INTO mur_pedagogique (auteur_id, cours_id, contenu, fichier_id) VALUES (:a,:c,:cont,:f)',
        [':a' => $userId, ':c' => $coursId, ':cont' => $contenu, ':f' => $fichierId]
    );
    jsonResponse(['ok' => true, 'id' => (int)$db->dernierInsertId()]);
}

// ---- DELETE ----
if ($methode === 'DELETE') {
    parse_str(file_get_contents('php://input'), $data);
    $postId = (int)($data['id'] ?? 0);
    if ($postId <= 0) jsonResponse(['ok' => false, 'erreur' => 'id requis'], 400);

    // Seul l'auteur peut supprimer
    $stmt = $db->executer('SELECT auteur_id FROM mur_pedagogique WHERE id = :id', [':id' => $postId]);
    $post = $stmt->fetch();
    if (!$post || (int)$post['auteur_id'] !== $userId) {
        jsonResponse(['ok' => false, 'erreur' => 'Non autorisé'], 403);
    }
    $db->executer('DELETE FROM mur_pedagogique WHERE id = :id', [':id' => $postId]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['ok' => false, 'erreur' => 'Méthode non autorisée'], 405);
