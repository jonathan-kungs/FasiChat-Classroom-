<?php
/**
 * API — Gestion des messages
 * Endpoints : GET (liste), POST (envoi)
 */
require_once __DIR__ . '/../middlewares/auth_middleware.php';
require_once __DIR__ . '/../classes/Message.php';
require_once __DIR__ . '/../classes/Fichier.php';

exigerAuthentification();

$methode    = $_SERVER['REQUEST_METHOD'];
$utilisateur = getUtilisateurCourant();
$userId      = Session::getId();
$role        = Session::getRole();
$db          = BaseDeDonnees::getInstance();

// ---- GET : Lister les messages ----
if ($methode === 'GET') {
    $type    = nettoyerEntree($_GET['type'] ?? '');
    $coursId = (int)($_GET['cours_id'] ?? 0);
    $destId  = (int)($_GET['dest_id'] ?? 0);

    if ($type === 'cours' && $coursId > 0) {
        $messages = $db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role AS user_role,
               f.nom_original AS fichier_nom, f.chemin AS fichier_chemin, f.taille_octets AS fichier_taille
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             LEFT JOIN fichiers f ON f.id = m.fichier_id
             WHERE m.cours_id = :cid AND m.type = "cours"
             ORDER BY m.created_at ASC',
            [':cid' => $coursId]
        )->fetchAll();
        jsonResponse(['ok' => true, 'messages' => $messages]);
    }

    if ($type === 'prive' && $destId > 0) {
        // Vérifier la règle : étudiants ↔ étudiants (même promo), enseignants ↔ enseignants
        $messages = $db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role AS user_role
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.type = "prive"
               AND ((m.expediteur_id = :moi AND m.destinataire_id = :lui)
                    OR (m.expediteur_id = :lui2 AND m.destinataire_id = :moi2))
             ORDER BY m.created_at ASC',
            [':moi' => $userId, ':lui' => $destId, ':lui2' => $destId, ':moi2' => $userId]
        )->fetchAll();
        // Marquer comme lus
        $db->executer(
            'UPDATE messages SET lu = 1 WHERE destinataire_id = :moi AND expediteur_id = :lui AND type = "prive" AND lu = 0',
            [':moi' => $userId, ':lui' => $destId]
        );
        jsonResponse(['ok' => true, 'messages' => $messages]);
    }

    if ($type === 'confidentiel' && $destId > 0) {
        // Uniquement Doyen ↔ Vice-Doyen
        if (!in_array($role, ['doyen', 'vicedoyen'], true)) {
            jsonResponse(['ok' => false, 'erreur' => 'Accès refusé'], 403);
        }
        $messages = $db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role AS user_role
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.type = "confidentiel"
               AND ((m.expediteur_id = :moi AND m.destinataire_id = :lui)
                    OR (m.expediteur_id = :lui2 AND m.destinataire_id = :moi2))
             ORDER BY m.created_at ASC',
            [':moi' => $userId, ':lui' => $destId, ':lui2' => $destId, ':moi2' => $userId]
        )->fetchAll();
        jsonResponse(['ok' => true, 'messages' => $messages]);
    }

    jsonResponse(['ok' => false, 'erreur' => 'Paramètres invalides'], 400);
}

// ---- POST : Envoyer un message ----
if ($methode === 'POST') {
    $type    = nettoyerEntree($_POST['type'] ?? '');
    $contenu = nettoyerEntree($_POST['contenu'] ?? '');
    $coursId = (int)($_POST['cours_id'] ?? 0);
    $destId  = (int)($_POST['dest_id'] ?? 0);

    // Gérer l'upload de fichier si présent
    $fichierId = null;
    if (!empty($_FILES['fichier']['name'])) {
        require_once __DIR__ . '/../config/config.php';
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['fichier']['tmp_name']);
        if (str_starts_with($mime, 'image/')) {
            $fichier = Image::depuisUpload($_FILES['fichier'], $userId);
        } elseif (str_starts_with($mime, 'video/')) {
            $fichier = Video::depuisUpload($_FILES['fichier'], $userId);
        } else {
            $fichier = Document::depuisUpload($_FILES['fichier'], $userId);
        }
        if ($fichier) $fichierId = $fichier->getId();
    }

    $msg = null;
    switch ($type) {
        case 'cours':
            if ($coursId <= 0) jsonResponse(['ok' => false, 'erreur' => 'cours_id manquant'], 400);
            // Vérifier l'appartenance au cours
            $stmt = $db->executer(
                'SELECT 1 FROM inscriptions_cours WHERE etudiant_id = :uid AND cours_id = :cid
                 UNION
                 SELECT 1 FROM cours WHERE id = :cid2 AND enseignant_id = :uid2',
                [':uid' => $userId, ':cid' => $coursId, ':cid2' => $coursId, ':uid2' => $userId]
            );
            if (!$stmt->fetch() && !in_array($role, ['doyen','vicedoyen','apparitaire'], true)) {
                // Permettre aussi les assistants
            }
            $msg = new MessagePublic(['expediteur_id' => $userId, 'contenu' => $contenu,
                'cours_id' => $coursId, 'fichier_id' => $fichierId]);
            break;

        case 'prive':
            if ($destId <= 0) jsonResponse(['ok' => false, 'erreur' => 'dest_id manquant'], 400);
            $msg = new MessagePrive(['expediteur_id' => $userId, 'contenu' => $contenu,
                'destinataire_id' => $destId, 'fichier_id' => $fichierId]);
            break;

        case 'confidentiel':
            if (!in_array($role, ['doyen', 'vicedoyen'], true)) {
                jsonResponse(['ok' => false, 'erreur' => 'Accès refusé'], 403);
            }
            if ($destId <= 0) jsonResponse(['ok' => false, 'erreur' => 'dest_id manquant'], 400);
            $msg = new MessageConfidentiel(['expediteur_id' => $userId, 'contenu' => $contenu,
                'destinataire_id' => $destId]);
            break;

        default:
            jsonResponse(['ok' => false, 'erreur' => 'Type de message invalide'], 400);
    }

    if (!$msg || !$msg->envoyer()) {
        jsonResponse(['ok' => false, 'erreur' => "Impossible d'envoyer le message"], 500);
    }

    jsonResponse(['ok' => true, 'message_id' => $msg->getId()]);
}

jsonResponse(['ok' => false, 'erreur' => 'Méthode non autorisée'], 405);
