============================================================
   FasiChat Classroom — Guide d'installation locale
   Travail pratique PHP OOP — Niveau L2 / Sciences Informatiques
============================================================

PRÉREQUIS
─────────
  • XAMPP ou WAMP ou MAMP installé
  • PHP >= 8.0 avec extensions : pdo_mysql, gd, fileinfo
  • MySQL 5.7+ ou MariaDB 10.4+

INSTALLATION RAPIDE (5 étapes)
───────────────────────────────

ÉTAPE 1 — Copier les fichiers
  Copiez le dossier FasiChat/ dans le répertoire racine de votre serveur :
    → XAMPP : C:\xampp\htdocs\FasiChat\
    → WAMP  : C:\wamp64\www\FasiChat\
    → MAMP  : /Applications/MAMP/htdocs/FasiChat/

ÉTAPE 2 — Créer la base de données
  Ouvrez phpMyAdmin (http://localhost/phpmyadmin)
  puis exécutez dans cet ordre :
    1. database/schema.sql   ← Crée la base et les tables
    2. database/seed.sql     ← Insère les données de test

  Ou via la ligne de commande :
    mysql -u root -p < database/schema.sql
    mysql -u root -p < database/seed.sql

ÉTAPE 3 — Configurer la connexion BDD
  Éditez le fichier config/config.php :
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'fasichat');
    define('DB_USER', 'root');
    define('DB_PASS', '');        ← Ajoutez votre mot de passe MySQL si nécessaire

ÉTAPE 4 — Permissions du dossier uploads
  Assurez-vous que le dossier uploads/ est accessible en écriture :
    Windows : Clic droit → Propriétés → Sécurité → Contrôle total
    Linux/Mac : chmod 775 uploads/

ÉTAPE 5 — Lancer l'application
  Démarrez Apache et MySQL dans XAMPP/WAMP, puis ouvrez :
    http://localhost/FasiChat/

============================================================
COMPTES DE TEST (mot de passe : password123)
============================================================

  Rôle          | Matricule    | Nom
  ──────────────┼─────────────────────────────────────────
  Doyen         | DOYEN001     | Pr. KUTANGILA Pierre
  Vice-Doyen    | VD001        | Pr. MANPUYA Jacques
  Apparitaire   | APP001       | Djo ROLLY
  Enseignant    | ENS001       | Prof. KABEYA Alphonse
  Enseignant    | ENS002       | Prof. MBUYAMBA Serge
  Enseignant    | ENS003       | Prof. ZUIYA Christian
  Assistant     | ASS001       | Amos BAHATI
  Assistant     | ASS002       | Jean NGALULA
  Étudiant      | ET2024001    | Samiel BANZOLELE
  Étudiant      | ET2024002    | Ezechiel ITEWE
  Étudiant      | ET2024003    | Beloved MAZUA
  ... (10 étudiants au total)

============================================================
STRUCTURE DU PROJET
============================================================

  FasiChat/
  ├── index.php                     ← Point d'entrée (redirection auto)
  ├── login.php                     ← Page de connexion
  ├── logout.php                    ← Déconnexion
  ├── dashboard_etudiant.php        ← Dashboard étudiant
  ├── dashboard_enseignant.php      ← Dashboard enseignant/assistant
  ├── dashboard_admin.php           ← Dashboard Doyen
  ├── dashboard_vicedoyen.php       ← Dashboard Vice-Doyen
  ├── dashboard_apparitaire.php     ← Dashboard Apparitaire
  ├── valve.php                     ← Tableau d'affichage officiel
  │
  ├── classes/                      ← Hiérarchie des classes PHP OOP
  │   ├── BaseDeDonnees.php         ← Singleton PDO
  │   ├── Session.php               ← Gestion sessions sécurisées
  │   ├── Utilisateur.php           ← Classe abstraite (base)
  │   ├── Etudiant.php              ← extends Utilisateur
  │   ├── Enseignant.php            ← extends Utilisateur
  │   ├── Assistant.php             ← extends Enseignant
  │   ├── AdminBase.php             ← Classe abstraite + interface Convocable
  │   ├── Doyen.php                 ← extends AdminBase
  │   ├── ViceDoyen.php             ← extends AdminBase
  │   ├── Apparitaire.php           ← extends Utilisateur
  │   ├── Message.php               ← Classe abstraite + MessagePrive/Public/Confidentiel
  │   ├── Convocation.php           ← Gestion des convocations de réunion
  │   ├── Fichier.php               ← Classe abstraite + Image/Video/Document (GD)
  │   ├── Valve.php                 ← Tableau d'affichage + AnnonceValve
  │   └── Cours.php                 ← Cours, Promotion, MurPedagogique
  │
  ├── api/                          ← Endpoints AJAX (répondent en JSON)
  │   ├── messages.php              ← CRUD messages (privé/cours/confidentiel)
  │   ├── convocations.php          ← CRUD convocations
  │   ├── valve.php                 ← CRUD annonces Valve
  │   ├── mur.php                   ← CRUD mur pédagogique
  │   └── users.php                 ← CRUD utilisateurs (Doyen)
  │
  ├── config/
  │   └── config.php                ← Paramètres de connexion BDD
  │
  ├── database/
  │   ├── schema.sql                ← Schéma complet (tables, clés)
  │   └── seed.sql                  ← Données de démonstration
  │
  ├── helpers/
  │   └── functions.php             ← Fonctions utilitaires + autoloader
  │
  ├── middlewares/
  │   └── auth_middleware.php       ← Contrôle d'accès par rôle
  │
  ├── uploads/                      ← Dossier des fichiers téléversés
  │
  └── assets/
      ├── *.css                     ← Feuilles de style des dashboards
      ├── fonts/
      │   └── fonts.css             ← Polices système (mode hors-ligne)
      └── js/
          └── *.js                  ← Scripts JavaScript

============================================================
CONCEPTS OOP ILLUSTRÉS (conformes au cahier des charges)
============================================================

  ✓ Classes abstraites  : Utilisateur, Message, Fichier, AdminBase
  ✓ Interfaces          : Convocable (implémentée par Doyen et ViceDoyen)
  ✓ Héritage            : Etudiant/Enseignant/Assistant/Doyen/ViceDoyen/Apparitaire
  ✓ Polymorphisme       : getDashboard() retourne un résultat différent par classe
  ✓ Encapsulation       : Propriétés protected/private + accesseurs
  ✓ Singleton (patron)  : BaseDeDonnees::getInstance()
  ✓ PDO + requêtes prep : Toutes les requêtes utilisent des placeholders (:param)
  ✓ Sessions sécurisées : Régénération ID, protection CSRF, HttpOnly cookies
  ✓ GD (compression)    : Image::traiter() comprime les images JPEG/PNG
  ✓ Rôles différenciés  : 6 rôles avec droits distincts
  ✓ Messages typés       : Privé, Public (cours), Confidentiel (Doyen↔ViceDoyen)
  ✓ Convocations         : Doyen et ViceDoyen → tous enseignants/assistants
  ✓ Valve               : Publication exclusive Apparitaire, lecture tous rôles
  ✓ Upload fichiers      : Image, Vidéo, Document avec validation MIME

============================================================
DÉPANNAGE
============================================================

  Erreur "Impossible de se connecter à MySQL" :
  → Vérifiez que MySQL est démarré dans XAMPP/WAMP
  → Vérifiez DB_USER et DB_PASS dans config/config.php

  Page blanche / erreur 500 :
  → Activez display_errors dans PHP ou lisez les logs Apache
  → Vérifiez que les fichiers SQL ont bien été exécutés

  Dossier uploads/ non accessible :
  → Vérifiez les permissions (écriture nécessaire)

  Fontes affichées différemment :
  → Normal : les polices système (Segoe UI, Helvetica) remplacent Google Fonts
    pour permettre l'utilisation sans internet. L'aspect visuel reste similaire.

============================================================
