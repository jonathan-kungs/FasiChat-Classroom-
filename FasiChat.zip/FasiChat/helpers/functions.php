<?php
/**
 * Fonctions utilitaires globales pour FasiChat Classroom
 */

/**
 * Échapper les sorties HTML (prévention XSS)
 */
function esc(string $valeur): string
{
    return htmlspecialchars($valeur, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * Formater une date MySQL en français
 */
function formatDate(string $date, string $format = 'd/m/Y à H:i'): string
{
    if (empty($date)) return '';
    try {
        $dt = new DateTime($date);
        return $dt->format($format);
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * Afficher une date relative (Aujourd'hui, Hier, ou date)
 */
function dateRelative(string $date): string
{
    if (empty($date)) return '';
    try {
        $dt   = new DateTime($date);
        $now  = new DateTime();
        $diff = $now->diff($dt);

        if ($diff->days === 0) {
            return $dt->format('H:i');
        } elseif ($diff->days === 1) {
            return 'Hier';
        } elseif ($diff->days < 7) {
            $jours = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
            return $jours[(int)$dt->format('w')] . ' ' . $dt->format('H:i');
        } else {
            return $dt->format('d/m/Y');
        }
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * Formater la taille d'un fichier en lecture humaine
 */
function formatTaille(int $octets): string
{
    if ($octets < 1024)       return $octets . ' o';
    if ($octets < 1048576)    return round($octets / 1024, 1) . ' Ko';
    if ($octets < 1073741824) return round($octets / 1048576, 1) . ' Mo';
    return round($octets / 1073741824, 1) . ' Go';
}

/**
 * Obtenir les initiales depuis nom/prénom
 */
function getInitiales(string $prenom, string $nom): string
{
    return mb_strtoupper(mb_substr($prenom, 0, 1) . mb_substr($nom, 0, 1));
}

/**
 * Obtenir la couleur de gradient CSS pour un rôle
 */
function getCouleurRole(string $role): string
{
    return match($role) {
        'doyen'      => 'linear-gradient(135deg,#dc2626,#991b1b)',
        'vicedoyen'  => 'linear-gradient(135deg,#7c3aed,#5b21b6)',
        'apparitaire'=> 'linear-gradient(135deg,#6366f1,#4f46e5)',
        'enseignant' => 'linear-gradient(135deg,#f59e0b,#d97706)',
        'assistant'  => 'linear-gradient(135deg,#14b8a6,#0d9488)',
        'etudiant'   => 'linear-gradient(135deg,#0ea5e9,#0284c7)',
        default      => 'linear-gradient(135deg,#6b7280,#4b5563)',
    };
}

/**
 * Obtenir le label affiché d'un rôle
 */
function getLabelRole(string $role): string
{
    return match($role) {
        'doyen'      => 'Doyen',
        'vicedoyen'  => 'Vice-Doyen',
        'apparitaire'=> 'Apparitaire',
        'enseignant' => 'Enseignant',
        'assistant'  => 'Assistant',
        'etudiant'   => 'Étudiant',
        default      => $role,
    };
}

/**
 * Obtenir l'icône d'un rôle
 */
function getIconeRole(string $role): string
{
    return match($role) {
        'doyen'      => '🏛',
        'vicedoyen'  => '🏅',
        'apparitaire'=> '🗂',
        'enseignant' => '👨‍🏫',
        'assistant'  => '📋',
        'etudiant'   => '🎓',
        default      => '👤',
    };
}

/**
 * Retourner une réponse JSON et terminer le script
 */
function jsonResponse(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Valider et nettoyer une entrée utilisateur
 */
function nettoyerEntree(string $valeur): string
{
    return trim(strip_tags($valeur));
}

/**
 * Vérifier si une requête est en POST
 */
function estPost(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Vérifier si une requête AJAX
 */
function estAjax(): bool
{
    return isset($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Obtenir un token CSRF (protection CSRF basique)
 */
function getCsrfToken(): string
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Vérifier un token CSRF
 */
function verifierCsrf(string $token): bool
{
    return isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Autoloader des classes FasiChat
 */
spl_autoload_register(function (string $classe): void {
    $fichier = __DIR__ . '/../classes/' . $classe . '.php';
    if (file_exists($fichier)) {
        require_once $fichier;
    }
});
