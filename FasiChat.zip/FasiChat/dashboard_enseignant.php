<?php
/**
 * Dashboard Enseignant / Assistant — FasiChat Classroom
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/Enseignant.php';
require_once __DIR__ . '/classes/Assistant.php';
require_once __DIR__ . '/classes/Convocation.php';

exigerAuthentification();
exigerRole(['enseignant', 'assistant']);

$utilisateur = getUtilisateurCourant();
$mesCours    = $utilisateur->getMesCours();
$premierCours = $mesCours[0] ?? null;
$convocations = $utilisateur->getConvocationsRecues();
$nbConvNonLues = Convocation::compterNonLues($utilisateur->getId());

// Collègues (enseignants/assistants)
$db = BaseDeDonnees::getInstance();
$collegues = $db->executer(
    'SELECT id, nom, prenom, role, en_ligne FROM utilisateurs
     WHERE role IN ("enseignant","assistant") AND id != :id AND actif = 1 ORDER BY nom',
    [':id' => $utilisateur->getId()]
)->fetchAll();

// Étudiants du premier cours
$etudiantsCours = [];
if ($premierCours) {
    $etudiantsCours = $utilisateur->getEtudiantsCours((int)$premierCours['id']);
}

// Posts du mur pédagogique
$murPosts = [];
if ($premierCours) {
    $murPosts = $utilisateur->getMurPedagogique((int)$premierCours['id']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FasiChat — Dashboard Enseignant</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/dashboard_enseignant.css">
<style>
.msg-system{text-align:center;color:#94a3b8;font-size:12px;margin:20px 0;font-style:italic;}
.convoc-card-header{display:flex;align-items:center;gap:10px;margin-bottom:8px;}
.convoc-unread-badge{background:#dc2626;color:white;border-radius:50%;width:18px;height:18px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;}
</style>
</head>
<body>

<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">💬</div>
    <div class="brand-info"><h3>FasiChat</h3><span>Espace <?= ucfirst($utilisateur->getRole()) ?></span></div>
  </div>
  <div class="nav-tabs">
    <button class="nav-tab active" onclick="showView('students',this)">👥 Étudiants</button>
    <button class="nav-tab" onclick="showView('mur',this)">📋 Mur</button>
    <button class="nav-tab" onclick="showView('msgs',this)">💬 Messages</button>
    <button class="nav-tab" onclick="location.href='valve.php'">📣 Valve</button>
  </div>
  <div class="sidebar-search">
    <div class="search-wrap">
      <span class="search-icon">🔍</span>
      <input type="text" class="search-input" placeholder="Rechercher..." oninput="filtrerListe(this.value)">
    </div>
  </div>
  <div class="conv-list">
    <?php if (!empty($mesCours)): ?>
    <div class="section-label">Mes Cours</div>
    <?php foreach ($mesCours as $cours): ?>
    <div class="conv-item <?= $cours === $premierCours ? 'active' : '' ?>"
         onclick="selectionnerCours(this, <?= $cours['id'] ?>, '<?= esc($cours['nom']) ?>')">
      <div class="avatar" style="background:<?= getCouleurRole('enseignant') ?>">📚</div>
      <div class="conv-info">
        <div class="conv-name"><?= esc($cours['nom']) ?></div>
        <div class="conv-preview"><?= $cours['nb_etudiants'] ?> étudiants</div>
      </div>
      <div class="conv-meta"><div class="conv-time">Actif</div></div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($collegues)): ?>
    <div class="section-label">Collègues (Privé)</div>
    <?php foreach ($collegues as $col): ?>
    <div class="conv-item"
         onclick="chargerPriveEns(this, <?= $col['id'] ?>, '<?= esc($col['prenom'].' '.$col['nom']) ?>')">
      <div class="avatar" style="background:<?= getCouleurRole($col['role']) ?>;font-size:12px;font-weight:700;">
        <?= getInitiales($col['prenom'], $col['nom']) ?>
      </div>
      <div class="conv-info">
        <div class="conv-name"><?= esc(getLabelRole($col['role']).' '.$col['nom']) ?></div>
        <div class="conv-preview"><?= $col['en_ligne'] ? 'En ligne' : 'Hors ligne' ?></div>
      </div>
      <div class="conv-meta">
        <?php if ($col['en_ligne']): ?><div class="conv-time" style="color:#22c55e">●</div><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($convocations)): ?>
    <div class="section-label">
      Convocations reçues
      <?php if ($nbConvNonLues > 0): ?>
      <span style="background:#dc2626;color:white;border-radius:10px;padding:1px 6px;font-size:9px;margin-left:4px;"><?= $nbConvNonLues ?></span>
      <?php endif; ?>
    </div>
    <?php foreach ($convocations as $conv): ?>
    <div class="conv-item" onclick="afficherConvocation(<?= $conv['id'] ?>)">
      <div class="avatar" style="background:linear-gradient(135deg,#dc2626,#991b1b)">🏛</div>
      <div class="conv-info">
        <div class="conv-name"><?= esc($conv['exp_prenom'].' '.$conv['exp_nom']) ?> — Réunion</div>
        <div class="conv-preview"><?= esc(mb_substr($conv['objet'],0,40)) ?></div>
      </div>
      <div class="conv-meta">
        <?php if (!$conv['lu']): ?><div class="conv-badge-warn">!</div><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="sidebar-profile">
    <div class="profile-avatar"><div class="online-dot"></div>👨‍🏫</div>
    <div class="profile-info">
      <h4><?= esc($utilisateur->getPrenom().' '.$utilisateur->getNom()) ?></h4>
      <span><?= getLabelRole($utilisateur->getRole()) ?></span>
    </div>
    <div class="profile-actions"><a href="logout.php" class="icon-btn">🚪</a></div>
  </div>
</div>

<!-- MAIN AREA -->
<div class="main-area">
  <div class="chat-topbar">
    <div class="chat-topbar-avatar" id="topbarAvatar" style="background:<?= getCouleurRole('enseignant') ?>">📚</div>
    <div class="chat-topbar-info">
      <h3 id="topbarTitle"><?= $premierCours ? esc($premierCours['nom']) : 'Sélectionnez un cours' ?></h3>
      <p id="topbarSub"><?= $premierCours ? $premierCours['nb_etudiants'].' étudiants' : '' ?></p>
    </div>
    <div class="status-badge public"><div class="status-dot"></div>Cours Public</div>
    <div class="topbar-actions">
      <button class="topbar-btn" onclick="showView('students',null)">👥 Étudiants</button>
      <button class="topbar-btn" onclick="showView('mur',null)">📋 Mur péda.</button>
      <button class="topbar-btn primary" onclick="showView('msgs',null)">💬 Messagerie</button>
    </div>
  </div>

  <!-- VUE ÉTUDIANTS -->
  <div class="students-panel visible" id="view-students">
    <div class="panel-header">
      <div><h2>Liste des étudiants</h2>
        <p><?= $premierCours ? esc($premierCours['nom']).' · '.$premierCours['nb_etudiants'].' inscrits' : '' ?></p>
      </div>
    </div>
    <div class="search-students">
      <div class="search-field">
        <span class="s-icon">🔍</span>
        <input type="text" id="searchEtu" placeholder="Rechercher un étudiant..." oninput="filtrerEtudiants(this.value)">
      </div>
      <button class="filter-btn active" onclick="filtreStatus('tous',this)">Tous</button>
      <button class="filter-btn" onclick="filtreStatus('online',this)">En ligne</button>
      <button class="filter-btn" onclick="filtreStatus('offline',this)">Hors ligne</button>
    </div>
    <div class="students-grid" id="grille-etudiants">
      <?php foreach ($etudiantsCours as $etu): ?>
      <div class="student-card" data-online="<?= $etu['en_ligne'] ?>">
        <div class="sc-header">
          <div class="sc-avatar" style="background:<?= getCouleurRole('etudiant') ?>">
            <?= getInitiales($etu['prenom'], $etu['nom']) ?>
          </div>
          <div>
            <div class="sc-name"><?= esc(strtoupper($etu['nom']).' '.$etu['prenom']) ?></div>
            <div class="sc-matric"><?= esc($etu['matricule']) ?></div>
          </div>
        </div>
        <div class="sc-stats">
          <span class="sc-tag <?= $etu['en_ligne'] ? 'tag-online' : 'tag-offline' ?>">
            <?= $etu['en_ligne'] ? '● En ligne' : '○ Hors ligne' ?>
          </span>
          <span class="sc-tag tag-blue"><?= esc($etu['promotion_nom'] ?? 'L2') ?></span>
        </div>
        <div class="sc-actions">
          <button class="sc-btn msg" onclick="chargerPriveEns(null,<?= $etu['id'] ?>,'<?= esc($etu['prenom'].' '.$etu['nom']) ?>')">💬 Message</button>
          <button class="sc-btn view">👁 Profil</button>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($etudiantsCours)): ?>
      <p style="color:#94a3b8;font-style:italic;grid-column:1/-1;">Aucun étudiant inscrit à ce cours.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- VUE MUR PÉDAGOGIQUE -->
  <div class="mur-panel" id="view-mur">
    <div class="mur-compose">
      <h3>📋 Publier sur le mur — <?= $premierCours ? esc($premierCours['nom']) : '' ?></h3>
      <textarea class="mur-textarea" id="murContenu" placeholder="Rédigez une question, un rappel ou une annonce pour vos étudiants..."></textarea>
      <div class="mur-footer">
        <div class="mur-attach">
          <button class="attach-btn" onclick="document.getElementById('murFichier').click()">📎 Fichier</button>
        </div>
        <button class="publish-btn" onclick="publierMur()">Publier →</button>
      </div>
      <input type="file" id="murFichier" hidden>
    </div>
    <div id="mur-posts">
      <?php foreach ($murPosts as $post): ?>
      <div class="mur-post">
        <div class="post-header">
          <div class="post-avatar" style="background:<?= getCouleurRole($post['role']) ?>">
            <?= getInitiales($post['prenom'], $post['nom']) ?>
          </div>
          <div>
            <div class="post-author"><?= getLabelRole($post['role']).' '.$post['nom'] ?></div>
            <div class="post-meta"><?= dateRelative($post['created_at']) ?></div>
          </div>
          <?php if ((int)$post['auteur_id'] === $utilisateur->getId()): ?>
          <div class="post-actions">
            <button class="post-action-btn" onclick="supprimerPost(<?= $post['id'] ?>,this)">🗑</button>
          </div>
          <?php endif; ?>
        </div>
        <div class="post-content"><?= nl2br(esc($post['contenu'])) ?></div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($murPosts)): ?>
      <div class="msg-system">Aucune publication sur ce mur. Publiez la première !</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- VUE MESSAGERIE -->
  <div class="chat-messages" id="view-msgs">
    <div class="msg-system">Sélectionnez une conversation.</div>
  </div>

  <!-- Input -->
  <div class="chat-input-area" id="input-area" style="display:none;">
    <div class="input-toolbar">
      <button class="toolbar-btn" onclick="document.getElementById('fileInputEns').click()">📎 Fichier</button>
    </div>
    <div class="input-row">
      <div class="msg-textarea-wrap">
        <textarea class="msg-textarea" id="msgInput" rows="1"
                  placeholder="Répondre..." onkeydown="handleKey(event)"></textarea>
        <button class="emoji-btn">😊</button>
      </div>
      <button class="send-btn" onclick="sendMsg()">➤</button>
    </div>
    <input type="file" id="fileInputEns" hidden onchange="uploadFichier(this)">
  </div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
  <div class="panel-section">
    <div class="panel-title">Statistiques</div>
    <div class="info-card">
      <h4><?= $premierCours ? esc($premierCours['nom']) : 'Mes cours' ?></h4>
      <div class="stat-row">
        <div class="stat-box"><div class="num"><?= count($etudiantsCours) ?></div><div class="lbl">Étudiants</div></div>
        <div class="stat-box"><div class="num"><?= count($mesCours) ?></div><div class="lbl">Cours</div></div>
        <div class="stat-box"><div class="num"><?= count($convocations) ?></div><div class="lbl">Convocations</div></div>
      </div>
    </div>
  </div>
  <?php if (!empty($convocations)): ?>
  <div class="panel-section">
    <div class="panel-title">Convocations reçues</div>
    <?php foreach (array_slice($convocations, 0, 3) as $conv): ?>
    <div class="convoc-card">
      <h4>🏛 <?= esc($conv['objet']) ?></h4>
      <p>Convoqué par <?= esc($conv['exp_prenom'].' '.$conv['exp_nom']) ?></p>
      <div class="convoc-date">
        📅 <?= date('d/m/Y', strtotime($conv['date_reunion'])) ?>
        · <?= date('H:i', strtotime($conv['heure_reunion'])) ?>
        · <?= esc($conv['lieu']) ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="panel-section">
    <div class="panel-title">Mes cours</div>
    <?php foreach ($mesCours as $cours): ?>
    <div class="info-card">
      <h4><?= esc($cours['nom']) ?></h4>
      <p><?= esc($cours['promo_nom'] ?? '') ?> · <?= $cours['nb_etudiants'] ?> étudiants</p>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
const MON_ID = <?= $utilisateur->getId() ?>;
let typeConv = 'cours';
let coursActifId = <?= $premierCours ? $premierCours['id'] : 'null' ?>;
let destActifId = null;

function showView(view, btn) {
  ['view-students','view-mur','view-msgs'].forEach(id => {
    const el = document.getElementById(id);
    el.classList.remove('visible');
    el.style.display = 'none';
  });
  document.getElementById('input-area').style.display = 'none';
  const el = document.getElementById('view-' + view);
  el.style.display = '';
  if (view === 'students' || view === 'mur') el.classList.add('visible');
  if (view === 'msgs') {
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    document.getElementById('input-area').style.display = 'block';
  }
  if (btn) { document.querySelectorAll('.nav-tab').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); }
}

function selectionnerCours(item, coursId, nom) {
  document.querySelectorAll('.conv-item').forEach(i=>i.classList.remove('active'));
  item.classList.add('active');
  coursActifId = coursId; destActifId = null; typeConv = 'cours';
  document.getElementById('topbarTitle').textContent = nom;
  chargerMsgs();
}

function chargerPriveEns(item, destId, nom) {
  if (item) { document.querySelectorAll('.conv-item').forEach(i=>i.classList.remove('active')); item.classList.add('active'); }
  destActifId = destId; coursActifId = null; typeConv = 'prive';
  document.getElementById('topbarTitle').textContent = nom;
  showView('msgs', null);
  chargerMsgs();
}

function chargerMsgs() {
  let url = 'api/messages.php?type=' + typeConv;
  if (coursActifId) url += '&cours_id=' + coursActifId;
  if (destActifId) url += '&dest_id=' + destActifId;
  fetch(url).then(r=>r.json()).then(data => {
    const box = document.getElementById('view-msgs');
    box.innerHTML = '';
    if (!data.ok || !data.messages.length) {
      box.innerHTML = '<div class="msg-system">Aucun message.</div>';
      return;
    }
    data.messages.forEach(msg => {
      const estMoi = parseInt(msg.expediteur_id) === MON_ID;
      const init = ((msg.prenom||'')[0]+(msg.nom||'')[0]).toUpperCase();
      const heure = new Date(msg.created_at).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
      const div = document.createElement('div');
      div.className = 'msg-row' + (estMoi?' mine':'');
      div.innerHTML = `<div class="msg-avatar" style="background:var(--sky)">${init}</div>
        <div class="msg-group">
          ${!estMoi?`<div class="msg-sender">${msg.prenom} ${msg.nom} · ${heure}</div>`:''}
          <div class="bubble ${estMoi?'mine':'theirs'}">${esc(msg.contenu||'')}</div>
          <div class="msg-meta">${heure}${estMoi?' ✓✓':''}</div>
        </div>`;
      box.appendChild(div);
    });
    box.scrollTop = box.scrollHeight;
  });
}

function sendMsg() {
  const ta = document.getElementById('msgInput');
  const text = ta.value.trim(); if (!text) return;
  const fd = new FormData();
  fd.append('type', typeConv); fd.append('contenu', text);
  if (coursActifId) fd.append('cours_id', coursActifId);
  if (destActifId) fd.append('dest_id', destActifId);
  fetch('api/messages.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if (data.ok){ta.value=''; chargerMsgs();} else alert(data.erreur);
  });
}

function uploadFichier(input) {
  if (!input.files[0]) return;
  const fd = new FormData();
  fd.append('fichier',input.files[0]); fd.append('type',typeConv);
  fd.append('contenu','[Fichier : '+input.files[0].name+']');
  if (coursActifId) fd.append('cours_id', coursActifId);
  if (destActifId) fd.append('dest_id', destActifId);
  fetch('api/messages.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if (data.ok) chargerMsgs(); else alert(data.erreur||'Erreur upload');
  });
  input.value='';
}

function publierMur() {
  const contenu = document.getElementById('murContenu').value.trim();
  if (!contenu || !coursActifId) { alert('Saisissez un contenu et sélectionnez un cours.'); return; }
  const fd = new FormData();
  fd.append('cours_id', coursActifId); fd.append('contenu', contenu);
  fetch('api/mur.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if (data.ok){ document.getElementById('murContenu').value=''; location.reload(); }
    else alert(data.erreur);
  });
}

function supprimerPost(id, btn) {
  if (!confirm('Supprimer cette publication ?')) return;
  fetch('api/mur.php',{method:'DELETE',body:'id='+id,headers:{'Content-Type':'application/x-www-form-urlencoded'}})
    .then(r=>r.json()).then(data=>{ if(data.ok) btn.closest('.mur-post').remove(); });
}

function afficherConvocation(id) {
  fetch('api/convocations.php?sens=recues').then(r=>r.json()).then(data=>{
    const conv = data.convocations?.find(c=>c.id==id);
    if (conv) {
      alert('📅 CONVOCATION\n\nObjet : '+conv.objet+'\nDate : '+conv.date_reunion+'\nHeure : '+conv.heure_reunion+'\nLieu : '+conv.lieu+(conv.message?'\n\n'+conv.message:''));
    }
  });
}

function filtrerEtudiants(q) {
  document.querySelectorAll('.student-card').forEach(c=>{
    const nom = c.querySelector('.sc-name')?.textContent.toLowerCase()||'';
    c.style.display = nom.includes(q.toLowerCase())?'':'none';
  });
}

function filtreStatus(status, btn) {
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.student-card').forEach(c=>{
    if (status==='tous') c.style.display='';
    else if (status==='online') c.style.display=c.dataset.online==='1'?'':'none';
    else c.style.display=c.dataset.online==='0'?'':'none';
  });
}

function filtrerListe(q) {}

function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMsg();}}

function esc(str){return (str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

document.getElementById('msgInput').addEventListener('input',function(){
  this.style.height='auto'; this.style.height=Math.min(this.scrollHeight,120)+'px';
});

// Init
showView('students', document.querySelector('.nav-tab.active'));
setInterval(()=>{ if(destActifId||coursActifId) chargerMsgs(); }, 5000);
</script>
</body>
</html>
