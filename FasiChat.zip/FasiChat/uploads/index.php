<?php /* Sécurité : interdire l'accès direct au dossier uploads */
