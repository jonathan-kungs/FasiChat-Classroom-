<?php
/**
 * Configuration de FasiChat Classroom
 * Modifiez ces paramètres selon votre environnement local
 */

// Base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'fasichat');
define('DB_USER', 'root');
define('DB_PASS', '');      // Changez si votre MySQL a un mot de passe
define('DB_CHARSET', 'utf8mb4');

// Application
define('APP_NAME', 'FasiChat Classroom');
define('APP_URL', 'http://localhost/FasiChat');  // URL de base (sans slash final)

// Sécurité des sessions
define('SESSION_LIFETIME', 7200);   // 2 heures en secondes
define('SESSION_NAME', 'fasichat_session');

// Upload de fichiers
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_MAX_SIZE', 20 * 1024 * 1024);   // 20 Mo en octets
define('UPLOAD_ALLOWED_TYPES', [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'video/mp4', 'video/mpeg', 'video/quicktime',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'audio/mpeg', 'audio/wav', 'audio/ogg',
]);

// Timezone
date_default_timezone_set('Africa/Kinshasa');

// Gestion des erreurs (désactiver en production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
