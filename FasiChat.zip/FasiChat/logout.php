<?php
/**
 * Déconnexion — Met à jour le statut en_ligne et détruit la session
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/classes/Session.php';
require_once __DIR__ . '/classes/BaseDeDonnees.php';

Session::demarrer();

if (Session::estConnecte()) {
    $id = Session::getId();
    try {
        $db = BaseDeDonnees::getInstance();
        $db->executer('UPDATE utilisateurs SET en_ligne = 0 WHERE id = :id', [':id' => $id]);
    } catch (Exception $e) {
        // Ignorer les erreurs DB lors de la déconnexion
    }
}

Session::deconnecter();
header('Location: login.php?deconnecte=1');
exit;
