<?php
/**
 * Valve — Tableau d'affichage officiel (lecture seule pour tous sauf Apparitaire)
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/Valve.php';

exigerAuthentification();

$role      = Session::getRole();
$userId    = Session::getId();
$db        = BaseDeDonnees::getInstance();
$utilisateur = getUtilisateurCourant();

$valve     = new Valve();
$categorie = isset($_GET['cat']) ? nettoyerEntree($_GET['cat']) : null;
$annonces  = $valve->getAnnonces($categorie);
$compteurs = $valve->getCompteurs();

// Déterminer le dashboard de retour
$dashRetour = match($role) {
    'doyen'      => 'dashboard_admin.php',
    'vicedoyen'  => 'dashboard_vicedoyen.php',
    'apparitaire'=> 'dashboard_apparitaire.php',
    'enseignant', 'assistant' => 'dashboard_enseignant.php',
    default      => 'dashboard_etudiant.php',
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>FasiChat — Valve Faculté</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/valve.css">
</head>
<body>

<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">💬</div>
    <div class="brand-info"><h3>FasiChat</h3><span>Valve — Tableau d'affichage</span></div>
  </div>
  <div class="nav-tabs">
    <button class="nav-tab" onclick="location.href='<?= $dashRetour ?>'">💬 Chat</button>
    <button class="nav-tab active">📣 Valve</button>
  </div>
  <div class="sidebar-cats">
    <div class="section-label">Catégories</div>
    <div class="cat-item <?= !$categorie?'active':'' ?>" onclick="location.href='valve.php'">
      <div class="cat-icon" style="background:rgba(79,163,224,0.15);">📋</div>
      <div class="cat-info"><div class="cat-name">Toutes les annonces</div><div class="cat-count"><?= $compteurs['total'] ?> publications</div></div>
    </div>
    <div class="cat-item <?= $categorie==='urgent'?'active':'' ?>" onclick="location.href='valve.php?cat=urgent'">
      <div class="cat-icon" style="background:rgba(239,68,68,0.12);">🚨</div>
      <div class="cat-info"><div class="cat-name">Urgences</div><div class="cat-count"><?= $compteurs['urgent'] ?> publication(s)</div></div>
      <?php if ($compteurs['urgent']>0): ?><div class="cat-badge"><?= $compteurs['urgent'] ?></div><?php endif; ?>
    </div>
    <div class="cat-item <?= $categorie==='convocation'?'active':'' ?>" onclick="location.href='valve.php?cat=convocation'">
      <div class="cat-icon" style="background:rgba(245,158,11,0.12);">📅</div>
      <div class="cat-info"><div class="cat-name">Convocations</div><div class="cat-count"><?= $compteurs['convocation'] ?> publication(s)</div></div>
    </div>
    <div class="cat-item <?= $categorie==='information'?'active':'' ?>" onclick="location.href='valve.php?cat=information'">
      <div class="cat-icon" style="background:rgba(34,197,94,0.12);">📢</div>
      <div class="cat-info"><div class="cat-name">Informations</div><div class="cat-count"><?= $compteurs['information'] ?> publication(s)</div></div>
    </div>
    <div class="cat-item <?= $categorie==='academique'?'active':'' ?>" onclick="location.href='valve.php?cat=academique'">
      <div class="cat-icon" style="background:rgba(99,102,241,0.12);">🎓</div>
      <div class="cat-info"><div class="cat-name">Académique</div><div class="cat-count"><?= $compteurs['academique'] ?> publication(s)</div></div>
    </div>
  </div>
  <div class="sidebar-profile">
    <div class="profile-avatar" style="background:<?= getCouleurRole($role) ?>">
      <div class="online-dot"></div><?= getIconeRole($role) ?>
    </div>
    <div class="profile-info">
      <h4><?= esc($utilisateur->getPrenom().' '.$utilisateur->getNom()) ?></h4>
      <span style="font-size:10px;"><?= getLabelRole($role) ?></span>
    </div>
    <a href="logout.php" class="icon-btn">🚪</a>
  </div>
</div>

<div class="main-area">
  <div class="valve-topbar">
    <div class="valve-topbar-icon">📣</div>
    <div class="valve-topbar-info">
      <h3>Valve — Faculté des Sciences Informatiques</h3>
      <p>Tableau d'affichage officiel · Géré par l'Apparitaire</p>
    </div>
    <div class="valve-topbar-actions">
      <?php if ($role === 'apparitaire'): ?>
      <button class="vt-btn primary" onclick="location.href='dashboard_apparitaire.php'">+ Gérer les annonces</button>
      <?php else: ?>
      <button class="vt-btn ghost" onclick="location.href='<?= $dashRetour ?>'">← Mon espace</button>
      <?php endif; ?>
    </div>
  </div>

  <!-- Filter bar -->
  <div class="filter-bar">
    <button class="filter-chip <?= !$categorie?'active':'' ?>" onclick="location.href='valve.php'">Toutes</button>
    <button class="filter-chip <?= $categorie==='urgent'?'active':'' ?>" onclick="location.href='valve.php?cat=urgent'">🚨 Urgences</button>
    <button class="filter-chip <?= $categorie==='convocation'?'active':'' ?>" onclick="location.href='valve.php?cat=convocation'">📅 Convocations</button>
    <button class="filter-chip <?= $categorie==='information'?'active':'' ?>" onclick="location.href='valve.php?cat=information'">📢 Infos</button>
    <button class="filter-chip <?= $categorie==='academique'?'active':'' ?>" onclick="location.href='valve.php?cat=academique'">🎓 Académique</button>
    <div class="filter-spacer"></div>
    <div class="search-valve">
      <span class="s-ico">🔍</span>
      <input type="text" id="searchValve" placeholder="Rechercher une annonce..." oninput="filtrerAnnonces(this.value)">
    </div>
  </div>

  <div class="valve-content">
    <!-- HERO -->
    <div class="valve-hero">
      <div>
        <div class="hero-badge">TABLEAU D'AFFICHAGE OFFICIEL</div>
        <h2>Bienvenue sur le Valve 📣</h2>
        <p>Toutes les annonces officielles de la Faculté des Sciences Informatiques. Consultez régulièrement cet espace pour rester informé.</p>
        <div class="hero-stats">
          <div class="hero-stat"><div class="n"><?= $compteurs['total'] ?></div><div class="l">ANNONCES</div></div>
          <div class="hero-stat"><div class="n"><?= $compteurs['urgent'] ?></div><div class="l">URGENCES</div></div>
          <div class="hero-stat"><div class="n"><?= $compteurs['convocation'] ?></div><div class="l">CONVOCATIONS</div></div>
        </div>
      </div>
    </div>

    <!-- Annonces grid -->
    <div class="annonces-grid" id="annoncesGrid">
      <?php foreach ($annonces as $ann): ?>
      <?php
        $cats = [
          'urgent'      => ['🚨','#ef4444','URGENT', 'annonce-card urgent', 'grid-column:1/-1;'],
          'convocation' => ['📅','#d97706','CONVOCATION', 'annonce-card convocation', ''],
          'information' => ['📢','#16a34a','INFORMATION', 'annonce-card', ''],
          'academique'  => ['🎓','#6366f1','ACADÉMIQUE', 'annonce-card', ''],
        ];
        [$ico, $clr, $label, $cls, $style] = $cats[$ann['categorie']] ?? ['📋','#64748b','INFO','annonce-card',''];
      ?>
      <div class="<?= $cls ?>" style="<?= $style ?>" data-titre="<?= esc(strtolower($ann['titre'])) ?>">
        <div class="ac-header">
          <div class="ac-cat-icon" style="background:rgba(99,102,241,0.12);"><?= $ico ?></div>
          <div class="ac-meta">
            <div class="ac-cat-label" style="color:<?= $clr ?>"><?= $label ?></div>
            <div class="ac-title"><?= esc($ann['titre']) ?></div>
          </div>
          <?php if ($ann['categorie']==='urgent'): ?>
          <div class="ac-priority" style="background:rgba(239,68,68,0.1);color:#ef4444;">⚠</div>
          <?php endif; ?>
        </div>
        <div class="ac-body">
          <div class="ac-text"><?= nl2br(esc($ann['contenu'])) ?></div>

          <?php if ($ann['categorie']==='convocation'): ?>
          <?php
            // Essayer de parser la date de réunion de la convocation depuis la BDD
            $dateInfo = '';
            $convStmt = $db->executer(
              'SELECT c.date_reunion, c.heure_reunion, c.lieu FROM convocations c
               JOIN utilisateurs u ON u.id = c.expediteur_id
               ORDER BY c.created_at DESC LIMIT 1'
            )->fetch();
            if ($convStmt) {
              $dateInfo = date('d/m/Y', strtotime($convStmt['date_reunion']));
              $heureInfo = date('H:i', strtotime($convStmt['heure_reunion']));
              $lieuInfo = $convStmt['lieu'];
            }
          ?>
          <?php if ($dateInfo): ?>
          <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
            <div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;padding:6px 12px;font-size:11px;color:#92400e;font-weight:600;">📅 <?= $dateInfo ?></div>
            <div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;padding:6px 12px;font-size:11px;color:#92400e;font-weight:600;">🕐 <?= $heureInfo ?></div>
            <div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:8px;padding:6px 12px;font-size:11px;color:#92400e;font-weight:600;">📍 <?= esc($lieuInfo) ?></div>
          </div>
          <?php endif; ?>
          <?php endif; ?>

          <?php if ($ann['fichier_nom']): ?>
          <div class="ac-file">
            <span style="font-size:20px;">📄</span>
            <span><?= esc($ann['fichier_nom']) ?></span>
            <small><?= formatTaille((int)$ann['fichier_taille']) ?></small>
          </div>
          <?php endif; ?>

          <div class="ac-footer">
            <div class="ac-author">
              <div class="ac-author-ava" style="background:<?= getCouleurRole($ann['auteur_role']) ?>">
                <?= getInitiales($ann['auteur_prenom'], $ann['auteur_nom']) ?>
              </div>
              <div><div class="ac-author-name"><?= esc($ann['auteur_prenom'].' '.$ann['auteur_nom']) ?> · <?= getLabelRole($ann['auteur_role']) ?></div></div>
            </div>
            <div class="ac-date"><?= dateRelative($ann['created_at']) ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>

      <?php if (empty($annonces)): ?>
      <div style="grid-column:1/-1;text-align:center;padding:60px;color:#94a3b8;">
        <div style="font-size:48px;margin-bottom:12px;">📋</div>
        <p>Aucune annonce publiée<?= $categorie?' dans cette catégorie':'' ?>.</p>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
function filtrerAnnonces(q) {
  document.querySelectorAll('.annonce-card').forEach(card => {
    const titre = card.dataset.titre || '';
    card.style.display = titre.includes(q.toLowerCase()) ? '' : 'none';
  });
}
</script>
</body>
</html>
