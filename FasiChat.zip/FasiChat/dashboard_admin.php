<?php
/**
 * Dashboard Doyen — FasiChat Classroom
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/Doyen.php';

exigerAuthentification();
exigerRole(['doyen']);

$doyen = getUtilisateurCourant();
$stats = $doyen->getStatistiques();
$utilisateurs = $doyen->getTousUtilisateurs();
$convocations = $doyen->getConvocationsEnvoyees();
$viceDoyen = $doyen->getViceDoyen();

// Messages confidentiels avec le Vice-Doyen
$messagesConf = [];
if ($viceDoyen) {
    $db = BaseDeDonnees::getInstance();
    $messagesConf = $db->executer(
        'SELECT m.*, u.nom, u.prenom FROM messages m JOIN utilisateurs u ON u.id = m.expediteur_id
         WHERE m.type = "confidentiel"
           AND ((m.expediteur_id = :moi AND m.destinataire_id = :vd)
                OR (m.expediteur_id = :vd2 AND m.destinataire_id = :moi2))
         ORDER BY m.created_at ASC LIMIT 30',
        [':moi'=>$doyen->getId(),':vd'=>$viceDoyen['id'],
         ':vd2'=>$viceDoyen['id'],':moi2'=>$doyen->getId()]
    )->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>FasiChat — Dashboard Doyen</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/dashboard_admin.css">
</head>
<body>

<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">🏛</div>
    <div class="brand-info"><h3>FasiChat Admin</h3><span>Espace Administratif</span></div>
  </div>
  <div class="role-badge-sidebar"><div class="rdot"></div><span>DOYEN — Accès complet</span></div>
  <div class="nav-section">
    <div class="nav-section-label">Administration</div>
    <div class="nav-item active" onclick="setNav(this,'dashboard')">
      <div class="nav-icon" style="background:rgba(79,163,224,0.12);">📊</div>
      <div><div class="nav-label">Tableau de bord</div><div class="nav-sub">Vue d'ensemble</div></div>
    </div>
    <div class="nav-item" onclick="setNav(this,'convocation')">
      <div class="nav-icon" style="background:rgba(245,158,11,0.12);">📅</div>
      <div><div class="nav-label">Convoquer réunion</div><div class="nav-sub">Enseignants &amp; Assistants</div></div>
    </div>
    <div class="nav-item" onclick="setNav(this,'utilisateurs')">
      <div class="nav-icon" style="background:rgba(34,197,94,0.12);">👥</div>
      <div><div class="nav-label">Utilisateurs</div><div class="nav-sub">Gérer les comptes</div></div>
      <div class="nav-badge"><?= $stats['etudiants'] + $stats['enseignants'] ?></div>
    </div>
  </div>
  <div class="nav-section">
    <div class="nav-section-label">Communication</div>
    <div class="nav-item" onclick="location.href='valve.php'">
      <div class="nav-icon" style="background:rgba(124,58,237,0.12);">📣</div>
      <div><div class="nav-label">Valve</div><div class="nav-sub">Tableau d'affichage</div></div>
    </div>
    <div class="nav-item" onclick="setNav(this,'messages')">
      <div class="nav-icon" style="background:rgba(239,68,68,0.12);">💬</div>
      <div><div class="nav-label">Messages privés</div><div class="nav-sub">Doyen ↔ Vice-Doyen</div></div>
    </div>
  </div>
  <div class="sidebar-bottom">
    <div class="profile-row">
      <div class="profile-ava"><div class="online-dot"></div>🏛</div>
      <div class="profile-info"><h4><?= esc($doyen->getPrenom().' '.$doyen->getNom()) ?></h4><span>Doyen de la Faculté</span></div>
      <a href="logout.php" class="logout-btn">🚪</a>
    </div>
  </div>
</div>

<div class="main-area">
  <div class="admin-topbar">
    <div>
      <div class="topbar-title">Tableau de bord — Doyen</div>
      <div class="topbar-sub">Faculté des Sciences &amp; Technologies · <?= date('Y') ?></div>
    </div>
    <div class="topbar-right">
      <button class="tb-btn ghost" onclick="location.href='valve.php'">📣 Valve</button>
      <button class="tb-btn primary" onclick="openConvocModal()">📅 Convoquer une réunion</button>
    </div>
  </div>

  <div class="admin-content">

    <!-- Section Dashboard -->
    <div id="section-dashboard">
      <div class="stats-row">
        <div class="stat-card blue">
          <div class="stat-icon">🎓</div><div class="stat-number"><?= $stats['etudiants'] ?></div>
          <div class="stat-label">Étudiants inscrits</div>
        </div>
        <div class="stat-card gold">
          <div class="stat-icon">👨‍🏫</div><div class="stat-number"><?= $stats['enseignants'] ?></div>
          <div class="stat-label">Enseignants actifs</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">📚</div><div class="stat-number"><?= $stats['cours'] ?></div>
          <div class="stat-label">Cours en cours</div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">📅</div><div class="stat-number"><?= $stats['convocations'] ?></div>
          <div class="stat-label">Convocations envoyées</div>
        </div>
      </div>

      <div class="two-col">
        <div class="card">
          <div class="card-header">
            <div class="card-title">👥 Utilisateurs</div>
          </div>
          <div style="overflow-x:auto;">
            <table class="users-table">
              <thead><tr><th>Utilisateur</th><th>Rôle</th><th>Statut</th><th>Actions</th></tr></thead>
              <tbody>
              <?php foreach (array_slice($utilisateurs, 0, 8) as $u): ?>
              <tr>
                <td><div class="user-cell">
                  <div class="user-row-ava" style="background:<?= getCouleurRole($u['role']) ?>">
                    <?= getInitiales($u['prenom'],$u['nom']) ?>
                  </div>
                  <div><div class="user-name"><?= esc($u['prenom'].' '.$u['nom']) ?></div>
                  <div class="user-email"><?= esc($u['matricule']) ?></div></div>
                </div></td>
                <td><span class="role-pill"><?= getIconeRole($u['role']).' '.getLabelRole($u['role']) ?></span></td>
                <td><span style="font-size:11px;color:<?= $u['en_ligne']?'#16a34a':'#94a3b8' ?>;font-weight:600;">
                  <?= $u['en_ligne']?'● En ligne':'○ Hors ligne' ?>
                </span></td>
                <td><div class="action-btns">
                  <?php if ($u['id'] != $doyen->getId()): ?>
                  <button class="act-btn del" onclick="desactiverUser(<?= $u['id'] ?>)">🗑</button>
                  <?php endif; ?>
                </div></td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px;">
          <!-- CONVOC RAPIDE -->
          <div class="card">
            <div class="card-header"><div class="card-title">📅 Convocation rapide</div></div>
            <div class="convoc-form" id="form-convoc-rapide">
              <div class="form-group">
                <label class="form-label">Objet *</label>
                <input type="text" class="form-input" id="qObj" placeholder="Ex: Conseil pédagogique...">
              </div>
              <div class="form-row-2">
                <div class="form-group">
                  <label class="form-label">Date *</label>
                  <input type="date" class="form-input" id="qDate">
                </div>
                <div class="form-group">
                  <label class="form-label">Heure *</label>
                  <input type="time" class="form-input" id="qHeure">
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Lieu *</label>
                <input type="text" class="form-input" id="qLieu" placeholder="Salle A-12 ou lien Meet...">
              </div>
              <div class="form-group">
                <label class="form-label">Destinataires</label>
                <div class="recipients-box">
                  <div class="recipient-tag">👨‍🏫 Tous les enseignants (<?= $stats['enseignants'] ?>)</div>
                  <div class="recipient-tag">📋 Tous les assistants (<?= $stats['assistants'] ?>)</div>
                </div>
              </div>
              <button class="send-convoc-btn" onclick="envoyerConvocRapide()">📨 Envoyer la convocation</button>
            </div>
          </div>

          <!-- CONVOCATIONS ENVOYÉES -->
          <?php if (!empty($convocations)): ?>
          <div class="card">
            <div class="card-header"><div class="card-title">📋 Convocations envoyées</div></div>
            <div class="activity-list">
              <?php foreach (array_slice($convocations,0,3) as $conv): ?>
              <div class="activity-item">
                <div class="act-icon-wrap" style="background:rgba(245,158,11,0.1);">📅</div>
                <div class="act-text">
                  <strong><?= esc($conv['objet']) ?></strong>
                  <p><?= date('d/m/Y',strtotime($conv['date_reunion'])) ?> · <?= $conv['nb_destinataires'] ?> destinataires</p>
                </div>
                <div class="act-time"><?= dateRelative($conv['created_at']) ?></div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Section Messages confidentiels -->
    <div id="section-messages" style="display:none;">
      <div class="card" style="max-width:700px;">
        <div class="card-header">
          <div class="card-title">🔒 Messages confidentiels — Vice-Doyen</div>
          <span style="font-size:10px;color:#dc2626;font-weight:700;">CONFIDENTIEL</span>
        </div>
        <?php if ($viceDoyen): ?>
        <div style="height:350px;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;" id="msgs-conf">
          <?php foreach ($messagesConf as $msg): ?>
          <?php $estMoi = ((int)$msg['expediteur_id'] === $doyen->getId()); ?>
          <div style="display:flex;gap:8px;<?= $estMoi?'flex-direction:row-reverse':'' ?>">
            <div style="width:32px;height:32px;border-radius:50%;background:<?= getCouleurRole($estMoi?'doyen':'vicedoyen') ?>;display:flex;align-items:center;justify-content:center;font-size:11px;color:white;font-weight:700;flex-shrink:0;">
              <?= $estMoi?'D':'VD' ?>
            </div>
            <div>
              <div style="background:<?= $estMoi?'#0ea5e9':'#f1f5f9' ?>;color:<?= $estMoi?'white':'#1e293b' ?>;padding:10px 14px;border-radius:12px;font-size:13px;max-width:400px;">
                <?= nl2br(esc($msg['contenu'])) ?>
              </div>
              <div style="font-size:10px;color:#94a3b8;margin-top:4px;<?= $estMoi?'text-align:right':'' ?>">
                <?= date('H:i',strtotime($msg['created_at'])) ?>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php if (empty($messagesConf)): ?>
          <div style="text-align:center;color:#94a3b8;font-style:italic;font-size:12px;">Aucun message confidentiel.</div>
          <?php endif; ?>
        </div>
        <div style="padding:16px;border-top:1px solid #f1f5f9;display:flex;gap:8px;">
          <textarea id="confInput" rows="1"
            style="flex:1;padding:10px 14px;border:1px solid #e2e8f0;border-radius:10px;font-family:inherit;font-size:13px;resize:none;"
            placeholder="Message confidentiel au Vice-Doyen..."
            onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();envoyerConf();}"></textarea>
          <button onclick="envoyerConf()"
            style="padding:10px 16px;background:#0ea5e9;color:white;border:none;border-radius:10px;cursor:pointer;font-size:14px;">➤</button>
        </div>
        <?php else: ?>
        <p style="padding:20px;color:#94a3b8;">Aucun Vice-Doyen enregistré.</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Section Utilisateurs -->
    <div id="section-utilisateurs" style="display:none;">
      <div class="card">
        <div class="card-header">
          <div class="card-title">👥 Gestion des utilisateurs</div>
          <button class="tb-btn primary" onclick="document.getElementById('modal-create-user').style.display='flex'">+ Nouveau compte</button>
        </div>
        <table class="users-table">
          <thead><tr><th>Utilisateur</th><th>Rôle</th><th>Matricule</th><th>Statut</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($utilisateurs as $u): ?>
          <tr>
            <td><div class="user-cell">
              <div class="user-row-ava" style="background:<?= getCouleurRole($u['role']) ?>"><?= getInitiales($u['prenom'],$u['nom']) ?></div>
              <div><div class="user-name"><?= esc($u['prenom'].' '.$u['nom']) ?></div><div class="user-email"><?= esc($u['email']??'') ?></div></div>
            </div></td>
            <td><span class="role-pill"><?= getIconeRole($u['role']).' '.getLabelRole($u['role']) ?></span></td>
            <td><code style="font-family:'JetBrains Mono',monospace;font-size:11px;"><?= esc($u['matricule']) ?></code></td>
            <td><span style="font-size:11px;color:<?= $u['en_ligne']?'#16a34a':'#94a3b8' ?>;font-weight:600;"><?= $u['en_ligne']?'● En ligne':'○ Hors ligne' ?></span></td>
            <td><?php if ($u['id'] != $doyen->getId()): ?>
              <button class="act-btn del" onclick="desactiverUser(<?= $u['id'] ?>)">🗑</button>
            <?php endif; ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Section Convocation -->
    <div id="section-convocation" style="display:none;">
      <div class="card" style="max-width:600px;">
        <div class="card-header"><div class="card-title">📅 Convoquer une réunion</div></div>
        <div class="convoc-form" style="padding:20px;">
          <div class="form-group"><label class="form-label">Objet *</label>
            <input type="text" class="form-input" id="cObj" placeholder="Objet de la réunion..."></div>
          <div class="form-row-2">
            <div class="form-group"><label class="form-label">Date *</label><input type="date" class="form-input" id="cDate"></div>
            <div class="form-group"><label class="form-label">Heure *</label><input type="time" class="form-input" id="cHeure"></div>
          </div>
          <div class="form-group"><label class="form-label">Lieu *</label>
            <input type="text" class="form-input" id="cLieu" placeholder="Salle ou lien Meet..."></div>
          <div class="form-group"><label class="form-label">Message</label>
            <textarea class="form-textarea" id="cMsg" placeholder="Ordre du jour..."></textarea></div>
          <div class="form-group"><label class="form-label">Destinataires</label>
            <div class="recipients-box">
              <div class="recipient-tag">👨‍🏫 Tous les enseignants (<?= $stats['enseignants'] ?>)</div>
              <div class="recipient-tag">📋 Tous les assistants (<?= $stats['assistants'] ?>)</div>
            </div>
          </div>
          <button class="send-convoc-btn" onclick="envoyerConvoc('cObj','cDate','cHeure','cLieu','cMsg')">📨 Envoyer la convocation</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL CONVOCATION -->
<div class="modal-overlay" id="convocModal" onclick="closeModalOutside(event)">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-header-icon">📅</div>
      <div><h3>Convoquer une réunion</h3><p>Envoyée à tous les enseignants et assistants</p></div>
      <button class="modal-close-btn" onclick="closeConvocModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Objet *</label>
        <input type="text" class="form-input" id="mObj" placeholder="Ex: Réunion extraordinaire..."></div>
      <div class="form-row-2">
        <div class="form-group"><label class="form-label">Date *</label><input type="date" class="form-input" id="mDate"></div>
        <div class="form-group"><label class="form-label">Heure *</label><input type="time" class="form-input" id="mHeure"></div>
      </div>
      <div class="form-group"><label class="form-label">Lieu *</label>
        <input type="text" class="form-input" id="mLieu" placeholder="Amphi A ou https://meet..."></div>
      <div class="form-group"><label class="form-label">Message</label>
        <textarea class="form-textarea" id="mMsg" placeholder="Précisez l'ordre du jour..."></textarea></div>
    </div>
    <div class="modal-footer">
      <button class="btn-cancel" onclick="closeConvocModal()">Annuler</button>
      <button class="btn-send" onclick="envoyerConvocModal()">📨 Envoyer la convocation</button>
    </div>
  </div>
</div>

<!-- MODAL CRÉER UTILISATEUR -->
<div id="modal-create-user" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;align-items:center;justify-content:center;">
  <div style="background:white;border-radius:16px;padding:28px;max-width:480px;width:90%;max-height:80vh;overflow-y:auto;">
    <h3 style="margin:0 0 20px;">👤 Nouveau compte utilisateur</h3>
    <div class="form-group"><label class="form-label">Matricule *</label><input type="text" class="form-input" id="nu-mat" placeholder="ET2024..."></div>
    <div class="form-row-2">
      <div class="form-group"><label class="form-label">Nom *</label><input type="text" class="form-input" id="nu-nom"></div>
      <div class="form-group"><label class="form-label">Prénom *</label><input type="text" class="form-input" id="nu-prenom"></div>
    </div>
    <div class="form-group"><label class="form-label">Email</label><input type="email" class="form-input" id="nu-email"></div>
    <div class="form-group"><label class="form-label">Rôle *</label>
      <select class="form-input" id="nu-role">
        <option value="etudiant">🎓 Étudiant</option>
        <option value="enseignant">👨‍🏫 Enseignant</option>
        <option value="assistant">📋 Assistant</option>
        <option value="apparitaire">🗂 Apparitaire</option>
        <option value="vicedoyen">🏅 Vice-Doyen</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Mot de passe *</label><input type="password" class="form-input" id="nu-mdp" placeholder="Min. 6 caractères"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px;">
      <button class="btn-cancel" onclick="document.getElementById('modal-create-user').style.display='none'">Annuler</button>
      <button class="btn-send" onclick="creerUtilisateur()">Créer le compte</button>
    </div>
  </div>
</div>

<script src="assets/js/dashboard_admin.js"></script>
<script>
const VD_ID = <?= $viceDoyen ? $viceDoyen['id'] : 'null' ?>;
const DOYEN_ID = <?= $doyen->getId() ?>;

function setNav(el, section) {
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  el.classList.add('active');
  ['dashboard','messages','utilisateurs','convocation'].forEach(s => {
    const sec = document.getElementById('section-'+s);
    if (sec) sec.style.display = s===section?'block':'none';
  });
}

function openConvocModal(){ document.getElementById('convocModal').classList.add('open'); }
function closeConvocModal(){ document.getElementById('convocModal').classList.remove('open'); }
function closeModalOutside(e){ if(e.target.id==='convocModal') closeConvocModal(); }

function envoyerConvocModal(){
  envoyerConvoc('mObj','mDate','mHeure','mLieu','mMsg', closeConvocModal);
}

function envoyerConvocRapide(){
  envoyerConvoc('qObj','qDate','qHeure','qLieu',null);
}

function envoyerConvoc(objId, dateId, heureId, lieuId, msgId='', cb=null){
  const objet = document.getElementById(objId).value.trim();
  const date  = document.getElementById(dateId).value;
  const heure = document.getElementById(heureId).value;
  const lieu  = document.getElementById(lieuId).value.trim();
  const msg   = msgId ? document.getElementById(msgId).value.trim() : '';
  if (!objet||!date||!heure||!lieu){ alert('Veuillez remplir tous les champs obligatoires.'); return; }
  const fd = new FormData();
  fd.append('objet',objet); fd.append('date_reunion',date);
  fd.append('heure_reunion',heure); fd.append('lieu',lieu); fd.append('message',msg);
  fetch('api/convocations.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){ alert('✓ '+data.message); if(cb) cb(); }
    else alert('Erreur : '+data.erreur);
  });
}

function envoyerConf(){
  const ta = document.getElementById('confInput');
  const text = ta.value.trim(); if(!text||!VD_ID) return;
  const fd = new FormData();
  fd.append('type','confidentiel'); fd.append('contenu',text); fd.append('dest_id',VD_ID);
  fetch('api/messages.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){ ta.value=''; rafraichirConf(); } else alert(data.erreur);
  });
}

function rafraichirConf(){
  fetch('api/messages.php?type=confidentiel&dest_id='+VD_ID).then(r=>r.json()).then(data=>{
    if(!data.ok) return;
    const box = document.getElementById('msgs-conf');
    box.innerHTML='';
    data.messages.forEach(msg=>{
      const estMoi = parseInt(msg.expediteur_id)===DOYEN_ID;
      const heure = new Date(msg.created_at).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
      box.innerHTML+=`<div style="display:flex;gap:8px;${estMoi?'flex-direction:row-reverse':''}">
        <div style="width:32px;height:32px;border-radius:50%;background:${estMoi?'#dc2626':'#7c3aed'};display:flex;align-items:center;justify-content:center;font-size:11px;color:white;font-weight:700;flex-shrink:0;">${estMoi?'D':'VD'}</div>
        <div><div style="background:${estMoi?'#0ea5e9':'#f1f5f9'};color:${estMoi?'white':'#1e293b'};padding:10px 14px;border-radius:12px;font-size:13px;max-width:400px;">${esc(msg.contenu||'')}</div>
        <div style="font-size:10px;color:#94a3b8;margin-top:4px;${estMoi?'text-align:right':''}">${heure}</div></div></div>`;
    });
    box.scrollTop=box.scrollHeight;
  });
}

function desactiverUser(id){
  if(!confirm('Désactiver ce compte ?')) return;
  fetch('api/users.php',{method:'DELETE',body:'id='+id,headers:{'Content-Type':'application/x-www-form-urlencoded'}})
    .then(r=>r.json()).then(data=>{ if(data.ok) location.reload(); else alert(data.erreur); });
}

function creerUtilisateur(){
  const fd = new FormData();
  fd.append('matricule',document.getElementById('nu-mat').value.trim());
  fd.append('nom',document.getElementById('nu-nom').value.trim());
  fd.append('prenom',document.getElementById('nu-prenom').value.trim());
  fd.append('email',document.getElementById('nu-email').value.trim());
  fd.append('role',document.getElementById('nu-role').value);
  fd.append('mot_de_passe',document.getElementById('nu-mdp').value);
  fetch('api/users.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){ alert('✓ Compte créé avec succès!'); document.getElementById('modal-create-user').style.display='none'; location.reload(); }
    else alert('Erreur : '+data.erreur);
  });
}

function esc(s){return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

setInterval(()=>{ if(document.getElementById('section-messages').style.display!=='none') rafraichirConf(); },5000);
</script>
</body>
</html>
