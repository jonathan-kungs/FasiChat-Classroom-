<?php
/**
 * Middleware d'authentification pour FasiChat Classroom
 * À inclure au début de chaque page protégée.
 *
 * Usage :
 *   require_once 'middlewares/auth_middleware.php';
 *   exigerAuthentification();
 *   exigerRole(['doyen', 'vicedoyen']);
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../helpers/functions.php';
require_once __DIR__ . '/../classes/Session.php';
require_once __DIR__ . '/../classes/BaseDeDonnees.php';
require_once __DIR__ . '/../classes/Utilisateur.php';

/**
 * Exiger qu'un utilisateur soit connecté.
 * Redirige vers login.php si non authentifié.
 */
function exigerAuthentification(): void
{
    Session::demarrer();
    if (!Session::estConnecte()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Exiger que l'utilisateur connecté ait l'un des rôles spécifiés.
 * Affiche une page 403 si le rôle ne correspond pas.
 *
 * @param string[] $rolesAutorises Tableau des rôles autorisés
 */
function exigerRole(array $rolesAutorises): void
{
    exigerAuthentification();
    $roleActuel = Session::getRole();
    if (!in_array($roleActuel, $rolesAutorises, true)) {
        http_response_code(403);
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="fr">
        <head>
          <meta charset="UTF-8">
          <title>Accès refusé — FasiChat</title>
          <style>
            body{font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;background:#f1f5f9;}
            .box{text-align:center;padding:40px;background:white;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,.08);}
            h1{color:#dc2626;margin-bottom:8px;}
            p{color:#64748b;}
            a{display:inline-block;margin-top:20px;padding:10px 20px;background:#0ea5e9;color:white;border-radius:8px;text-decoration:none;}
          </style>
        </head>
        <body>
          <div class="box">
            <h1>🔒 Accès refusé</h1>
            <p>Vous n'avez pas les droits nécessaires pour accéder à cette page.</p>
            <a href="login.php">← Retour à la connexion</a>
          </div>
        </body>
        </html>
        HTML;
        exit;
    }
}

/**
 * Instancier l'objet utilisateur correct selon le rôle en session
 * Retourne l'instance du bon type (Etudiant, Enseignant, Doyen, etc.)
 */
function getUtilisateurCourant(): Utilisateur
{
    Session::demarrer();
    $id = Session::getId();
    if (!$id) {
        header('Location: login.php');
        exit;
    }

    $donnees = Utilisateur::trouverParId($id);
    if (!$donnees) {
        Session::deconnecter();
        header('Location: login.php');
        exit;
    }

    // Charger toutes les classes nécessaires
    $classesDir = __DIR__ . '/../classes/';
    $fichiers = ['AdminBase','Doyen','ViceDoyen','Apparitaire','Enseignant','Assistant','Etudiant'];
    foreach ($fichiers as $f) {
        require_once $classesDir . $f . '.php';
    }

    return match($donnees['role']) {
        'doyen'      => new Doyen($donnees),
        'vicedoyen'  => new ViceDoyen($donnees),
        'apparitaire'=> new Apparitaire($donnees),
        'enseignant' => new Enseignant($donnees),
        'assistant'  => new Assistant($donnees),
        'etudiant'   => new Etudiant($donnees),
        default      => throw new RuntimeException('Rôle inconnu : ' . $donnees['role']),
    };
}
