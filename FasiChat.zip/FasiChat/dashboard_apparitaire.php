<?php
/**
 * Dashboard Apparitaire — FasiChat Classroom
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/Apparitaire.php';
require_once __DIR__ . '/classes/Valve.php';

exigerAuthentification();
exigerRole(['apparitaire']);

$apparitaire = getUtilisateurCourant();
$stats       = $apparitaire->getStatistiquesValve();
$valve       = new Valve();
$annonces    = $valve->getAnnonces();
$promotions  = Promotion::listerToutes();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>FasiChat — Apparitaire</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/dashboard_apparitaire.css">
</head>
<body>
<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">🗂</div>
    <div class="brand-info"><h3>FasiChat</h3><span>Espace Apparitaire</span></div>
  </div>
  <div class="role-badge"><div class="rdot"></div><span>APPARITAIRE — Gestion du Valve</span></div>
  <div class="nav-section">
    <div class="nav-label-section">Gestion Valve</div>
    <div class="nav-item active" onclick="setNav(this)"><div class="nav-icon" style="background:rgba(99,102,241,0.12);">📊</div><div><div class="nl">Tableau de bord</div><div class="ns">Vue d'ensemble</div></div></div>
    <div class="nav-item" onclick="openModal()"><div class="nav-icon" style="background:rgba(34,197,94,0.12);">➕</div><div><div class="nl">Nouvelle annonce</div><div class="ns">Publier sur le Valve</div></div></div>
    <div class="nav-item" onclick="setNav(this)"><div class="nav-icon" style="background:rgba(245,158,11,0.12);">📋</div><div><div class="nl">Gérer les annonces</div><div class="ns">Modifier / Supprimer</div></div><div class="nb"><?= $stats['total'] ?></div></div>
  </div>
  <div class="nav-section">
    <div class="nav-label-section">Navigation</div>
    <div class="nav-item" onclick="location.href='valve.php'"><div class="nav-icon" style="background:rgba(99,102,241,0.08);">📣</div><div><div class="nl">Voir le Valve public</div><div class="ns">Vue utilisateur</div></div></div>
  </div>
  <div class="sidebar-bottom">
    <div class="profile-ava"><div class="online-dot"></div>🗂</div>
    <div class="pi"><h4><?= esc($apparitaire->getPrenom().' '.$apparitaire->getNom()) ?></h4><span>Apparitaire · Faculté</span></div>
    <a href="logout.php" class="logout-btn">🚪</a>
  </div>
</div>

<div class="main-area">
  <div class="topbar">
    <div>
      <div class="topbar-title">Gestion du Valve — Apparitaire</div>
      <div class="topbar-sub">Faculté des Sciences Informatiques · Tableau d'affichage officiel</div>
    </div>
    <div class="topbar-right">
      <button class="tb-btn ghost" onclick="location.href='valve.php'">👁 Voir le Valve</button>
      <button class="tb-btn primary" onclick="openModal()">➕ Nouvelle annonce</button>
    </div>
  </div>

  <div class="content">
    <div class="stats-row">
      <div class="stat-card sc-indigo"><div class="si">📣</div><div class="sn"><?= $stats['total'] ?></div><div class="sl">Annonces actives</div><div class="st">Sur le Valve public</div></div>
      <div class="stat-card sc-red"><div class="si">🚨</div><div class="sn"><?= $stats['urgent'] ?></div><div class="sl">Urgences actives</div><div class="st">Priorité maximale</div></div>
      <div class="stat-card sc-gold"><div class="si">📅</div><div class="sn"><?= $stats['convocation'] ?></div><div class="sl">Convocations</div><div class="st">Publiées sur le Valve</div></div>
      <div class="stat-card sc-green"><div class="si">👁</div><div class="sn"><?= number_format($stats['vues_total']) ?></div><div class="sl">Vues totales</div><div class="st">Toutes annonces</div></div>
    </div>

    <div class="main-grid">
      <div style="display:flex;flex-direction:column;gap:16px;">
        <!-- COMPOSE -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">✍️ Rédiger une annonce</div>
            <span style="font-size:10px;font-weight:700;background:rgba(99,102,241,0.1);color:#6366f1;border:1px solid rgba(99,102,241,0.2);padding:3px 10px;border-radius:20px;letter-spacing:0.5px;">APPARITAIRE UNIQUEMENT</span>
          </div>
          <div class="compose-area">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Titre *</label>
                <input type="text" class="form-input" id="compTitle" placeholder="Ex: Modification calendrier...">
              </div>
              <div class="form-group">
                <label class="form-label">Catégorie *</label>
                <select class="form-select" id="compCat">
                  <option value="information">📢 Information</option>
                  <option value="urgent">🚨 Urgent</option>
                  <option value="convocation">📅 Convocation</option>
                  <option value="academique">🎓 Académique</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Contenu *</label>
              <textarea class="form-textarea" id="compContent" placeholder="Rédigez le contenu de l'annonce..."></textarea>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Date d'expiration</label>
                <input type="date" class="form-input" id="compExp">
              </div>
              <div class="form-group">
                <label class="form-label">Pièce jointe</label>
                <input type="file" class="form-input" id="compFichier" accept=".pdf,.doc,.docx">
              </div>
            </div>
            <button class="pub-btn" onclick="publierAnnonce()">📣 Publier sur le Valve</button>
          </div>
        </div>

        <!-- LISTE ANNONCES -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">📋 Annonces publiées (<?= count($annonces) ?>)</div>
            <button class="card-action" onclick="location.href='valve.php'">Voir le Valve public →</button>
          </div>
          <div class="annonces-list" id="annoncesList">
            <?php foreach ($annonces as $ann): ?>
            <?php
              $cats = ['urgent'=>['🚨','#ef4444','URGENT'], 'convocation'=>['📅','#d97706','CONVOCATION'],
                       'information'=>['📢','#16a34a','INFORMATION'], 'academique'=>['🎓','#6366f1','ACADÉMIQUE']];
              [$ico, $clr, $label] = $cats[$ann['categorie']] ?? ['📋','#64748b','INFO'];
            ?>
            <div class="annonce-item" data-id="<?= $ann['id'] ?>">
              <div class="ai-cat" style="background:rgba(99,102,241,0.1);"><?= $ico ?></div>
              <div class="ai-body">
                <div class="ai-cat-tag" style="color:<?= $clr ?>"><?= $label ?></div>
                <div class="ai-title"><?= esc($ann['titre']) ?></div>
                <div class="ai-preview"><?= esc(mb_substr($ann['contenu'],0,80)) ?>...</div>
                <div class="ai-meta">
                  <span class="status-pill active-pill">● Actif</span>
                  <span><?= dateRelative($ann['created_at']) ?></span>
                  <span>👁 <?= $ann['vues'] ?> vues</span>
                </div>
              </div>
              <div class="ai-actions">
                <button class="ai-btn edit" onclick="ouvrirEdit(<?= $ann['id'] ?>, '<?= esc(addslashes($ann['titre'])) ?>', '<?= esc(addslashes($ann['contenu'])) ?>', '<?= $ann['categorie'] ?>')">✏</button>
                <button class="ai-btn del" onclick="supprimerAnnonce(<?= $ann['id'] ?>, this)">🗑</button>
              </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($annonces)): ?>
            <div style="text-align:center;padding:30px;color:#94a3b8;font-style:italic;">Aucune annonce publiée.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="right-col">
        <div class="stat-small">
          <div class="stat-small-title">📊 Statistiques Valve</div>
          <?php
            $total = max($stats['total'], 1);
            $bars = [
              ['label'=>'Urgences', 'count'=>$stats['urgent'], 'color'=>'#ef4444,#dc2626'],
              ['label'=>'Convocations', 'count'=>$stats['convocation'], 'color'=>'#f59e0b,#d97706'],
              ['label'=>'Informations', 'count'=>$stats['information'], 'color'=>'#22c55e,#16a34a'],
              ['label'=>'Académique', 'count'=>$stats['academique'], 'color'=>'#6366f1,#4f46e5'],
            ];
            foreach ($bars as $bar):
              $pct = round($bar['count']/$total*100);
          ?>
          <div class="bar-item">
            <div class="bar-label"><?= $bar['label'] ?> <span><?= $bar['count'] ?> / <?= $stats['total'] ?></span></div>
            <div class="bar-track"><div class="bar-fill" style="width:<?= $pct ?>%;background:linear-gradient(90deg,<?= $bar['color'] ?>);"></div></div>
          </div>
          <?php endforeach; ?>
          <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--gray-100);">
            <div style="font-size:11px;font-weight:700;color:var(--navy);margin-bottom:8px;">Vues totales</div>
            <div style="font-size:28px;font-weight:700;color:#6366f1;"><?= number_format($stats['vues_total']) ?></div>
          </div>
        </div>
        <div class="recent-card">
          <div class="card-header"><div class="card-title">⚡ Actions rapides</div></div>
          <div style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;">
            <button onclick="openModal()" style="width:100%;padding:10px 14px;background:linear-gradient(135deg,#6366f1,#4f46e5);color:white;border:none;border-radius:10px;font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;">➕ Nouvelle annonce</button>
            <button onclick="location.href='valve.php'" style="width:100%;padding:10px 14px;background:#f1f5f9;color:#1e293b;border:none;border-radius:10px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer;">👁 Prévisualiser le Valve</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL NOUVELLE ANNONCE -->
<div class="modal-overlay" id="modal" onclick="closeOut(event)">
  <div class="modal">
    <div class="modal-hdr"><span style="font-size:26px;">📣</span>
      <div><h3>Nouvelle annonce Valve</h3><p>Visible par tous les utilisateurs</p></div>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Titre *</label><input type="text" class="form-input" id="mTitle" placeholder="Titre..."></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Catégorie *</label>
          <select class="form-select" id="mCat">
            <option value="information">📢 Information</option>
            <option value="urgent">🚨 Urgent</option>
            <option value="convocation">📅 Convocation</option>
            <option value="academique">🎓 Académique</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Expiration</label><input type="date" class="form-input" id="mExp"></div>
      </div>
      <div class="form-group"><label class="form-label">Contenu *</label><textarea class="form-textarea" id="mContent" placeholder="Contenu..."></textarea></div>
    </div>
    <div class="modal-footer">
      <button class="btn-cancel" onclick="closeModal()">Annuler</button>
      <button class="btn-ok" onclick="publierDepuisModal()">📣 Publier sur le Valve</button>
    </div>
  </div>
</div>

<!-- MODAL EDIT -->
<div class="modal-overlay" id="editModal" onclick="closeEditOut(event)">
  <div class="modal">
    <div class="modal-hdr" style="background:linear-gradient(135deg,#0ea5e9,#0284c7);">
      <span style="font-size:26px;">✏</span>
      <div><h3>Modifier l'annonce</h3><p>Mettre à jour le contenu</p></div>
      <button class="modal-close" onclick="closeEditModal()">✕</button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="eId">
      <div class="form-group"><label class="form-label">Titre *</label><input type="text" class="form-input" id="eTitle"></div>
      <div class="form-group"><label class="form-label">Catégorie</label>
        <select class="form-select" id="eCat">
          <option value="information">📢 Information</option>
          <option value="urgent">🚨 Urgent</option>
          <option value="convocation">📅 Convocation</option>
          <option value="academique">🎓 Académique</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Contenu *</label><textarea class="form-textarea" id="eContent" style="min-height:100px;"></textarea></div>
    </div>
    <div class="modal-footer">
      <button class="btn-cancel" onclick="closeEditModal()">Annuler</button>
      <button class="btn-ok" onclick="sauvegarderEdit()">💾 Enregistrer</button>
    </div>
  </div>
</div>

<script>
function setNav(el){document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));el.classList.add('active');}
function openModal(){document.getElementById('modal').classList.add('open');}
function closeModal(){document.getElementById('modal').classList.remove('open');}
function closeOut(e){if(e.target.id==='modal')closeModal();}
function closeEditOut(e){if(e.target.id==='editModal')closeEditModal();}
function closeEditModal(){document.getElementById('editModal').classList.remove('open');}

function publierAnnonce(){
  const titre   = document.getElementById('compTitle').value.trim();
  const contenu = document.getElementById('compContent').value.trim();
  if(!titre||!contenu){alert('Titre et contenu obligatoires.'); return;}
  const fd = new FormData();
  fd.append('titre',titre); fd.append('contenu',contenu);
  fd.append('categorie',document.getElementById('compCat').value);
  fd.append('date_expiration',document.getElementById('compExp').value||'');
  const f = document.getElementById('compFichier').files[0];
  if(f) fd.append('fichier',f);
  fetch('api/valve.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){alert('✓ Annonce publiée sur le Valve !'); location.reload();}
    else alert('Erreur : '+data.erreur);
  });
}

function publierDepuisModal(){
  const titre   = document.getElementById('mTitle').value.trim();
  const contenu = document.getElementById('mContent').value.trim();
  if(!titre||!contenu){alert('Titre et contenu obligatoires.'); return;}
  const fd = new FormData();
  fd.append('titre',titre); fd.append('contenu',contenu);
  fd.append('categorie',document.getElementById('mCat').value);
  fd.append('date_expiration',document.getElementById('mExp').value||'');
  fetch('api/valve.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){alert('✓ '+data.message); closeModal(); location.reload();}
    else alert('Erreur : '+data.erreur);
  });
}

function ouvrirEdit(id,titre,contenu,cat){
  document.getElementById('eId').value=id;
  document.getElementById('eTitle').value=titre;
  document.getElementById('eContent').value=contenu;
  document.getElementById('eCat').value=cat;
  document.getElementById('editModal').classList.add('open');
}

function sauvegarderEdit(){
  const id      = document.getElementById('eId').value;
  const titre   = document.getElementById('eTitle').value.trim();
  const contenu = document.getElementById('eContent').value.trim();
  if(!titre||!contenu){alert('Champs obligatoires.'); return;}
  fetch('api/valve.php',{method:'PUT',body:'id='+id+'&titre='+encodeURIComponent(titre)+'&contenu='+encodeURIComponent(contenu)+'&categorie='+document.getElementById('eCat').value,
    headers:{'Content-Type':'application/x-www-form-urlencoded'}}).then(r=>r.json()).then(data=>{
    if(data.ok){alert('✓ Annonce modifiée !'); closeEditModal(); location.reload();}
    else alert('Erreur.');
  });
}

function supprimerAnnonce(id, btn){
  if(!confirm('Supprimer cette annonce du Valve ?')) return;
  fetch('api/valve.php',{method:'DELETE',body:'id='+id,headers:{'Content-Type':'application/x-www-form-urlencoded'}})
    .then(r=>r.json()).then(data=>{
      if(data.ok) btn.closest('.annonce-item').remove();
      else alert('Erreur.');
  });
}
</script>
</body>
</html>
