<?php
/**
 * Page de connexion — FasiChat Classroom
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/classes/Session.php';
require_once __DIR__ . '/classes/BaseDeDonnees.php';
require_once __DIR__ . '/classes/Utilisateur.php';

Session::demarrer();

// Si déjà connecté, rediriger
if (Session::estConnecte()) {
    header('Location: index.php');
    exit;
}

$erreur = '';
$deconnecte = isset($_GET['deconnecte']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matricule  = nettoyerEntree($_POST['matricule'] ?? '');
    $motDePasse = $_POST['mot_de_passe'] ?? '';

    if (empty($matricule) || empty($motDePasse)) {
        $erreur = 'Veuillez remplir tous les champs.';
    } else {
        $utilisateur = Utilisateur::authentifier($matricule, $motDePasse);
        if ($utilisateur) {
            Session::connecter($utilisateur);
            // Rediriger selon le rôle
            $dashboard = match($utilisateur['role']) {
                'doyen'       => 'dashboard_admin.php',
                'vicedoyen'   => 'dashboard_vicedoyen.php',
                'apparitaire' => 'dashboard_apparitaire.php',
                'enseignant', 'assistant' => 'dashboard_enseignant.php',
                'etudiant'    => 'dashboard_etudiant.php',
                default       => 'login.php',
            };
            header('Location: ' . $dashboard);
            exit;
        } else {
            $erreur = 'Identifiant ou mot de passe incorrect.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FasiChat Classroom — Connexion</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/login.css">
<style>
.alert-error {
    background: rgba(220,38,38,0.1);
    border: 1px solid rgba(220,38,38,0.3);
    color: #dc2626;
    padding: 12px 16px;
    border-radius: 10px;
    margin-bottom: 16px;
    font-size: 13px;
    font-weight: 500;
}
.alert-success {
    background: rgba(34,197,94,0.1);
    border: 1px solid rgba(34,197,94,0.3);
    color: #16a34a;
    padding: 12px 16px;
    border-radius: 10px;
    margin-bottom: 16px;
    font-size: 13px;
    font-weight: 500;
}
.comptes-test {
    margin-top: 24px;
    padding: 16px;
    background: rgba(14,165,233,0.05);
    border: 1px solid rgba(14,165,233,0.15);
    border-radius: 12px;
    font-size: 11px;
    color: #64748b;
}
.comptes-test h5 { margin: 0 0 8px; color: #0ea5e9; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; }
.compte-item { display: flex; justify-content: space-between; padding: 4px 0; cursor: pointer; }
.compte-item:hover { color: #0ea5e9; }
.compte-item code { font-family: 'JetBrains Mono', monospace; font-size: 10px; }
</style>
</head>
<body>
<div class="bg-layer"></div>
<div class="grid-lines"></div>
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>
<div class="orb orb-3"></div>

<div class="login-wrapper">
  <!-- Left Panel -->
  <div class="left-panel">
    <div class="brand">
      <div class="brand-logo">💬</div>
      <div class="brand-name">Fasi<span>Chat</span></div>
      <div class="brand-sub">Classroom Edition &mdash; Plateforme Académique</div>
    </div>
    <div class="features">
      <div class="feature-item">
        <div class="feature-icon">📚</div>
        <div class="feature-text">
          <h4>Cours &amp; Promotions</h4>
          <p>Regroupez étudiants et enseignants par cours et promotion</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">🔒</div>
        <div class="feature-text">
          <h4>Messagerie Sécurisée</h4>
          <p>Messages privés, publics et mur pédagogique selon les rôles</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">📁</div>
        <div class="feature-text">
          <h4>Partage de Fichiers</h4>
          <p>PDF, vidéos, documents jusqu'à 20 Mo avec compression auto</p>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">📣</div>
        <div class="feature-text">
          <h4>Onglet Valve</h4>
          <p>Annonces institutionnelles visibles par toute la communauté</p>
        </div>
      </div>
    </div>
    <div class="left-bottom">© 2026 FasiChat Classroom. Tous droits réservés.</div>
  </div>

  <!-- Right Panel -->
  <div class="right-panel">
    <div class="form-header">
      <h2>Bienvenue</h2>
      <p>Connectez-vous à votre espace académique</p>
    </div>

    <?php if ($deconnecte): ?>
      <div class="alert-success">✓ Vous avez été déconnecté avec succès.</div>
    <?php endif; ?>
    <?php if ($erreur): ?>
      <div class="alert-error">⚠ <?= esc($erreur) ?></div>
    <?php endif; ?>

    <form action="login.php" method="post">
      <div class="form-group">
        <label class="form-label">Identifiant / Matricule</label>
        <div class="input-wrapper">
          <span class="input-icon">👤</span>
          <input type="text" name="matricule" class="form-input"
                 placeholder="Ex: DOYEN001 ou ET2024001"
                 value="<?= esc($_POST['matricule'] ?? '') ?>" required>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Mot de passe</label>
        <div class="input-wrapper">
          <span class="input-icon">🔑</span>
          <input type="password" name="mot_de_passe" class="form-input"
                 placeholder="••••••••" required>
        </div>
      </div>

      <button type="submit" class="btn-login">Se connecter →</button>
    </form>

    <!-- Comptes de test -->
    <div class="comptes-test">
      <h5>COMPTES DE TEST (mot de passe : password123)</h5>
      <div class="compte-item" onclick="remplir('DOYEN001')">
        <span>🏛 Doyen (Pr. KUTANGILA)</span>
        <code>DOYEN001</code>
      </div>
      <div class="compte-item" onclick="remplir('VD001')">
        <span>🏅 Vice-Doyen (Pr. MANPUYA)</span>
        <code>VD001</code>
      </div>
      <div class="compte-item" onclick="remplir('APP001')">
        <span>🗂 Apparitaire (Djo ROLLY)</span>
        <code>APP001</code>
      </div>
      <div class="compte-item" onclick="remplir('ENS001')">
        <span>👨‍🏫 Enseignant (Prof. KABEYA)</span>
        <code>ENS001</code>
      </div>
      <div class="compte-item" onclick="remplir('ASS001')">
        <span>📋 Assistant (Amos BAHATI)</span>
        <code>ASS001</code>
      </div>
      <div class="compte-item" onclick="remplir('ET2024001')">
        <span>🎓 Étudiant (Samiel BANZOLELE)</span>
        <code>ET2024001</code>
      </div>
    </div>
  </div>
</div>

<script>
function remplir(matricule) {
  document.querySelector('input[name="matricule"]').value = matricule;
  document.querySelector('input[name="mot_de_passe"]').value = 'password123';
}
</script>
</body>
</html>
