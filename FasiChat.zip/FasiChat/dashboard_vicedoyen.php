<?php
/**
 * Dashboard Vice-Doyen — FasiChat Classroom
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/ViceDoyen.php';

exigerAuthentification();
exigerRole(['vicedoyen']);

$vd    = getUtilisateurCourant();
$stats = $vd->getStatistiques();
$convocations = $vd->getConvocationsEnvoyees();
$doyen = $vd->getDoyen();

$db = BaseDeDonnees::getInstance();
$messagesConf = [];
if ($doyen) {
    $messagesConf = $db->executer(
        'SELECT m.*, u.nom, u.prenom FROM messages m JOIN utilisateurs u ON u.id = m.expediteur_id
         WHERE m.type = "confidentiel"
           AND ((m.expediteur_id = :moi AND m.destinataire_id = :d)
                OR (m.expediteur_id = :d2 AND m.destinataire_id = :moi2))
         ORDER BY m.created_at ASC LIMIT 30',
        [':moi'=>$vd->getId(),':d'=>$doyen['id'],':d2'=>$doyen['id'],':moi2'=>$vd->getId()]
    )->fetchAll();
}

$annoncesValve = (int)$db->executer('SELECT COUNT(*) FROM annonces_valve')->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>FasiChat — Vice-Doyen</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/dashboard_vicedoyen.css">
</head>
<body>
<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">🏅</div>
    <div class="brand-info"><h3>FasiChat Admin</h3><span>Espace Vice-Doyen</span></div>
  </div>
  <div class="role-badge-sidebar"><div class="rdot"></div><span>VICE-DOYEN — Accès administratif</span></div>
  <div class="nav-section">
    <div class="nav-section-label">Administration</div>
    <div class="nav-item active" onclick="setNav(this,'dashboard')">
      <div class="nav-icon" style="background:rgba(124,58,237,0.12);">📊</div>
      <div><div class="nav-label">Tableau de bord</div><div class="nav-sub">Vue d'ensemble</div></div>
    </div>
    <div class="nav-item" onclick="setNav(this,'convocation')">
      <div class="nav-icon" style="background:rgba(245,158,11,0.12);">📅</div>
      <div><div class="nav-label">Convoquer réunion</div><div class="nav-sub">Enseignants &amp; Assistants</div></div>
    </div>
  </div>
  <div class="nav-section">
    <div class="nav-section-label">Communication</div>
    <div class="nav-item" onclick="location.href='valve.php'">
      <div class="nav-icon" style="background:rgba(124,58,237,0.12);">📣</div>
      <div><div class="nav-label">Valve</div><div class="nav-sub">Tableau d'affichage</div></div>
    </div>
    <div class="nav-item" onclick="setNav(this,'messages')">
      <div class="nav-icon" style="background:rgba(220,38,38,0.12);">🔒</div>
      <div><div class="nav-label">Message — Doyen</div><div class="nav-sub">Confidentiel</div></div>
    </div>
  </div>
  <div class="sidebar-bottom">
    <div class="profile-ava"><div class="online-dot"></div>🏅</div>
    <div class="profile-info"><h4><?= esc($vd->getPrenom().' '.$vd->getNom()) ?></h4><span>Vice-Doyen</span></div>
    <a href="logout.php" class="logout-btn">🚪</a>
  </div>
</div>

<div class="main-area">
  <div class="admin-topbar">
    <div>
      <div class="topbar-title">Tableau de bord — Vice-Doyen</div>
      <div class="topbar-sub">Faculté des Sciences Informatiques</div>
    </div>
    <div class="topbar-right">
      <button class="tb-btn ghost" onclick="location.href='valve.php'">📣 Valve</button>
      <button class="tb-btn ghost" onclick="location.href='dashboard_admin.php'">🏛 Espace Doyen</button>
      <button class="tb-btn primary" onclick="openModal()">📅 Convoquer une réunion</button>
    </div>
  </div>
  <div class="admin-content">

    <!-- STATS -->
    <div class="stats-row" id="section-dashboard">
      <div class="stat-card purple"><div class="stat-icon">👨‍🏫</div><div class="stat-number"><?= $stats['enseignants'] ?></div><div class="stat-label">Enseignants</div></div>
      <div class="stat-card blue"><div class="stat-icon">🎓</div><div class="stat-number"><?= $stats['etudiants'] ?></div><div class="stat-label">Étudiants</div></div>
      <div class="stat-card gold"><div class="stat-icon">📅</div><div class="stat-number"><?= $stats['convocations'] ?></div><div class="stat-label">Convocations envoyées</div></div>
      <div class="stat-card green"><div class="stat-icon">📣</div><div class="stat-number"><?= $annoncesValve ?></div><div class="stat-label">Annonces Valve</div></div>
    </div>

    <!-- Dashboard principal -->
    <div id="view-dashboard" class="two-col">
      <!-- CONVOC RAPIDE -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📅 Convoquer une réunion</div>
          <span class="conf-badge">🏅 Vice-Doyen uniquement</span>
        </div>
        <div class="convoc-form">
          <div class="form-group"><label class="form-label">Objet *</label><input type="text" class="form-input" id="qObj" placeholder="Ex: Commission de recherche..."></div>
          <div class="form-row-2">
            <div class="form-group"><label class="form-label">Date *</label><input type="date" class="form-input" id="qDate"></div>
            <div class="form-group"><label class="form-label">Heure *</label><input type="time" class="form-input" id="qHeure"></div>
          </div>
          <div class="form-group"><label class="form-label">Lieu *</label><input type="text" class="form-input" id="qLieu" placeholder="Salle de Conférence B..."></div>
          <div class="form-group"><label class="form-label">Message</label><textarea class="form-textarea" id="qMsg" placeholder="Ordre du jour..."></textarea></div>
          <div class="form-group"><label class="form-label">Destinataires</label>
            <div class="recipients-box">
              <div class="recipient-tag">👨‍🏫 Tous les enseignants (<?= $stats['enseignants'] ?>)</div>
              <div class="recipient-tag">📋 Tous les assistants (<?= $stats['assistants'] ?>)</div>
            </div>
          </div>
          <button class="send-btn" onclick="envoyerConvoc()">📨 Envoyer la convocation</button>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:16px;">
        <!-- MSG PRIVÉ DOYEN -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">🔒 Message privé — Doyen</div>
            <span class="conf-badge">Confidentiel</span>
          </div>
          <?php if ($doyen): ?>
          <div class="priv-chat">
            <div class="priv-messages" id="privMsgs">
              <?php foreach ($messagesConf as $msg): ?>
              <?php $estMoi = ((int)$msg['expediteur_id'] === $vd->getId()); ?>
              <div class="msg-row <?= $estMoi?'mine':'' ?>">
                <div class="msg-av" style="background:<?= $estMoi?'linear-gradient(135deg,#7c3aed,#5b21b6)':'linear-gradient(135deg,#dc2626,#991b1b)' ?>">
                  <?= $estMoi?'VD':'D' ?>
                </div>
                <div class="msg-group">
                  <div class="bubble <?= $estMoi?'mine':'theirs' ?>"><?= nl2br(esc($msg['contenu'])) ?></div>
                  <div class="msg-time"><?= date('H:i',strtotime($msg['created_at'])) ?><?= $estMoi?' ✓✓':'' ?></div>
                </div>
              </div>
              <?php endforeach; ?>
              <?php if (empty($messagesConf)): ?>
              <div style="text-align:center;color:#94a3b8;font-style:italic;font-size:12px;padding:20px;">Aucun message confidentiel.</div>
              <?php endif; ?>
            </div>
            <div class="priv-input">
              <textarea class="priv-textarea" id="privInput"
                        placeholder="Message confidentiel au Doyen..."
                        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();envoyerConf();}" rows="1"></textarea>
              <button class="priv-send" onclick="envoyerConf()">➤</button>
            </div>
          </div>
          <?php else: ?>
          <p style="padding:20px;color:#94a3b8;">Aucun Doyen enregistré.</p>
          <?php endif; ?>
        </div>

        <!-- CONVOCATIONS ENVOYÉES -->
        <?php if (!empty($convocations)): ?>
        <div class="card">
          <div class="card-header"><div class="card-title">🕐 Convocations envoyées</div></div>
          <div class="activity-list">
            <?php foreach (array_slice($convocations,0,3) as $conv): ?>
            <div class="activity-item">
              <div class="act-icon-wrap" style="background:rgba(245,158,11,0.1);">📅</div>
              <div class="act-text"><strong><?= esc($conv['objet']) ?></strong>
                <p><?= date('d/m/Y',strtotime($conv['date_reunion'])) ?> · <?= $conv['nb_destinataires'] ?> destinataires</p>
              </div>
              <div class="act-time"><?= dateRelative($conv['created_at']) ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Section Convocation -->
    <div id="view-convocation" style="display:none;">
      <div class="card" style="max-width:600px;">
        <div class="card-header"><div class="card-title">📅 Convoquer une réunion officielle</div></div>
        <div class="convoc-form" style="padding:20px;">
          <div class="form-group"><label class="form-label">Objet *</label><input type="text" class="form-input" id="cObj" placeholder="Objet..."></div>
          <div class="form-row-2">
            <div class="form-group"><label class="form-label">Date *</label><input type="date" class="form-input" id="cDate"></div>
            <div class="form-group"><label class="form-label">Heure *</label><input type="time" class="form-input" id="cHeure"></div>
          </div>
          <div class="form-group"><label class="form-label">Lieu *</label><input type="text" class="form-input" id="cLieu"></div>
          <div class="form-group"><label class="form-label">Message</label><textarea class="form-textarea" id="cMsg"></textarea></div>
          <button class="send-btn" onclick="envoyerConvocFull()">📨 Envoyer la convocation</button>
        </div>
      </div>
    </div>

    <!-- Section Messages -->
    <div id="view-messages" style="display:none;">
      <div class="card" style="max-width:600px;">
        <div class="card-header">
          <div class="card-title">🔒 Messages confidentiels — Doyen</div>
          <span class="conf-badge">Confidentiel</span>
        </div>
        <?php if ($doyen): ?>
        <div style="height:350px;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;" id="conf-section">
          <?php foreach ($messagesConf as $msg): ?>
          <?php $estMoi = ((int)$msg['expediteur_id'] === $vd->getId()); ?>
          <div style="display:flex;gap:8px;<?= $estMoi?'flex-direction:row-reverse':'' ?>">
            <div style="width:32px;height:32px;border-radius:50%;background:<?= $estMoi?'#7c3aed':'#dc2626' ?>;display:flex;align-items:center;justify-content:center;font-size:11px;color:white;font-weight:700;flex-shrink:0;"><?= $estMoi?'VD':'D' ?></div>
            <div><div style="background:<?= $estMoi?'#7c3aed':'#f1f5f9' ?>;color:<?= $estMoi?'white':'#1e293b' ?>;padding:10px 14px;border-radius:12px;font-size:13px;max-width:400px;"><?= nl2br(esc($msg['contenu'])) ?></div>
            <div style="font-size:10px;color:#94a3b8;margin-top:4px;<?= $estMoi?'text-align:right':'' ?>"><?= date('H:i',strtotime($msg['created_at'])) ?></div></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div style="padding:16px;border-top:1px solid #f1f5f9;display:flex;gap:8px;">
          <textarea id="confInput2" rows="1"
            style="flex:1;padding:10px 14px;border:1px solid #e2e8f0;border-radius:10px;font-family:inherit;font-size:13px;resize:none;"
            placeholder="Message confidentiel au Doyen..."
            onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();envoyerConf2();}"></textarea>
          <button onclick="envoyerConf2()"
            style="padding:10px 16px;background:#7c3aed;color:white;border:none;border-radius:10px;cursor:pointer;font-size:14px;">➤</button>
        </div>
        <?php else: ?>
        <p style="padding:20px;color:#94a3b8;">Aucun Doyen enregistré.</p>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<!-- MODAL CONVOCATION -->
<div class="modal-overlay" id="convocModal" onclick="closeOut(event)">
  <div class="modal">
    <div class="modal-header">
      <span style="font-size:26px;">📅</span>
      <div><h3>Convoquer une réunion</h3><p>Envoyée à tous les enseignants et assistants</p></div>
      <button class="modal-close-btn" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Objet *</label><input type="text" class="form-input" id="mObj" placeholder="Objet..."></div>
      <div class="form-row-2">
        <div class="form-group"><label class="form-label">Date *</label><input type="date" class="form-input" id="mDate"></div>
        <div class="form-group"><label class="form-label">Heure *</label><input type="time" class="form-input" id="mHeure"></div>
      </div>
      <div class="form-group"><label class="form-label">Lieu *</label><input type="text" class="form-input" id="mLieu"></div>
      <div class="form-group"><label class="form-label">Message</label><textarea class="form-textarea" id="mMsg"></textarea></div>
    </div>
    <div class="modal-footer">
      <button class="btn-cancel" onclick="closeModal()">Annuler</button>
      <button class="btn-send-modal" onclick="envoyerConvocModal()">📨 Envoyer</button>
    </div>
  </div>
</div>

<script>
const VD_ID = <?= $vd->getId() ?>;
const DOYEN_ID = <?= $doyen ? $doyen['id'] : 'null' ?>;

function setNav(el, section) {
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  el.classList.add('active');
  ['dashboard','convocation','messages'].forEach(s=>{
    const v = document.getElementById('view-'+s);
    if(v) v.style.display = s===section?'':'none';
  });
}

function openModal(){ document.getElementById('convocModal').classList.add('open'); }
function closeModal(){ document.getElementById('convocModal').classList.remove('open'); }
function closeOut(e){ if(e.target.id==='convocModal') closeModal(); }

function _envoyerConvoc(obj,date,heure,lieu,msg,cb){
  if(!obj||!date||!heure||!lieu){alert('Champs obligatoires manquants.'); return;}
  const fd = new FormData();
  fd.append('objet',obj); fd.append('date_reunion',date);
  fd.append('heure_reunion',heure); fd.append('lieu',lieu); fd.append('message',msg||'');
  fetch('api/convocations.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){alert('✓ '+data.message); if(cb) cb();}
    else alert('Erreur : '+data.erreur);
  });
}

function envoyerConvoc(){
  _envoyerConvoc(
    document.getElementById('qObj').value.trim(),
    document.getElementById('qDate').value,
    document.getElementById('qHeure').value,
    document.getElementById('qLieu').value.trim(),
    document.getElementById('qMsg').value.trim()
  );
}

function envoyerConvocFull(){
  _envoyerConvoc(
    document.getElementById('cObj').value.trim(),
    document.getElementById('cDate').value,
    document.getElementById('cHeure').value,
    document.getElementById('cLieu').value.trim(),
    document.getElementById('cMsg').value.trim()
  );
}

function envoyerConvocModal(){
  _envoyerConvoc(
    document.getElementById('mObj').value.trim(),
    document.getElementById('mDate').value,
    document.getElementById('mHeure').value,
    document.getElementById('mLieu').value.trim(),
    document.getElementById('mMsg').value.trim(),
    closeModal
  );
}

function envoyerConf(){
  const ta = document.getElementById('privInput');
  const text = ta.value.trim(); if(!text||!DOYEN_ID) return;
  const fd = new FormData();
  fd.append('type','confidentiel'); fd.append('contenu',text); fd.append('dest_id',DOYEN_ID);
  fetch('api/messages.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){ta.value=''; location.reload();} else alert(data.erreur);
  });
}

function envoyerConf2(){
  const ta = document.getElementById('confInput2');
  const text = ta.value.trim(); if(!text||!DOYEN_ID) return;
  const fd = new FormData();
  fd.append('type','confidentiel'); fd.append('contenu',text); fd.append('dest_id',DOYEN_ID);
  fetch('api/messages.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
    if(data.ok){ta.value=''; location.reload();} else alert(data.erreur);
  });
}

window.addEventListener('load',()=>{
  const b = document.getElementById('privMsgs');
  if(b) b.scrollTop = b.scrollHeight;
});
</script>
</body>
</html>
