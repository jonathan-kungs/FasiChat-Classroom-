<?php
/**
 * Point d'entrée principal — Redirige vers le bon dashboard selon le rôle
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/classes/Session.php';

Session::demarrer();

if (!Session::estConnecte()) {
    header('Location: login.php');
    exit;
}

// Rediriger vers le bon dashboard
$role = Session::getRole();
$dashboard = match($role) {
    'doyen'      => 'dashboard_admin.php',
    'vicedoyen'  => 'dashboard_vicedoyen.php',
    'apparitaire'=> 'dashboard_apparitaire.php',
    'enseignant', 'assistant' => 'dashboard_enseignant.php',
    'etudiant'   => 'dashboard_etudiant.php',
    default      => 'login.php',
};

header('Location: ' . $dashboard);
exit;
