<?php
/**
 * Dashboard Étudiant — FasiChat Classroom
 */
require_once __DIR__ . '/middlewares/auth_middleware.php';
require_once __DIR__ . '/classes/Etudiant.php';
require_once __DIR__ . '/classes/Convocation.php';
require_once __DIR__ . '/classes/Valve.php';

exigerAuthentification();
exigerRole(['etudiant']);

$etudiant = getUtilisateurCourant();
$mesCours  = $etudiant->getMesCours();
$premierCours = $mesCours[0] ?? null;
$convNonLues  = 0; // Les étudiants ne reçoivent pas de convocations

// Messages du premier cours (si existant)
$messagesInitiaux = [];
if ($premierCours) {
    $messagesInitiaux = $etudiant->getMessagesCours((int)$premierCours['id']);
}

// Conversations privées
$conversations = $etudiant->getMesConversations();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FasiChat — Dashboard Étudiant</title>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<link rel="stylesheet" href="assets/etudiant.css">
<style>
.msg-system { text-align:center; color:#94a3b8; font-size:12px; margin:20px 0; font-style:italic; }
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
  <div class="sidebar-header">
    <div class="brand-mark">💬</div>
    <div class="brand-info">
      <h3>FasiChat</h3>
      <span>Classroom Edition</span>
    </div>
  </div>

  <div class="nav-tabs">
    <button class="nav-tab active" onclick="switchTab(this,'msgs')">💬 Messages</button>
    <button class="nav-tab" onclick="switchTab(this,'cours')">📚 Cours</button>
    <button class="nav-tab" onclick="location.href='valve.php'">📣 Valve</button>
  </div>

  <div class="sidebar-search">
    <div class="search-wrap">
      <span class="search-icon">🔍</span>
      <input type="text" class="search-input" placeholder="Rechercher..." id="searchInput" oninput="filtrerConversations(this.value)">
    </div>
  </div>

  <div class="conv-list" id="msgs-panel">
    <?php if (!empty($mesCours)): ?>
    <div class="section-label">Cours Publics</div>
    <?php foreach ($mesCours as $cours): ?>
    <div class="conv-item <?= $cours === $premierCours ? 'active' : '' ?>"
         onclick="chargerCours(this, <?= $cours['id'] ?>, '<?= esc($cours['nom']) ?>')">
      <div class="avatar avatar-group">📚</div>
      <div class="conv-info">
        <div class="conv-name"><?= esc($cours['nom']) ?></div>
        <div class="conv-preview">Prof. <?= esc($cours['enseignant_nom']) ?></div>
      </div>
      <div class="conv-meta">
        <div class="conv-time">Actif</div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($conversations)): ?>
    <div class="section-label">Messages Privés</div>
    <?php foreach ($conversations as $conv): ?>
    <div class="conv-item"
         onclick="chargerPrive(this, <?= $conv['interlocuteur_id'] ?>, '<?= esc($conv['prenom'] . ' ' . $conv['nom']) ?>')">
      <div class="avatar avatar-blue" style="font-size:13px;font-weight:700;">
        <?= getInitiales($conv['prenom'], $conv['nom']) ?>
      </div>
      <div class="conv-info">
        <div class="conv-name"><?= esc($conv['prenom'] . ' ' . $conv['nom']) ?></div>
        <div class="conv-preview"><?= esc(mb_substr($conv['dernier_msg'] ?? '...', 0, 40)) ?></div>
      </div>
      <div class="conv-meta">
        <?php if ($conv['non_lus'] > 0): ?>
        <div class="conv-badge"><?= $conv['non_lus'] ?></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="sidebar-profile">
    <div class="profile-avatar">
      <div class="online-dot"></div>
      🎓
    </div>
    <div class="profile-info">
      <h4><?= esc($etudiant->getPrenom() . ' ' . $etudiant->getNom()) ?></h4>
      <span>Étudiant</span>
    </div>
    <div class="profile-actions">
      <a href="logout.php" class="icon-btn" title="Déconnexion">🚪</a>
    </div>
  </div>
</div>

<!-- MAIN CHAT -->
<div class="main-area">
  <div class="chat-topbar">
    <div class="chat-topbar-avatar" id="topbarAvatar">📚</div>
    <div class="chat-topbar-info">
      <h3 id="topbarTitle"><?= $premierCours ? esc($premierCours['nom']) : 'Sélectionnez une conversation' ?></h3>
      <p id="topbarSub"><?= $premierCours ? 'Cours public' : '' ?></p>
    </div>
    <div class="status-badge public" id="statusBadge">
      <div class="status-dot"></div>
      <span id="statusLabel">Message Public</span>
    </div>
  </div>

  <div class="chat-messages" id="messages">
    <?php if ($premierCours): ?>
    <?php foreach ($messagesInitiaux as $msg): ?>
    <?php
      $estMoi = ((int)$msg['expediteur_id'] === $etudiant->getId());
      $initiales = getInitiales($msg['prenom'], $msg['nom']);
      $couleur = getCouleurRole($msg['role']);
    ?>
    <div class="msg-row <?= $estMoi ? 'mine' : '' ?>">
      <div class="msg-avatar" style="background:<?= $couleur ?>"><?= esc($initiales) ?></div>
      <div class="msg-group">
        <?php if (!$estMoi): ?>
        <div class="msg-sender"><?= esc($msg['prenom'] . ' ' . $msg['nom']) ?> · <?= date('H:i', strtotime($msg['created_at'])) ?></div>
        <?php endif; ?>
        <div class="bubble <?= $estMoi ? 'mine' : 'theirs' ?>"><?= nl2br(esc($msg['contenu'])) ?></div>
        <div class="msg-meta">
          <?= date('H:i', strtotime($msg['created_at'])) ?>
          <?php if ($estMoi): ?><span class="check-read">✓✓</span><?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($messagesInitiaux)): ?>
    <div class="msg-system">Aucun message pour le moment. Soyez le premier à écrire !</div>
    <?php endif; ?>
    <?php else: ?>
    <div class="msg-system">Sélectionnez une conversation dans la barre de gauche.</div>
    <?php endif; ?>
  </div>

  <!-- Input -->
  <div class="chat-input-area" id="inputArea" style="<?= $premierCours ? '' : 'display:none' ?>">
    <div class="input-toolbar">
      <button class="toolbar-btn" onclick="document.getElementById('fileInput').click()">📎 Fichier</button>
      <button class="toolbar-btn" onclick="document.getElementById('imageInput').click()">🖼 Image</button>
      <button class="toolbar-btn" onclick="document.getElementById('videoInput').click()">🎥 Vidéo</button>
    </div>
    <div class="input-row">
      <div class="msg-textarea-wrap">
        <textarea class="msg-textarea" id="msgInput" rows="1"
                  placeholder="Écrire un message... (Entrée pour envoyer)"
                  onkeydown="handleKey(event)"></textarea>
        <button class="emoji-btn">😊</button>
      </div>
      <button class="send-btn" onclick="envoyerMessage()">➤</button>
    </div>
    <input type="file" id="fileInput" hidden accept=".pdf,.doc,.docx" onchange="uploadFichier(this)">
    <input type="file" id="imageInput" hidden accept="image/*" onchange="uploadFichier(this)">
    <input type="file" id="videoInput" hidden accept="video/*" onchange="uploadFichier(this)">
  </div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
  <div class="panel-section" id="infoCours">
    <?php if ($premierCours): ?>
    <div class="panel-title">Infos du cours</div>
    <div class="info-card">
      <h4><?= esc($premierCours['nom']) ?></h4>
      <p><?= esc($premierCours['description'] ?? '') ?></p>
    </div>
    <div class="panel-title">Enseignant</div>
    <div class="member-item">
      <div class="member-ava" style="background:<?= getCouleurRole('enseignant') ?>">
        <?= getInitiales($premierCours['enseignant_prenom'], $premierCours['enseignant_nom']) ?>
      </div>
      <div class="member-info">
        <h5>Prof. <?= esc($premierCours['enseignant_nom']) ?></h5>
        <p>Responsable du cours</p>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
const MON_ID = <?= $etudiant->getId() ?>;
const MON_NOM = "<?= esc($etudiant->getPrenom() . ' ' . $etudiant->getNom()) ?>";
const MON_INIT = "<?= getInitiales($etudiant->getPrenom(), $etudiant->getNom()) ?>";
let typeConv = 'cours';
let coursActifId = <?= $premierCours ? $premierCours['id'] : 'null' ?>;
let destActifId  = null;
let refreshTimer = null;

function chargerCours(item, coursId, nom) {
  document.querySelectorAll('.conv-item').forEach(i => i.classList.remove('active'));
  item.classList.add('active');
  coursActifId = coursId;
  destActifId  = null;
  typeConv     = 'cours';
  document.getElementById('topbarTitle').textContent = nom;
  document.getElementById('topbarSub').textContent   = 'Cours public';
  document.getElementById('statusLabel').textContent = 'Message Public';
  document.getElementById('statusBadge').className   = 'status-badge public';
  document.getElementById('inputArea').style.display = '';
  chargerMessages();
}

function chargerPrive(item, destId, nom) {
  document.querySelectorAll('.conv-item').forEach(i => i.classList.remove('active'));
  item.classList.add('active');
  destActifId  = destId;
  coursActifId = null;
  typeConv     = 'prive';
  document.getElementById('topbarTitle').textContent = nom;
  document.getElementById('topbarSub').textContent   = 'Message privé';
  document.getElementById('statusLabel').textContent = 'Privé';
  document.getElementById('statusBadge').className   = 'status-badge';
  document.getElementById('inputArea').style.display = '';
  chargerMessages();
}

function chargerMessages() {
  let url = 'api/messages.php?type=' + typeConv;
  if (typeConv === 'cours' && coursActifId) url += '&cours_id=' + coursActifId;
  if (typeConv === 'prive' && destActifId) url += '&dest_id=' + destActifId;

  fetch(url).then(r => r.json()).then(data => {
    if (!data.ok) return;
    const box = document.getElementById('messages');
    box.innerHTML = '';
    if (data.messages.length === 0) {
      box.innerHTML = '<div class="msg-system">Aucun message. Soyez le premier !</div>';
      return;
    }
    data.messages.forEach(msg => box.appendChild(creerBulle(msg)));
    box.scrollTop = box.scrollHeight;
  }).catch(console.error);
}

function creerBulle(msg) {
  const estMoi = parseInt(msg.expediteur_id) === MON_ID;
  const init = (msg.prenom ? msg.prenom[0] : '') + (msg.nom ? msg.nom[0] : '');
  const heure = new Date(msg.created_at).toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'});
  const div = document.createElement('div');
  div.className = 'msg-row' + (estMoi ? ' mine' : '');
  div.innerHTML = `
    <div class="msg-avatar" style="background:var(--sky)">${init.toUpperCase()}</div>
    <div class="msg-group">
      ${!estMoi ? `<div class="msg-sender">${msg.prenom} ${msg.nom} · ${heure}</div>` : ''}
      <div class="bubble ${estMoi?'mine':'theirs'}">${escHtml(msg.contenu || '')}</div>
      <div class="msg-meta">${heure}${estMoi?' <span class="check-read">✓✓</span>':''}</div>
    </div>`;
  return div;
}

function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function envoyerMessage() {
  const ta = document.getElementById('msgInput');
  const text = ta.value.trim();
  if (!text) return;

  const fd = new FormData();
  fd.append('type', typeConv);
  fd.append('contenu', text);
  if (typeConv === 'cours') fd.append('cours_id', coursActifId);
  if (typeConv === 'prive') fd.append('dest_id', destActifId);

  fetch('api/messages.php', {method:'POST', body:fd})
    .then(r => r.json()).then(data => {
      if (data.ok) { ta.value = ''; ta.style.height='auto'; chargerMessages(); }
      else alert(data.erreur);
    });
}

function uploadFichier(input) {
  if (!input.files[0]) return;
  const fd = new FormData();
  fd.append('fichier', input.files[0]);
  fd.append('type', typeConv);
  fd.append('contenu', '[Fichier partagé : ' + input.files[0].name + ']');
  if (typeConv === 'cours') fd.append('cours_id', coursActifId);
  if (typeConv === 'prive') fd.append('dest_id', destActifId);

  fetch('api/messages.php', {method:'POST', body:fd})
    .then(r => r.json()).then(data => {
      if (data.ok) chargerMessages();
      else alert(data.erreur || 'Erreur upload');
    });
  input.value = '';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); envoyerMessage(); }
}

function switchTab(btn, tab) {
  document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function filtrerConversations(q) {
  document.querySelectorAll('.conv-item').forEach(item => {
    const nom = item.querySelector('.conv-name')?.textContent.toLowerCase() || '';
    item.style.display = nom.includes(q.toLowerCase()) ? '' : 'none';
  });
}

// Auto-refresh toutes les 5 secondes
function demarrerRefresh() {
  stopperRefresh();
  refreshTimer = setInterval(() => {
    if (coursActifId || destActifId) chargerMessages();
  }, 5000);
}
function stopperRefresh() { if (refreshTimer) clearInterval(refreshTimer); }

// Textarea auto-resize
document.getElementById('msgInput').addEventListener('input', function() {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});

window.addEventListener('load', () => {
  const msgs = document.getElementById('messages');
  msgs.scrollTop = msgs.scrollHeight;
  demarrerRefresh();
});
</script>
</body>
</html>
