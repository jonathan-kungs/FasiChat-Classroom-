-- ============================================================
--  FasiChat Classroom — Schéma de base de données
--  Cours : Programmation Web en PHP — Niveau L2 / SI
-- ============================================================

CREATE DATABASE IF NOT EXISTS fasichat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fasichat;

-- -------------------------
-- Promotions
-- -------------------------
CREATE TABLE IF NOT EXISTS promotions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    niveau VARCHAR(50) NOT NULL,
    annee_academique VARCHAR(20) NOT NULL DEFAULT '2025-2026',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Utilisateurs
-- -------------------------
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(50) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role ENUM('etudiant','enseignant','assistant','doyen','vicedoyen','apparitaire') NOT NULL,
    promotion_id INT UNSIGNED NULL,
    actif TINYINT(1) NOT NULL DEFAULT 1,
    en_ligne TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (promotion_id) REFERENCES promotions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Cours
-- -------------------------
CREATE TABLE IF NOT EXISTS cours (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    code VARCHAR(50),
    description TEXT,
    promotion_id INT UNSIGNED NOT NULL,
    enseignant_id INT UNSIGNED NOT NULL,
    actif TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (promotion_id) REFERENCES promotions(id),
    FOREIGN KEY (enseignant_id) REFERENCES utilisateurs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Inscriptions aux cours
-- -------------------------
CREATE TABLE IF NOT EXISTS inscriptions_cours (
    etudiant_id INT UNSIGNED NOT NULL,
    cours_id INT UNSIGNED NOT NULL,
    inscrit_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (etudiant_id, cours_id),
    FOREIGN KEY (etudiant_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Fichiers partagés
-- -------------------------
CREATE TABLE IF NOT EXISTS fichiers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom_original VARCHAR(300) NOT NULL,
    nom_stocke VARCHAR(300) NOT NULL,
    type_mime VARCHAR(100) NOT NULL,
    taille_octets INT UNSIGNED NOT NULL,
    chemin VARCHAR(500) NOT NULL,
    type_fichier ENUM('image','video','document','vocal','autre') NOT NULL DEFAULT 'autre',
    uploaded_by INT UNSIGNED NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES utilisateurs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Messages
-- -------------------------
CREATE TABLE IF NOT EXISTS messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    expediteur_id INT UNSIGNED NOT NULL,
    destinataire_id INT UNSIGNED NULL,
    cours_id INT UNSIGNED NULL,
    type ENUM('prive','public','cours','confidentiel') NOT NULL,
    contenu TEXT,
    type_media ENUM('texte','vocal','fichier') NOT NULL DEFAULT 'texte',
    fichier_id INT UNSIGNED NULL,
    lu TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (expediteur_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (destinataire_id) REFERENCES utilisateurs(id) ON DELETE SET NULL,
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE SET NULL,
    FOREIGN KEY (fichier_id) REFERENCES fichiers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Convocations de réunion
-- -------------------------
CREATE TABLE IF NOT EXISTS convocations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    expediteur_id INT UNSIGNED NOT NULL,
    objet VARCHAR(300) NOT NULL,
    date_reunion DATE NOT NULL,
    heure_reunion TIME NOT NULL,
    lieu VARCHAR(300) NOT NULL,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (expediteur_id) REFERENCES utilisateurs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Destinataires des convocations
-- -------------------------
CREATE TABLE IF NOT EXISTS destinataires_convocations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    convocation_id INT UNSIGNED NOT NULL,
    destinataire_id INT UNSIGNED NOT NULL,
    lu TINYINT(1) NOT NULL DEFAULT 0,
    lu_le TIMESTAMP NULL,
    FOREIGN KEY (convocation_id) REFERENCES convocations(id) ON DELETE CASCADE,
    FOREIGN KEY (destinataire_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    UNIQUE KEY unique_dest (convocation_id, destinataire_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Annonces du Valve
-- -------------------------
CREATE TABLE IF NOT EXISTS annonces_valve (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    auteur_id INT UNSIGNED NOT NULL,
    titre VARCHAR(300) NOT NULL,
    contenu TEXT NOT NULL,
    categorie ENUM('urgent','convocation','information','academique') NOT NULL DEFAULT 'information',
    date_expiration DATE NULL,
    fichier_id INT UNSIGNED NULL,
    vues INT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (auteur_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (fichier_id) REFERENCES fichiers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------
-- Mur pédagogique
-- -------------------------
CREATE TABLE IF NOT EXISTS mur_pedagogique (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    auteur_id INT UNSIGNED NOT NULL,
    cours_id INT UNSIGNED NOT NULL,
    contenu TEXT NOT NULL,
    fichier_id INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (auteur_id) REFERENCES utilisateurs(id),
    FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE,
    FOREIGN KEY (fichier_id) REFERENCES fichiers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
