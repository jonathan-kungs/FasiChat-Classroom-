-- ============================================================
--  FasiChat Classroom — Données de démonstration
--  Comptes de test pour chaque rôle
-- ============================================================

USE fasichat;

-- -------------------------
-- Promotions
-- -------------------------
INSERT INTO promotions (nom, niveau, annee_academique) VALUES
('L2 Sciences Informatiques FASI', 'L2', '2025-2026'),
('L3 Cybersécurité', 'L3', '2025-2026'),
('L1 Informatique', 'L1', '2025-2026');

-- -------------------------
-- Utilisateurs (mots de passe: password123 hashé avec bcrypt)
-- Tous les mots de passe sont: password123
-- -------------------------
INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, promotion_id) VALUES
-- Doyen
('DOYEN001', 'KUTANGILA', 'Pierre', 'doyen@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'doyen', NULL),

-- Vice-Doyen
('VD001', 'MANPUYA', 'Jacques', 'vdoyen@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vicedoyen', NULL),

-- Apparitaire
('APP001', 'ROLLY', 'Djo', 'apparitaire@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'apparitaire', NULL),

-- Enseignants
('ENS001', 'KABEYA', 'Alphonse', 'kabeya@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'enseignant', NULL),

('ENS002', 'MBUYAMBA', 'Serge', 'mbuyamba@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'enseignant', NULL),

('ENS003', 'ZUIYA', 'Christian', 'zuiya@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'enseignant', NULL),

-- Assistants
('ASS001', 'BAHATI', 'Amos', 'bahati@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'assistant', NULL),

('ASS002', 'NGALULA', 'Jean', 'ngalula@faculte.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'assistant', NULL),

-- Étudiants L2
('ET2024001', 'BANZOLELE', 'Samiel', 'samiel@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024002', 'ITEWE', 'Ezechiel', 'ezechiel@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024003', 'MAZUA', 'Beloved', 'beloved@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024004', 'BAKENDA', 'Dan', 'dan@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024005', 'SHONGO', 'Yve', 'yve@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024006', 'BIAYA', 'Jordy', 'jordy@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024007', 'NZOLA', 'Love', 'love@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024008', 'MBO', 'Dan', 'danm@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024009', 'YULILA', 'Miriam', 'miriam@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1),

('ET2024010', 'NGONGO', 'Andy', 'andy@etudiant.edu',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'etudiant', 1);

-- -------------------------
-- Cours
-- -------------------------
INSERT INTO cours (nom, code, description, promotion_id, enseignant_id) VALUES
('Programmation Web en PHP', 'INF301', 'Programmation Orientée Objet en PHP, PDO, MVC', 1, 4),
('Système Embarqué', 'INF302', 'Microcontrôleurs, Arduino, systèmes temps-réel', 1, 6),
('Cybersécurité Avancée', 'INF401', 'Cryptographie, sécurité réseaux, tests de pénétration', 2, 5);

-- -------------------------
-- Inscriptions aux cours
-- -------------------------
INSERT INTO inscriptions_cours (etudiant_id, cours_id) VALUES
(9, 1), (10, 1), (11, 1), (12, 1), (13, 1),
(14, 1), (15, 1), (16, 1), (17, 1), (18, 1),
(9, 2), (10, 2), (11, 2), (12, 2), (13, 2);

-- -------------------------
-- Messages de démonstration
-- -------------------------
INSERT INTO messages (expediteur_id, destinataire_id, cours_id, type, contenu, type_media) VALUES
-- Messages dans le cours PHP (public)
(4, NULL, 1, 'cours', 'Bonjour à tous ! Rappel : les projets FasiChat sont à rendre avant vendredi 23h59. Assurez-vous de respecter les principes de la POO. Bon courage !', 'texte'),
(9, NULL, 1, 'cours', 'Merci Professeur, est-ce que le rapport est obligatoire pour la note finale ?', 'texte'),
(4, NULL, 1, 'cours', 'La conception est obligatoire et compte pour 6 points sur 20. Pensez aux diagrammes UML !', 'texte'),
(10, NULL, 1, 'cours', 'Professeur, pour la classe abstraite Utilisateur, doit-on y mettre la méthode de connexion ?', 'texte'),
(4, NULL, 1, 'cours', 'La méthode seConnecter() doit être déclarée abstraite dans la classe mère et implémentée dans chaque classe fille. Pensez au polymorphisme !', 'texte'),

-- Message privé entre étudiants
(9, 10, NULL, 'prive', 'Ezechiel, tu as commencé le diagramme UML ?', 'texte'),
(10, 9, NULL, 'prive', 'Oui je travaille dessus. On peut se voir demain pour comparer ?', 'texte'),
(9, 11, NULL, 'prive', 'Beloved, le culte de demain est important, sois là !', 'texte'),

-- Message privé enseignant à enseignant
(4, 5, NULL, 'prive', 'Collègue Mbuyamba, vous êtes disponible pour la réunion de jeudi ?', 'texte'),
(5, 4, NULL, 'prive', "D'accord pour jeudi 14h, je serai là.", 'texte'),

-- Message confidentiel Doyen ↔ Vice-Doyen
(1, 2, NULL, 'confidentiel', "VD, avez-vous les résultats de la commission de recherche pour vendredi ?", 'texte'),
(2, 1, NULL, 'confidentiel', 'Oui Professeur, je les ferai parvenir avant jeudi midi. 3 nouveaux projets validés.', 'texte'),
(1, 2, NULL, 'confidentiel', 'Parfait. Préparez aussi le bilan budgétaire pour la réunion.', 'texte'),
(2, 1, NULL, 'confidentiel', 'Bien reçu. Je prépare tout cela.', 'texte');

-- -------------------------
-- Convocations
-- -------------------------
INSERT INTO convocations (expediteur_id, objet, date_reunion, heure_reunion, lieu, message) VALUES
(1, 'Conseil Pédagogique — Bilan Semestre 5', '2026-01-24', '14:00:00', 'Salle A-12',
 "Présence obligatoire pour tous les enseignants et assistants. Ordre du jour : bilan du semestre 5 et modalités des examens de rattrapage."),
(2, 'Réunion Commission de Recherche', '2026-01-27', '10:00:00', 'Salle de Conférence B',
 'Veuillez préparer un bilan de vos activités de recherche du semestre. Présentation des nouveaux projets validés.');

-- Destinataires convocations (tous enseignants et assistants : ids 4,5,6,7,8)
INSERT INTO destinataires_convocations (convocation_id, destinataire_id) VALUES
(1, 4), (1, 5), (1, 6), (1, 7), (1, 8),
(2, 4), (2, 5), (2, 6), (2, 7), (2, 8);

-- -------------------------
-- Annonces Valve
-- -------------------------
INSERT INTO annonces_valve (auteur_id, titre, contenu, categorie, date_expiration) VALUES
(3, 'Modification du calendrier des examens — Semestre 5',
 'Suite à des contraintes organisationnelles, le calendrier des examens de rattrapage a été modifié. Les épreuves de Programmation Web et de Mathématique pour informaticien sont reportées au lundi 27 juillet 2026. Veuillez consulter le nouveau calendrier.',
 'urgent', '2026-07-27'),

(3, 'Réunion du Conseil Pédagogique — Vendredi 24 Juin',
 'Le Doyen de la Faculté convoque l\'ensemble des enseignants et assistants à une réunion du Conseil Pédagogique. Présence obligatoire. Ordre du jour : bilan du semestre 5 et modalités des examens.',
 'convocation', '2026-06-24'),

(3, 'Dépôt des projets — Plateforme en ligne',
 'Le dépôt des projets de fin d\'année s\'effectuera exclusivement via la plateforme en ligne de la faculté. Aucun envoi par email ne sera accepté. Date limite : vendredi 30 juin 2026 à 23h59.',
 'information', '2026-06-30'),

(3, 'Résultats du Semestre 2 disponibles',
 'Les résultats du semestre 2 sont désormais disponibles sur le portail étudiant. Les étudiants ayant des réclamations disposent de 5 jours ouvrables pour contacter la scolarité.',
 'academique', NULL),

(3, 'Fermeture de la salle de machines — Travaux',
 'La salle de machines sera fermée du 22 au 24 juillet 2026 pour travaux de rénovation. Les étudiants sont priés d\'utiliser leurs propres équipements pendant cette période.',
 'information', '2026-07-24');

-- -------------------------
-- Mur pédagogique
-- -------------------------
INSERT INTO mur_pedagogique (auteur_id, cours_id, contenu) VALUES
(4, 1, 'Rappel important : le projet FasiChat est à rendre avant vendredi 23h59. Assurez-vous que votre diagramme UML est complet et que votre code respecte les principes de la POO vus en cours. Bon courage à tous !'),
(4, 1, 'Question de réflexion pour la prochaine séance : Comment modéliseriez-vous la différence de visibilité des messages entre étudiants et enseignants en POO ? Pensez aux interfaces et aux principes SOLID.'),
(7, 1, 'Pour ceux qui ont des difficultés avec PDO, je vous recommande de lire la documentation officielle. Les requêtes préparées sont obligatoires dans ce projet !');
