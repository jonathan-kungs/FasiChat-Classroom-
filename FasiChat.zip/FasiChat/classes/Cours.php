<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe Cours — Représente un cours académique
 */
class Cours
{
    private ?int $id;
    private string $nom;
    private string $code;
    private ?int $promotionId;
    private int $enseignantId;
    private bool $actif;
    private BaseDeDonnees $db;

    public function __construct(array $donnees = [])
    {
        $this->id           = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->nom          = $donnees['nom'] ?? '';
        $this->code         = $donnees['code'] ?? '';
        $this->promotionId  = isset($donnees['promotion_id']) ? (int)$donnees['promotion_id'] : null;
        $this->enseignantId = (int)($donnees['enseignant_id'] ?? 0);
        $this->actif        = (bool)($donnees['actif'] ?? true);
        $this->db           = BaseDeDonnees::getInstance();
    }

    /**
     * Lister tous les cours
     */
    public static function listerTous(): array
    {
        $db = BaseDeDonnees::getInstance();
        return $db->executer(
            'SELECT c.*, p.nom AS promo_nom,
               u.nom AS ens_nom, u.prenom AS ens_prenom,
               (SELECT COUNT(*) FROM inscriptions_cours ic WHERE ic.cours_id = c.id) AS nb_etudiants
             FROM cours c
             LEFT JOIN promotions p ON p.id = c.promotion_id
             JOIN utilisateurs u ON u.id = c.enseignant_id
             WHERE c.actif = 1
             ORDER BY c.nom'
        )->fetchAll();
    }

    /**
     * Trouver un cours par ID
     */
    public static function trouverParId(int $id): ?array
    {
        $db = BaseDeDonnees::getInstance();
        $stmt = $db->executer(
            'SELECT c.*, p.nom AS promo_nom, u.nom AS ens_nom, u.prenom AS ens_prenom
             FROM cours c
             LEFT JOIN promotions p ON p.id = c.promotion_id
             JOIN utilisateurs u ON u.id = c.enseignant_id
             WHERE c.id = :id',
            [':id' => $id]
        );
        return $stmt->fetch() ?: null;
    }

    public function getId(): ?int   { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function getCode(): string { return $this->code; }
}

// ============================================================

/**
 * Classe Promotion — Groupe d'étudiants
 */
class Promotion
{
    private ?int $id;
    private string $nom;
    private string $niveau;
    private string $anneeAcademique;
    private BaseDeDonnees $db;

    public function __construct(array $donnees = [])
    {
        $this->id              = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->nom             = $donnees['nom'] ?? '';
        $this->niveau          = $donnees['niveau'] ?? '';
        $this->anneeAcademique = $donnees['annee_academique'] ?? '2025-2026';
        $this->db              = BaseDeDonnees::getInstance();
    }

    public static function listerToutes(): array
    {
        $db = BaseDeDonnees::getInstance();
        return $db->executer(
            'SELECT p.*, COUNT(u.id) AS nb_etudiants
             FROM promotions p
             LEFT JOIN utilisateurs u ON u.promotion_id = p.id AND u.role = "etudiant"
             GROUP BY p.id
             ORDER BY p.niveau, p.nom'
        )->fetchAll();
    }

    public function getId(): ?int   { return $this->id; }
    public function getNom(): string { return $this->nom; }
}

// ============================================================

/**
 * Classe MurPedagogique — Tableau des publications pédagogiques d'un cours
 */
class MurPedagogique
{
    private int $coursId;
    private BaseDeDonnees $db;

    public function __construct(int $coursId)
    {
        $this->coursId = $coursId;
        $this->db      = BaseDeDonnees::getInstance();
    }

    /**
     * Obtenir les publications du mur pédagogique
     */
    public function getPosts(): array
    {
        return $this->db->executer(
            'SELECT mp.*, u.nom, u.prenom, u.role,
               f.nom_original AS fichier_nom, f.chemin AS fichier_chemin
             FROM mur_pedagogique mp
             JOIN utilisateurs u ON u.id = mp.auteur_id
             LEFT JOIN fichiers f ON f.id = mp.fichier_id
             WHERE mp.cours_id = :cid
             ORDER BY mp.created_at DESC',
            [':cid' => $this->coursId]
        )->fetchAll();
    }

    /**
     * Supprimer un post (l'auteur uniquement)
     */
    public function supprimerPost(int $postId, int $auteurId): bool
    {
        $stmt = $this->db->executer(
            'SELECT id FROM mur_pedagogique WHERE id = :pid AND auteur_id = :aid',
            [':pid' => $postId, ':aid' => $auteurId]
        );
        if (!$stmt->fetch()) return false;
        $this->db->executer('DELETE FROM mur_pedagogique WHERE id = :id', [':id' => $postId]);
        return true;
    }
}
