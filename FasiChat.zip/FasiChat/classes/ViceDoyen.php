<?php
require_once __DIR__ . '/AdminBase.php';

/**
 * Classe ViceDoyen — Adjoint du Doyen
 * Mêmes droits de convocation que le Doyen (via héritage AdminBase + Convocable).
 * Peut aussi affecter les enseignants à des cours.
 */
class ViceDoyen extends AdminBase
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_vicedoyen.php';
    }

    /**
     * Affecter un enseignant à un cours
     */
    public function affecterEnseignant(int $enseignantId, int $coursId): bool
    {
        // Vérifier que l'utilisateur est bien enseignant
        $stmt = $this->db->executer(
            'SELECT id FROM utilisateurs WHERE id = :id AND role IN ("enseignant","assistant")',
            [':id' => $enseignantId]
        );
        if (!$stmt->fetch()) {
            return false;
        }

        $this->db->executer(
            'UPDATE cours SET enseignant_id = :ens WHERE id = :cid',
            [':ens' => $enseignantId, ':cid' => $coursId]
        );
        return true;
    }

    /**
     * Obtenir tous les cours avec leurs enseignants (pour affectation)
     */
    public function getCoursPourAffectation(): array
    {
        return $this->db->executer(
            'SELECT c.*, u.nom AS ens_nom, u.prenom AS ens_prenom, p.nom AS promo_nom
             FROM cours c
             JOIN utilisateurs u ON u.id = c.enseignant_id
             LEFT JOIN promotions p ON p.id = c.promotion_id
             WHERE c.actif = 1
             ORDER BY c.nom'
        )->fetchAll();
    }

    /**
     * Trouver le Doyen pour les messages confidentiels
     */
    public function getDoyen(): ?array
    {
        return $this->db->executer(
            'SELECT * FROM utilisateurs WHERE role = "doyen" AND actif = 1 LIMIT 1'
        )->fetch() ?: null;
    }
}
