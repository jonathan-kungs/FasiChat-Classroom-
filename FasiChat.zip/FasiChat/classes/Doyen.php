<?php
require_once __DIR__ . '/AdminBase.php';

/**
 * Classe Doyen — Responsable de faculté, privilèges les plus élevés
 * Peut : convoquer une réunion, gérer les utilisateurs,
 *         envoyer des messages confidentiels au Vice-Doyen.
 */
class Doyen extends AdminBase
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_admin.php';
    }

    /**
     * Créer un compte utilisateur (Doyen uniquement)
     */
    public function creerUtilisateur(
        string $matricule,
        string $nom,
        string $prenom,
        string $email,
        string $motDePasse,
        string $role,
        ?int $promotionId = null
    ): bool {
        $hash = Utilisateur::hacherMotDePasse($motDePasse);
        try {
            $this->db->executer(
                'INSERT INTO utilisateurs (matricule, nom, prenom, email, mot_de_passe, role, promotion_id)
                 VALUES (:mat, :nom, :prenom, :email, :mdp, :role, :promo)',
                [
                    ':mat'   => $matricule,
                    ':nom'   => $nom,
                    ':prenom' => $prenom,
                    ':email' => $email,
                    ':mdp'   => $hash,
                    ':role'  => $role,
                    ':promo' => $promotionId,
                ]
            );
            return true;
        } catch (PDOException $e) {
            return false; // Doublon matricule ou email
        }
    }

    /**
     * Désactiver un compte utilisateur
     */
    public function desactiverUtilisateur(int $utilisateurId): bool
    {
        if ($utilisateurId === $this->id) {
            return false; // Impossible de se désactiver soi-même
        }
        $this->db->executer(
            'UPDATE utilisateurs SET actif = 0 WHERE id = :id',
            [':id' => $utilisateurId]
        );
        return true;
    }

    /**
     * Trouver le Vice-Doyen pour les messages confidentiels
     */
    public function getViceDoyen(): ?array
    {
        return $this->db->executer(
            'SELECT * FROM utilisateurs WHERE role = "vicedoyen" AND actif = 1 LIMIT 1'
        )->fetch() ?: null;
    }
}
