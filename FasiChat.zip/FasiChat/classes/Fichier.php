<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe abstraite Fichier — Gestion des fichiers partagés
 * Concept POO : encapsulation, héritage, compression GD
 */
abstract class Fichier
{
    protected ?int $id;
    protected string $nomOriginal;
    protected string $nomStocke;
    protected string $typeMime;
    protected int $tailleOctets;
    protected string $chemin;
    protected int $uploadedBy;
    protected BaseDeDonnees $db;

    public const MAX_SIZE = 20 * 1024 * 1024; // 20 Mo

    public function __construct(array $donnees = [])
    {
        $this->id           = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->nomOriginal  = $donnees['nom_original'] ?? '';
        $this->nomStocke    = $donnees['nom_stocke'] ?? '';
        $this->typeMime     = $donnees['type_mime'] ?? '';
        $this->tailleOctets = (int)($donnees['taille_octets'] ?? 0);
        $this->chemin       = $donnees['chemin'] ?? '';
        $this->uploadedBy   = (int)($donnees['uploaded_by'] ?? 0);
        $this->db           = BaseDeDonnees::getInstance();
    }

    /**
     * Traiter le fichier avant stockage (compression, etc.)
     * Chaque sous-classe implémente sa propre logique
     */
    abstract public function traiter(string $tmpPath): bool;

    /**
     * Enregistrer le fichier en base de données
     */
    public function enregistrer(): bool
    {
        $this->db->executer(
            'INSERT INTO fichiers (nom_original, nom_stocke, type_mime, taille_octets, chemin, type_fichier, uploaded_by)
             VALUES (:orig, :stocke, :mime, :taille, :chemin, :type, :par)',
            [
                ':orig'   => $this->nomOriginal,
                ':stocke' => $this->nomStocke,
                ':mime'   => $this->typeMime,
                ':taille' => $this->tailleOctets,
                ':chemin' => $this->chemin,
                ':type'   => $this->getTypeFichier(),
                ':par'    => $this->uploadedBy,
            ]
        );
        $this->id = (int)$this->db->dernierInsertId();
        return true;
    }

    /**
     * Valider un fichier uploadé (type + taille)
     */
    public static function valider(array $fichierPost, array $typesAutorises): array
    {
        if (!isset($fichierPost['tmp_name']) || $fichierPost['error'] !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'erreur' => 'Erreur lors du téléversement.'];
        }

        if ($fichierPost['size'] > self::MAX_SIZE) {
            return ['ok' => false, 'erreur' => 'La taille maximale est 20 Mo.'];
        }

        // Vérifier le type MIME réel (pas la valeur POST)
        $finfo   = new finfo(FILEINFO_MIME_TYPE);
        $typeMime = $finfo->file($fichierPost['tmp_name']);

        if (!in_array($typeMime, $typesAutorises, true)) {
            return ['ok' => false, 'erreur' => 'Type de fichier non autorisé.'];
        }

        return ['ok' => true, 'mime' => $typeMime];
    }

    /**
     * Générer un nom de fichier unique pour le stockage
     */
    protected static function genererNomStocke(string $extension): string
    {
        return uniqid('fc_', true) . '.' . $extension;
    }

    abstract protected function getTypeFichier(): string;

    // Accesseurs
    public function getId(): ?int            { return $this->id; }
    public function getNomOriginal(): string { return $this->nomOriginal; }
    public function getNomStocke(): string   { return $this->nomStocke; }
    public function getChemin(): string      { return $this->chemin; }
    public function getTailleOctets(): int   { return $this->tailleOctets; }
    public function getTypeMime(): string    { return $this->typeMime; }
}

// ============================================================

/**
 * Classe Image — Gestion des images avec compression GD
 */
class Image extends Fichier
{
    private int $qualiteJpeg;

    public function __construct(array $donnees = [], int $qualite = 75)
    {
        parent::__construct($donnees);
        $this->qualiteJpeg = max(1, min(100, $qualite));
    }

    protected function getTypeFichier(): string { return 'image'; }

    /**
     * Comprimer l'image avec l'extension GD (JPEG/PNG)
     */
    public function traiter(string $tmpPath): bool
    {
        if (!function_exists('imagecreatefromjpeg')) {
            // GD non disponible — copie directe
            return copy($tmpPath, $this->chemin);
        }

        $image = null;
        switch ($this->typeMime) {
            case 'image/jpeg':
            case 'image/jpg':
                $image = @imagecreatefromjpeg($tmpPath);
                break;
            case 'image/png':
                $image = @imagecreatefrompng($tmpPath);
                break;
            case 'image/gif':
                $image = @imagecreatefromgif($tmpPath);
                break;
            case 'image/webp':
                $image = @imagecreatefromwebp($tmpPath);
                break;
            default:
                return copy($tmpPath, $this->chemin);
        }

        if (!$image) {
            return copy($tmpPath, $this->chemin);
        }

        // Redimensionner si la largeur dépasse 1920px
        $w = imagesx($image);
        $h = imagesy($image);
        if ($w > 1920) {
            $newH = (int)(($h / $w) * 1920);
            $resized = imagescale($image, 1920, $newH);
            imagedestroy($image);
            $image = $resized;
        }

        $resultat = imagejpeg($image, $this->chemin, $this->qualiteJpeg);
        imagedestroy($image);

        if ($resultat) {
            $this->tailleOctets = filesize($this->chemin);
        }

        return $resultat;
    }

    /**
     * Factory : créer une Image depuis un fichier uploadé
     */
    public static function depuisUpload(array $fichierPost, int $userId): ?self
    {
        $types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $valid = self::valider($fichierPost, $types);
        if (!$valid['ok']) return null;

        $ext = match($valid['mime']) {
            'image/png'  => 'jpg', // Toujours sauver en JPEG après compression
            'image/gif'  => 'gif',
            default      => 'jpg',
        };

        $nomStocke = self::genererNomStocke($ext);
        $chemin    = UPLOAD_DIR . $nomStocke;

        $instance = new self([
            'nom_original'  => basename($fichierPost['name']),
            'nom_stocke'    => $nomStocke,
            'type_mime'     => $valid['mime'],
            'taille_octets' => $fichierPost['size'],
            'chemin'        => $chemin,
            'uploaded_by'   => $userId,
        ]);

        if (!$instance->traiter($fichierPost['tmp_name'])) {
            return null;
        }
        $instance->enregistrer();
        return $instance;
    }
}

// ============================================================

/**
 * Classe Video — Gestion des vidéos avec compression FFmpeg (si disponible)
 */
class Video extends Fichier
{
    protected function getTypeFichier(): string { return 'video'; }

    public function traiter(string $tmpPath): bool
    {
        // Vérifier FFmpeg
        $ffmpegPath = trim(shell_exec('which ffmpeg 2>/dev/null'));
        if (!empty($ffmpegPath) && file_exists($ffmpegPath)) {
            // Comprimer avec FFmpeg (CRF 28 = compression modérée)
            $cmd = sprintf(
                '%s -i %s -vcodec libx264 -crf 28 -acodec aac %s -y 2>/dev/null',
                escapeshellarg($ffmpegPath),
                escapeshellarg($tmpPath),
                escapeshellarg($this->chemin)
            );
            exec($cmd, $output, $returnCode);
            if ($returnCode === 0 && file_exists($this->chemin)) {
                $this->tailleOctets = filesize($this->chemin);
                return true;
            }
        }
        // Fallback : copie directe si FFmpeg indisponible
        return move_uploaded_file($tmpPath, $this->chemin) || copy($tmpPath, $this->chemin);
    }

    public static function depuisUpload(array $fichierPost, int $userId): ?self
    {
        $types = ['video/mp4', 'video/mpeg', 'video/quicktime', 'video/x-msvideo'];
        $valid = self::valider($fichierPost, $types);
        if (!$valid['ok']) return null;

        $nomStocke = self::genererNomStocke('mp4');
        $chemin    = UPLOAD_DIR . $nomStocke;

        $instance = new self([
            'nom_original'  => basename($fichierPost['name']),
            'nom_stocke'    => $nomStocke,
            'type_mime'     => $valid['mime'],
            'taille_octets' => $fichierPost['size'],
            'chemin'        => $chemin,
            'uploaded_by'   => $userId,
        ]);

        if (!$instance->traiter($fichierPost['tmp_name'])) {
            return null;
        }
        $instance->enregistrer();
        return $instance;
    }
}

// ============================================================

/**
 * Classe Document — PDF, Word, etc. (pas de compression)
 */
class Document extends Fichier
{
    protected function getTypeFichier(): string { return 'document'; }

    public function traiter(string $tmpPath): bool
    {
        return move_uploaded_file($tmpPath, $this->chemin) || copy($tmpPath, $this->chemin);
    }

    public static function depuisUpload(array $fichierPost, int $userId): ?self
    {
        $types = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4',
        ];
        $valid = self::valider($fichierPost, $types);
        if (!$valid['ok']) return null;

        $ext = match(true) {
            str_contains($valid['mime'], 'pdf')   => 'pdf',
            str_contains($valid['mime'], 'msword') => 'doc',
            str_contains($valid['mime'], 'wordprocessingml') => 'docx',
            str_contains($valid['mime'], 'audio') => 'mp3',
            default => 'bin',
        };

        $nomStocke = self::genererNomStocke($ext);
        $chemin    = UPLOAD_DIR . $nomStocke;

        $instance = new self([
            'nom_original'  => basename($fichierPost['name']),
            'nom_stocke'    => $nomStocke,
            'type_mime'     => $valid['mime'],
            'taille_octets' => $fichierPost['size'],
            'chemin'        => $chemin,
            'uploaded_by'   => $userId,
        ]);

        if (!$instance->traiter($fichierPost['tmp_name'])) {
            return null;
        }
        $instance->enregistrer();
        return $instance;
    }
}
