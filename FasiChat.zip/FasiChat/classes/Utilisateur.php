<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe abstraite Utilisateur — Base de la hiérarchie des acteurs
 * Concept POO : classe abstraite, encapsulation
 */
abstract class Utilisateur
{
    protected int $id;
    protected string $matricule;
    protected string $nom;
    protected string $prenom;
    protected ?string $email;
    protected string $motDePasse;
    protected string $role;
    protected ?int $promotionId;
    protected bool $actif;
    protected bool $enLigne;
    protected BaseDeDonnees $db;

    public function __construct(array $donnees)
    {
        $this->id          = (int)($donnees['id'] ?? 0);
        $this->matricule   = $donnees['matricule'] ?? '';
        $this->nom         = $donnees['nom'] ?? '';
        $this->prenom      = $donnees['prenom'] ?? '';
        $this->email       = $donnees['email'] ?? null;
        $this->motDePasse  = $donnees['mot_de_passe'] ?? '';
        $this->role        = $donnees['role'] ?? '';
        $this->promotionId = isset($donnees['promotion_id']) ? (int)$donnees['promotion_id'] : null;
        $this->actif       = (bool)($donnees['actif'] ?? true);
        $this->enLigne     = (bool)($donnees['en_ligne'] ?? false);
        $this->db          = BaseDeDonnees::getInstance();
    }

    // ---- Méthode abstraite (polymorphisme) ----

    /**
     * Retourner le dashboard associé au rôle de l'utilisateur
     */
    abstract public function getDashboard(): string;

    // ---- Méthodes communes ----

    /**
     * Authentifier un utilisateur par matricule + mot de passe
     * Retourne l'utilisateur ou null si échec
     */
    public static function authentifier(string $matricule, string $motDePasse): ?array
    {
        $db   = BaseDeDonnees::getInstance();
        $stmt = $db->executer(
            'SELECT * FROM utilisateurs WHERE matricule = :matricule AND actif = 1 LIMIT 1',
            [':matricule' => $matricule]
        );
        $utilisateur = $stmt->fetch();

        if (!$utilisateur) {
            return null;
        }

        if (!password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
            return null;
        }

        // Marquer en ligne
        $db->executer(
            'UPDATE utilisateurs SET en_ligne = 1 WHERE id = :id',
            [':id' => $utilisateur['id']]
        );

        return $utilisateur;
    }

    /**
     * Hacher un mot de passe de manière sécurisée
     */
    public static function hacherMotDePasse(string $motDePasse): string
    {
        return password_hash($motDePasse, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Obtenir un utilisateur par son ID
     */
    public static function trouverParId(int $id): ?array
    {
        $db   = BaseDeDonnees::getInstance();
        $stmt = $db->executer(
            'SELECT u.*, p.nom AS promotion_nom FROM utilisateurs u
             LEFT JOIN promotions p ON p.id = u.promotion_id
             WHERE u.id = :id LIMIT 1',
            [':id' => $id]
        );
        return $stmt->fetch() ?: null;
    }

    /**
     * Lister tous les utilisateurs (avec filtre optionnel par rôle)
     */
    public static function listerTous(?string $role = null): array
    {
        $db  = BaseDeDonnees::getInstance();
        $sql = 'SELECT u.*, p.nom AS promotion_nom
                FROM utilisateurs u
                LEFT JOIN promotions p ON p.id = u.promotion_id';
        $params = [];
        if ($role !== null) {
            $sql   .= ' WHERE u.role = :role';
            $params[':role'] = $role;
        }
        $sql .= ' ORDER BY u.nom, u.prenom';
        return $db->executer($sql, $params)->fetchAll();
    }

    /**
     * Marquer l'utilisateur comme hors-ligne
     */
    public function seDeconnecter(): void
    {
        $this->db->executer(
            'UPDATE utilisateurs SET en_ligne = 0 WHERE id = :id',
            [':id' => $this->id]
        );
        $this->enLigne = false;
    }

    /**
     * Retourner les initiales de l'utilisateur (pour l'avatar)
     */
    public function getInitiales(): string
    {
        return mb_strtoupper(
            mb_substr($this->prenom, 0, 1) . mb_substr($this->nom, 0, 1)
        );
    }

    /**
     * Retourner le nom complet
     */
    public function getNomComplet(): string
    {
        return $this->prenom . ' ' . $this->nom;
    }

    // ---- Accesseurs ----
    public function getId(): int         { return $this->id; }
    public function getMatricule(): string { return $this->matricule; }
    public function getNom(): string     { return $this->nom; }
    public function getPrenom(): string  { return $this->prenom; }
    public function getEmail(): ?string  { return $this->email; }
    public function getRole(): string    { return $this->role; }
    public function estActif(): bool     { return $this->actif; }
    public function estEnLigne(): bool   { return $this->enLigne; }
    public function getPromotionId(): ?int { return $this->promotionId; }
}
