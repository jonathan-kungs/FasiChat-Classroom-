<?php
require_once __DIR__ . '/Utilisateur.php';

/**
 * Classe Etudiant — Acteur pédagogique de base
 * Peut : envoyer des messages texte/vocaux/fichiers, communiquer
 *         en privé avec d'autres étudiants, en public avec enseignants.
 */
class Etudiant extends Utilisateur
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_etudiant.php';
    }

    /**
     * Obtenir les cours dans lesquels l'étudiant est inscrit
     */
    public function getMesCours(): array
    {
        $stmt = $this->db->executer(
            'SELECT c.*, u.nom AS enseignant_nom, u.prenom AS enseignant_prenom
             FROM cours c
             JOIN inscriptions_cours ic ON ic.cours_id = c.id
             JOIN utilisateurs u ON u.id = c.enseignant_id
             WHERE ic.etudiant_id = :id AND c.actif = 1
             ORDER BY c.nom',
            [':id' => $this->id]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les messages d'un cours (messages publics)
     */
    public function getMessagesCours(int $coursId): array
    {
        $stmt = $this->db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role, u.matricule
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.cours_id = :coursId AND m.type = "cours"
             ORDER BY m.created_at ASC',
            [':coursId' => $coursId]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les messages privés avec un autre étudiant
     */
    public function getMessagesPrives(int $interlocuteurId): array
    {
        $stmt = $this->db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.type = "prive"
               AND (
                 (m.expediteur_id = :moi1 AND m.destinataire_id = :lui1)
                 OR
                 (m.expediteur_id = :lui2 AND m.destinataire_id = :moi2)
               )
             ORDER BY m.created_at ASC',
            [':moi1' => $this->id, ':lui1' => $interlocuteurId,
             ':moi2' => $interlocuteurId, ':lui2' => $this->id]  // NOTE: corrected
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les conversations privées de l'étudiant
     */
    public function getMesConversations(): array
    {
        $stmt = $this->db->executer(
            'SELECT DISTINCT
               CASE WHEN m.expediteur_id = :id THEN m.destinataire_id ELSE m.expediteur_id END AS interlocuteur_id,
               u.nom, u.prenom, u.role, u.en_ligne,
               (SELECT contenu FROM messages m2 WHERE m2.type = "prive"
                AND ((m2.expediteur_id = :id2 AND m2.destinataire_id = u.id)
                     OR (m2.expediteur_id = u.id AND m2.destinataire_id = :id3))
                ORDER BY m2.created_at DESC LIMIT 1) AS dernier_msg,
               (SELECT COUNT(*) FROM messages m3 WHERE m3.type = "prive"
                AND m3.destinataire_id = :id4 AND m3.expediteur_id = u.id AND m3.lu = 0) AS non_lus
             FROM messages m
             JOIN utilisateurs u ON u.id = (CASE WHEN m.expediteur_id = :id5 THEN m.destinataire_id ELSE m.expediteur_id END)
             WHERE m.type = "prive"
               AND (m.expediteur_id = :id6 OR m.destinataire_id = :id7)
               AND u.role = "etudiant"
             ORDER BY non_lus DESC, u.nom',
            [':id'=>$this->id, ':id2'=>$this->id, ':id3'=>$this->id,
             ':id4'=>$this->id, ':id5'=>$this->id, ':id6'=>$this->id, ':id7'=>$this->id]
        );
        return $stmt->fetchAll();
    }
}
