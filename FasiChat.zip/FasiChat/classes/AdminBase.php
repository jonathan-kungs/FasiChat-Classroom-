<?php
require_once __DIR__ . '/Utilisateur.php';

/**
 * Interface Convocable — Contrat partagé entre Doyen et ViceDoyen
 * Concept POO : interface + polymorphisme
 */
interface Convocable
{
    public function convoquer(
        string $objet,
        string $dateReunion,
        string $heureReunion,
        string $lieu,
        string $message
    ): bool;
}

/**
 * Classe abstraite AdminBase — Base des acteurs administratifs avec droit de convocation
 * Concept POO : classe abstraite + interface + héritage
 */
abstract class AdminBase extends Utilisateur implements Convocable
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    /**
     * Convoquer une réunion collective pour tous les enseignants et assistants
     * Méthode partagée sans duplication (réponse au piste de réflexion POO du TP)
     */
    public function convoquer(
        string $objet,
        string $dateReunion,
        string $heureReunion,
        string $lieu,
        string $message = ''
    ): bool {
        if (empty(trim($objet)) || empty($dateReunion) || empty($heureReunion) || empty($lieu)) {
            return false;
        }

        // Créer la convocation
        $this->db->executer(
            'INSERT INTO convocations (expediteur_id, objet, date_reunion, heure_reunion, lieu, message)
             VALUES (:exp, :objet, :date, :heure, :lieu, :msg)',
            [
                ':exp'   => $this->id,
                ':objet' => $objet,
                ':date'  => $dateReunion,
                ':heure' => $heureReunion,
                ':lieu'  => $lieu,
                ':msg'   => $message,
            ]
        );
        $convocationId = (int)$this->db->dernierInsertId();

        // Récupérer tous les enseignants et assistants
        $destinataires = $this->db->executer(
            'SELECT id FROM utilisateurs WHERE role IN ("enseignant", "assistant") AND actif = 1'
        )->fetchAll();

        // Créer une entrée pour chaque destinataire
        foreach ($destinataires as $dest) {
            $this->db->executer(
                'INSERT IGNORE INTO destinataires_convocations (convocation_id, destinataire_id)
                 VALUES (:cid, :did)',
                [':cid' => $convocationId, ':did' => $dest['id']]
            );
        }

        return true;
    }

    /**
     * Obtenir les convocations envoyées par cet administrateur
     */
    public function getConvocationsEnvoyees(): array
    {
        $stmt = $this->db->executer(
            'SELECT c.*,
               (SELECT COUNT(*) FROM destinataires_convocations dc WHERE dc.convocation_id = c.id) AS nb_destinataires,
               (SELECT COUNT(*) FROM destinataires_convocations dc WHERE dc.convocation_id = c.id AND dc.lu = 1) AS nb_lus
             FROM convocations c
             WHERE c.expediteur_id = :id
             ORDER BY c.created_at DESC',
            [':id' => $this->id]
        );
        return $stmt->fetchAll();
    }

    /**
     * Envoyer un message confidentiel au Doyen ou Vice-Doyen
     */
    public function envoyerMessageConfidentiel(int $destinataireId, string $contenu): bool
    {
        // Vérifier que le destinataire est bien Doyen ou ViceDoyen
        $stmt = $this->db->executer(
            'SELECT id FROM utilisateurs WHERE id = :id AND role IN ("doyen","vicedoyen")',
            [':id' => $destinataireId]
        );
        if (!$stmt->fetch()) {
            return false;
        }

        $this->db->executer(
            'INSERT INTO messages (expediteur_id, destinataire_id, type, contenu, type_media)
             VALUES (:exp, :dest, "confidentiel", :contenu, "texte")',
            [':exp' => $this->id, ':dest' => $destinataireId, ':contenu' => $contenu]
        );
        return true;
    }

    /**
     * Obtenir les messages confidentiels échangés avec l'autre admin
     */
    public function getMessagesConfidentiels(int $interlocuteurId): array
    {
        $stmt = $this->db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.type = "confidentiel"
               AND ((m.expediteur_id = :moi AND m.destinataire_id = :lui)
                    OR (m.expediteur_id = :lui2 AND m.destinataire_id = :moi2))
             ORDER BY m.created_at ASC',
            [':moi' => $this->id, ':lui' => $interlocuteurId,
             ':moi2' => $this->id, ':lui2' => $interlocuteurId]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les statistiques globales de la faculté
     */
    public function getStatistiques(): array
    {
        $db = $this->db;
        return [
            'etudiants'     => (int)$db->executer('SELECT COUNT(*) FROM utilisateurs WHERE role = "etudiant" AND actif = 1')->fetchColumn(),
            'enseignants'   => (int)$db->executer('SELECT COUNT(*) FROM utilisateurs WHERE role = "enseignant" AND actif = 1')->fetchColumn(),
            'assistants'    => (int)$db->executer('SELECT COUNT(*) FROM utilisateurs WHERE role = "assistant" AND actif = 1')->fetchColumn(),
            'cours'         => (int)$db->executer('SELECT COUNT(*) FROM cours WHERE actif = 1')->fetchColumn(),
            'convocations'  => (int)$db->executer('SELECT COUNT(*) FROM convocations WHERE expediteur_id = :id', [':id' => $this->id])->fetchColumn(),
        ];
    }

    /**
     * Lister tous les utilisateurs avec détails
     */
    public function getTousUtilisateurs(): array
    {
        return $this->db->executer(
            'SELECT u.*, p.nom AS promotion_nom
             FROM utilisateurs u
             LEFT JOIN promotions p ON p.id = u.promotion_id
             ORDER BY u.role, u.nom'
        )->fetchAll();
    }
}
