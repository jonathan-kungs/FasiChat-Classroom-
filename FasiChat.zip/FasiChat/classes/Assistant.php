<?php
require_once __DIR__ . '/Enseignant.php';

/**
 * Classe Assistant — Partage les droits de l'Enseignant
 * Hérite de Enseignant (réutilisation de code, héritage POO).
 * Peut également visualiser les étudiants et publier sur le mur.
 */
class Assistant extends Enseignant
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_enseignant.php'; // Partage le même dashboard
    }

    /**
     * Les assistants peuvent voir tous les cours (pas seulement les leurs)
     */
    public function getCoursDeLaFaculte(): array
    {
        $stmt = $this->db->executer(
            'SELECT c.*, p.nom AS promo_nom,
               u.nom AS enseignant_nom, u.prenom AS enseignant_prenom,
               (SELECT COUNT(*) FROM inscriptions_cours ic WHERE ic.cours_id = c.id) AS nb_etudiants
             FROM cours c
             LEFT JOIN promotions p ON p.id = c.promotion_id
             JOIN utilisateurs u ON u.id = c.enseignant_id
             WHERE c.actif = 1
             ORDER BY c.nom'
        );
        return $stmt->fetchAll();
    }

    /**
     * Un assistant peut publier sur le mur de n'importe quel cours
     */
    public function publierMurCours(int $coursId, string $contenu, ?int $fichierId = null): bool
    {
        // Vérifier que le cours existe
        $stmt = $this->db->executer('SELECT id FROM cours WHERE id = :cid', [':cid' => $coursId]);
        if (!$stmt->fetch()) {
            return false;
        }

        $this->db->executer(
            'INSERT INTO mur_pedagogique (auteur_id, cours_id, contenu, fichier_id)
             VALUES (:auteur, :cours, :contenu, :fichier)',
            [':auteur' => $this->id, ':cours' => $coursId,
             ':contenu' => $contenu, ':fichier' => $fichierId]
        );
        return true;
    }
}
