<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe Valve — Tableau d'affichage institutionnel
 * Visible par tous, modifiable uniquement par l'Apparitaire.
 * Concept POO : encapsulation, contrôle d'accès par rôle
 */
class Valve
{
    private BaseDeDonnees $db;

    public function __construct()
    {
        $this->db = BaseDeDonnees::getInstance();
    }

    /**
     * Obtenir toutes les annonces actives (non expirées)
     */
    public function getAnnonces(?string $categorie = null): array
    {
        $sql = 'SELECT a.*, u.nom AS auteur_nom, u.prenom AS auteur_prenom, u.role AS auteur_role,
                  f.nom_original AS fichier_nom, f.chemin AS fichier_chemin, f.taille_octets AS fichier_taille
                FROM annonces_valve a
                JOIN utilisateurs u ON u.id = a.auteur_id
                LEFT JOIN fichiers f ON f.id = a.fichier_id
                WHERE (a.date_expiration IS NULL OR a.date_expiration >= CURDATE())';
        $params = [];

        if ($categorie !== null) {
            $sql    .= ' AND a.categorie = :cat';
            $params[':cat'] = $categorie;
        }

        $sql .= ' ORDER BY
                    CASE a.categorie WHEN "urgent" THEN 0 ELSE 1 END,
                    a.created_at DESC';

        return $this->db->executer($sql, $params)->fetchAll();
    }

    /**
     * Obtenir une annonce par son ID
     */
    public function getAnnonce(int $id): ?array
    {
        $stmt = $this->db->executer(
            'SELECT a.*, u.nom AS auteur_nom, u.prenom AS auteur_prenom
             FROM annonces_valve a
             JOIN utilisateurs u ON u.id = a.auteur_id
             WHERE a.id = :id',
            [':id' => $id]
        );
        return $stmt->fetch() ?: null;
    }

    /**
     * Incrémenter le compteur de vues d'une annonce
     */
    public function incrementerVues(int $annonceId): void
    {
        $this->db->executer(
            'UPDATE annonces_valve SET vues = vues + 1 WHERE id = :id',
            [':id' => $annonceId]
        );
    }

    /**
     * Compter les annonces par catégorie (pour la sidebar)
     */
    public function getCompteurs(): array
    {
        $rows = $this->db->executer(
            'SELECT categorie, COUNT(*) AS total
             FROM annonces_valve
             WHERE (date_expiration IS NULL OR date_expiration >= CURDATE())
             GROUP BY categorie'
        )->fetchAll();

        $result = ['urgent'=>0, 'convocation'=>0, 'information'=>0, 'academique'=>0, 'total'=>0];
        foreach ($rows as $row) {
            $result[$row['categorie']] = (int)$row['total'];
            $result['total'] += (int)$row['total'];
        }
        return $result;
    }
}

// ============================================================

/**
 * Classe AnnonceValve — Représentation d'une annonce du Valve
 */
class AnnonceValve
{
    private ?int $id;
    private int $auteurId;
    private string $titre;
    private string $contenu;
    private string $categorie;
    private ?string $dateExpiration;
    private ?int $fichierId;
    private int $vues;

    public function __construct(array $donnees = [])
    {
        $this->id             = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->auteurId       = (int)($donnees['auteur_id'] ?? 0);
        $this->titre          = $donnees['titre'] ?? '';
        $this->contenu        = $donnees['contenu'] ?? '';
        $this->categorie      = $donnees['categorie'] ?? 'information';
        $this->dateExpiration = $donnees['date_expiration'] ?? null;
        $this->fichierId      = isset($donnees['fichier_id']) ? (int)$donnees['fichier_id'] : null;
        $this->vues           = (int)($donnees['vues'] ?? 0);
    }

    public function getId(): ?int          { return $this->id; }
    public function getTitre(): string     { return $this->titre; }
    public function getContenu(): string   { return $this->contenu; }
    public function getCategorie(): string { return $this->categorie; }
    public function getVues(): int         { return $this->vues; }

    /**
     * Retourner l'icône associée à la catégorie
     */
    public function getIconeCategorie(): string
    {
        return match($this->categorie) {
            'urgent'      => '🚨',
            'convocation' => '📅',
            'information' => '📢',
            'academique'  => '🎓',
            default       => '📋',
        };
    }
}
