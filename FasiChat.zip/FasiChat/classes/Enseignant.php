<?php
require_once __DIR__ . '/Utilisateur.php';

/**
 * Classe Enseignant — Acteur pédagogique responsable de cours
 * Peut : voir la liste de ses étudiants, publier sur le mur pédagogique,
 *         échanger en privé avec collègues, recevoir convocations.
 */
class Enseignant extends Utilisateur
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_enseignant.php';
    }

    /**
     * Obtenir les cours dont l'enseignant est responsable
     */
    public function getMesCours(): array
    {
        $stmt = $this->db->executer(
            'SELECT c.*, p.nom AS promo_nom,
               (SELECT COUNT(*) FROM inscriptions_cours ic WHERE ic.cours_id = c.id) AS nb_etudiants
             FROM cours c
             LEFT JOIN promotions p ON p.id = c.promotion_id
             WHERE c.enseignant_id = :id AND c.actif = 1
             ORDER BY c.nom',
            [':id' => $this->id]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les étudiants inscrits à un cours de l'enseignant
     */
    public function getEtudiantsCours(int $coursId): array
    {
        $stmt = $this->db->executer(
            'SELECT u.*, p.nom AS promotion_nom
             FROM utilisateurs u
             JOIN inscriptions_cours ic ON ic.etudiant_id = u.id
             LEFT JOIN promotions p ON p.id = u.promotion_id
             WHERE ic.cours_id = :coursId AND u.role = "etudiant"
             ORDER BY u.nom, u.prenom',
            [':coursId' => $coursId]
        );
        return $stmt->fetchAll();
    }

    /**
     * Publier sur le mur pédagogique
     */
    public function publierMur(int $coursId, string $contenu, ?int $fichierId = null): bool
    {
        // Vérifier que l'enseignant est bien responsable du cours
        $stmt = $this->db->executer(
            'SELECT id FROM cours WHERE id = :cid AND enseignant_id = :uid',
            [':cid' => $coursId, ':uid' => $this->id]
        );
        if (!$stmt->fetch()) {
            return false; // Pas autorisé
        }

        $this->db->executer(
            'INSERT INTO mur_pedagogique (auteur_id, cours_id, contenu, fichier_id)
             VALUES (:auteur, :cours, :contenu, :fichier)',
            [':auteur' => $this->id, ':cours' => $coursId,
             ':contenu' => $contenu, ':fichier' => $fichierId]
        );
        return true;
    }

    /**
     * Obtenir les posts du mur pédagogique d'un cours
     */
    public function getMurPedagogique(int $coursId): array
    {
        $stmt = $this->db->executer(
            'SELECT mp.*, u.nom, u.prenom, u.role
             FROM mur_pedagogique mp
             JOIN utilisateurs u ON u.id = mp.auteur_id
             WHERE mp.cours_id = :coursId
             ORDER BY mp.created_at DESC',
            [':coursId' => $coursId]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les convocations reçues
     */
    public function getConvocationsRecues(): array
    {
        $stmt = $this->db->executer(
            'SELECT c.*, dc.lu, dc.lu_le,
               u.nom AS expediteur_nom, u.prenom AS expediteur_prenom, u.role AS expediteur_role
             FROM convocations c
             JOIN destinataires_convocations dc ON dc.convocation_id = c.id
             JOIN utilisateurs u ON u.id = c.expediteur_id
             WHERE dc.destinataire_id = :id
             ORDER BY c.created_at DESC',
            [':id' => $this->id]
        );
        return $stmt->fetchAll();
    }

    /**
     * Obtenir les messages privés avec un collègue
     */
    public function getMessagesPrives(int $interlocuteurId): array
    {
        $stmt = $this->db->executer(
            'SELECT m.*, u.nom, u.prenom, u.role
             FROM messages m
             JOIN utilisateurs u ON u.id = m.expediteur_id
             WHERE m.type = "prive"
               AND ((m.expediteur_id = :moi AND m.destinataire_id = :lui)
                    OR (m.expediteur_id = :lui2 AND m.destinataire_id = :moi2))
             ORDER BY m.created_at ASC',
            [':moi' => $this->id, ':lui' => $interlocuteurId,
             ':moi2' => $this->id, ':lui2' => $interlocuteurId]
        );
        return $stmt->fetchAll();
    }
}
