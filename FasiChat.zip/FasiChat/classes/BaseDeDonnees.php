<?php
/**
 * Classe BaseDeDonnees — Singleton PDO
 * Gère la connexion unique à la base de données via PDO.
 */
class BaseDeDonnees
{
    private static ?BaseDeDonnees $instance = null;
    private PDO $connexion;

    /**
     * Constructeur privé (Singleton)
     */
    private function __construct()
    {
        require_once __DIR__ . '/../config/config.php';

        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHARSET
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $this->connexion = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Ne jamais afficher les détails de connexion en production
            throw new RuntimeException('Erreur de connexion à la base de données. Vérifiez config/config.php');
        }
    }

    /**
     * Obtenir l'instance unique (Singleton)
     */
    public static function getInstance(): BaseDeDonnees
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Obtenir la connexion PDO
     */
    public function getConnexion(): PDO
    {
        return $this->connexion;
    }

    /**
     * Préparer et exécuter une requête avec paramètres liés
     *
     * @param string $sql   La requête SQL avec placeholders
     * @param array  $params Les paramètres à lier
     */
    public function executer(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->connexion->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Obtenir l'id du dernier enregistrement inséré
     */
    public function dernierInsertId(): string
    {
        return $this->connexion->lastInsertId();
    }

    // Empêcher le clonage et la désérialisation (Singleton strict)
    private function __clone() {}
    public function __wakeup() { throw new RuntimeException('Cannot unserialize singleton.'); }
}
