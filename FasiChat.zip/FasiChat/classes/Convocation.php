<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe Convocation — Message administratif formel de réunion
 * Concept POO : classe distincte avec ses propres attributs et comportements
 */
class Convocation
{
    private ?int $id;
    private int $expediteurId;
    private string $objet;
    private string $dateReunion;
    private string $heureReunion;
    private string $lieu;
    private string $message;
    private string $createdAt;
    private BaseDeDonnees $db;

    public function __construct(array $donnees = [])
    {
        $this->id           = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->expediteurId = (int)($donnees['expediteur_id'] ?? 0);
        $this->objet        = $donnees['objet'] ?? '';
        $this->dateReunion  = $donnees['date_reunion'] ?? '';
        $this->heureReunion = $donnees['heure_reunion'] ?? '';
        $this->lieu         = $donnees['lieu'] ?? '';
        $this->message      = $donnees['message'] ?? '';
        $this->createdAt    = $donnees['created_at'] ?? date('Y-m-d H:i:s');
        $this->db           = BaseDeDonnees::getInstance();
    }

    /**
     * Obtenir toutes les convocations (pour un destinataire)
     */
    public static function getParDestinataire(int $destinataireId): array
    {
        $db   = BaseDeDonnees::getInstance();
        $stmt = $db->executer(
            'SELECT c.*, dc.lu, dc.lu_le,
               u.nom AS exp_nom, u.prenom AS exp_prenom, u.role AS exp_role
             FROM convocations c
             JOIN destinataires_convocations dc ON dc.convocation_id = c.id
             JOIN utilisateurs u ON u.id = c.expediteur_id
             WHERE dc.destinataire_id = :id
             ORDER BY c.created_at DESC',
            [':id' => $destinataireId]
        );
        return $stmt->fetchAll();
    }

    /**
     * Marquer une convocation comme lue
     */
    public static function marquerLue(int $convocationId, int $destinataireId): void
    {
        $db = BaseDeDonnees::getInstance();
        $db->executer(
            'UPDATE destinataires_convocations
             SET lu = 1, lu_le = NOW()
             WHERE convocation_id = :cid AND destinataire_id = :did AND lu = 0',
            [':cid' => $convocationId, ':did' => $destinataireId]
        );
    }

    /**
     * Compter les convocations non lues pour un utilisateur
     */
    public static function compterNonLues(int $destinataireId): int
    {
        $db = BaseDeDonnees::getInstance();
        return (int)$db->executer(
            'SELECT COUNT(*) FROM destinataires_convocations
             WHERE destinataire_id = :id AND lu = 0',
            [':id' => $destinataireId]
        )->fetchColumn();
    }

    // Accesseurs
    public function getId(): ?int          { return $this->id; }
    public function getObjet(): string     { return $this->objet; }
    public function getDateReunion(): string { return $this->dateReunion; }
    public function getHeureReunion(): string { return $this->heureReunion; }
    public function getLieu(): string      { return $this->lieu; }
    public function getMessage(): string   { return $this->message; }
    public function getCreatedAt(): string { return $this->createdAt; }
}
