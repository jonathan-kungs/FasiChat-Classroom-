<?php
require_once __DIR__ . '/Utilisateur.php';

/**
 * Classe Apparitaire — Gestionnaire exclusif du Valve
 * Ne participe PAS aux conversations pédagogiques ni aux réunions.
 * Seul habilité à publier, modifier et supprimer des annonces sur le Valve.
 */
class Apparitaire extends Utilisateur
{
    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
    }

    public function getDashboard(): string
    {
        return 'dashboard_apparitaire.php';
    }

    /**
     * Publier une annonce sur le Valve
     */
    public function publierAnnonce(
        string $titre,
        string $contenu,
        string $categorie = 'information',
        ?string $dateExpiration = null,
        ?int $fichierId = null
    ): bool {
        $categoriesValides = ['urgent', 'convocation', 'information', 'academique'];
        if (!in_array($categorie, $categoriesValides, true)) {
            $categorie = 'information';
        }

        if (empty(trim($titre)) || empty(trim($contenu))) {
            return false;
        }

        $this->db->executer(
            'INSERT INTO annonces_valve (auteur_id, titre, contenu, categorie, date_expiration, fichier_id)
             VALUES (:auteur, :titre, :contenu, :categorie, :expiration, :fichier)',
            [
                ':auteur'     => $this->id,
                ':titre'      => $titre,
                ':contenu'    => $contenu,
                ':categorie'  => $categorie,
                ':expiration' => $dateExpiration ?: null,
                ':fichier'    => $fichierId,
            ]
        );
        return true;
    }

    /**
     * Modifier une annonce existante du Valve
     */
    public function modifierAnnonce(
        int $annonceId,
        string $titre,
        string $contenu,
        string $categorie,
        ?string $dateExpiration = null
    ): bool {
        // Vérifier que l'annonce existe
        $stmt = $this->db->executer(
            'SELECT id FROM annonces_valve WHERE id = :id',
            [':id' => $annonceId]
        );
        if (!$stmt->fetch()) {
            return false;
        }

        $this->db->executer(
            'UPDATE annonces_valve
             SET titre = :titre, contenu = :contenu, categorie = :categorie, date_expiration = :exp
             WHERE id = :id',
            [
                ':titre'    => $titre,
                ':contenu'  => $contenu,
                ':categorie'=> $categorie,
                ':exp'      => $dateExpiration ?: null,
                ':id'       => $annonceId,
            ]
        );
        return true;
    }

    /**
     * Supprimer une annonce du Valve
     */
    public function supprimerAnnonce(int $annonceId): bool
    {
        $stmt = $this->db->executer(
            'SELECT id FROM annonces_valve WHERE id = :id',
            [':id' => $annonceId]
        );
        if (!$stmt->fetch()) {
            return false;
        }
        $this->db->executer('DELETE FROM annonces_valve WHERE id = :id', [':id' => $annonceId]);
        return true;
    }

    /**
     * Obtenir les statistiques du Valve
     */
    public function getStatistiquesValve(): array
    {
        $db = $this->db;
        return [
            'total'        => (int)$db->executer('SELECT COUNT(*) FROM annonces_valve')->fetchColumn(),
            'urgent'       => (int)$db->executer('SELECT COUNT(*) FROM annonces_valve WHERE categorie = "urgent"')->fetchColumn(),
            'convocation'  => (int)$db->executer('SELECT COUNT(*) FROM annonces_valve WHERE categorie = "convocation"')->fetchColumn(),
            'information'  => (int)$db->executer('SELECT COUNT(*) FROM annonces_valve WHERE categorie = "information"')->fetchColumn(),
            'academique'   => (int)$db->executer('SELECT COUNT(*) FROM annonces_valve WHERE categorie = "academique"')->fetchColumn(),
            'vues_total'   => (int)$db->executer('SELECT COALESCE(SUM(vues),0) FROM annonces_valve')->fetchColumn(),
        ];
    }
}
