<?php
/**
 * Classe Session — Gestion sécurisée des sessions PHP
 */
class Session
{
    private static bool $demarree = false;

    /**
     * Démarrer la session de manière sécurisée
     */
    public static function demarrer(): void
    {
        if (self::$demarree || session_status() === PHP_SESSION_ACTIVE) {
            self::$demarree = true;
            return;
        }

        if (!defined('SESSION_LIFETIME')) {
            require_once __DIR__ . '/../config/config.php';
        }

        session_name(SESSION_NAME);

        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'domain'   => '',
            'secure'   => false,     // true si HTTPS
            'httponly' => true,      // protection XSS
            'samesite' => 'Strict',
        ]);

        session_start();
        self::$demarree = true;

        // Régénération de l'ID de session toutes les 30 minutes (protection fixation)
        if (!isset($_SESSION['dernier_renouvellement'])) {
            $_SESSION['dernier_renouvellement'] = time();
        } elseif (time() - $_SESSION['dernier_renouvellement'] > 1800) {
            session_regenerate_id(true);
            $_SESSION['dernier_renouvellement'] = time();
        }
    }

    /**
     * Vérifier si un utilisateur est connecté
     */
    public static function estConnecte(): bool
    {
        self::demarrer();
        return isset($_SESSION['utilisateur_id']) && !empty($_SESSION['utilisateur_id']);
    }

    /**
     * Connecter un utilisateur (enregistrement en session)
     */
    public static function connecter(array $utilisateur): void
    {
        self::demarrer();
        session_regenerate_id(true);
        $_SESSION['utilisateur_id']    = $utilisateur['id'];
        $_SESSION['utilisateur_role']  = $utilisateur['role'];
        $_SESSION['utilisateur_nom']   = $utilisateur['nom'];
        $_SESSION['utilisateur_prenom'] = $utilisateur['prenom'];
        $_SESSION['matricule']         = $utilisateur['matricule'];
        $_SESSION['dernier_renouvellement'] = time();
    }

    /**
     * Déconnecter l'utilisateur
     */
    public static function deconnecter(): void
    {
        self::demarrer();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
        self::$demarree = false;
    }

    /**
     * Obtenir la valeur d'une variable de session
     */
    public static function obtenir(string $cle, mixed $defaut = null): mixed
    {
        self::demarrer();
        return $_SESSION[$cle] ?? $defaut;
    }

    /**
     * Définir une variable de session
     */
    public static function definir(string $cle, mixed $valeur): void
    {
        self::demarrer();
        $_SESSION[$cle] = $valeur;
    }

    /**
     * Supprimer une variable de session
     */
    public static function supprimer(string $cle): void
    {
        self::demarrer();
        unset($_SESSION[$cle]);
    }

    /**
     * Exiger que l'utilisateur soit connecté, sinon rediriger
     */
    public static function exigerConnexion(): void
    {
        if (!self::estConnecte()) {
            header('Location: login.php');
            exit;
        }
    }

    /**
     * Exiger un rôle précis (ou liste de rôles)
     */
    public static function exigerRole(array $rolesAutorises): void
    {
        self::exigerConnexion();
        $roleActuel = self::obtenir('utilisateur_role');
        if (!in_array($roleActuel, $rolesAutorises, true)) {
            http_response_code(403);
            echo '<h1>Accès refusé</h1><p>Vous n\'avez pas les droits nécessaires.</p>';
            exit;
        }
    }

    /**
     * Obtenir l'ID de l'utilisateur connecté
     */
    public static function getId(): ?int
    {
        $id = self::obtenir('utilisateur_id');
        return $id !== null ? (int)$id : null;
    }

    /**
     * Obtenir le rôle de l'utilisateur connecté
     */
    public static function getRole(): ?string
    {
        return self::obtenir('utilisateur_role');
    }
}
