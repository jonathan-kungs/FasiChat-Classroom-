<?php
require_once __DIR__ . '/BaseDeDonnees.php';

/**
 * Classe abstraite Message — Base de la hiérarchie des messages
 * Concept POO : abstraction, encapsulation, polymorphisme
 */
abstract class Message
{
    protected ?int $id;
    protected int $expediteurId;
    protected string $contenu;
    protected string $typeMedia;
    protected ?int $fichierId;
    protected string $type;
    protected bool $lu;
    protected string $createdAt;
    protected BaseDeDonnees $db;

    public function __construct(array $donnees = [])
    {
        $this->id           = isset($donnees['id']) ? (int)$donnees['id'] : null;
        $this->expediteurId = (int)($donnees['expediteur_id'] ?? 0);
        $this->contenu      = $donnees['contenu'] ?? '';
        $this->typeMedia    = $donnees['type_media'] ?? 'texte';
        $this->fichierId    = isset($donnees['fichier_id']) ? (int)$donnees['fichier_id'] : null;
        $this->type         = $donnees['type'] ?? '';
        $this->lu           = (bool)($donnees['lu'] ?? false);
        $this->createdAt    = $donnees['created_at'] ?? date('Y-m-d H:i:s');
        $this->db           = BaseDeDonnees::getInstance();
    }

    /**
     * Enregistrer le message en base de données (méthode abstraite)
     */
    abstract public function envoyer(): bool;

    /**
     * Marquer le message comme lu
     */
    public function marquerLu(): void
    {
        if ($this->id) {
            $this->db->executer('UPDATE messages SET lu = 1 WHERE id = :id', [':id' => $this->id]);
            $this->lu = true;
        }
    }

    /**
     * Supprimer le message
     */
    public function supprimer(): bool
    {
        if (!$this->id) return false;
        $this->db->executer('DELETE FROM messages WHERE id = :id', [':id' => $this->id]);
        return true;
    }

    // Accesseurs
    public function getId(): ?int        { return $this->id; }
    public function getContenu(): string { return $this->contenu; }
    public function getType(): string    { return $this->type; }
    public function estLu(): bool        { return $this->lu; }
    public function getCreatedAt(): string { return $this->createdAt; }
}

// ============================================================

/**
 * Classe MessagePrive — Échange privé entre deux utilisateurs du même groupe
 */
class MessagePrive extends Message
{
    private int $destinataireId;

    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
        $this->destinataireId = (int)($donnees['destinataire_id'] ?? 0);
        $this->type = 'prive';
    }

    public function envoyer(): bool
    {
        if (empty($this->contenu) && !$this->fichierId) return false;
        $this->db->executer(
            'INSERT INTO messages (expediteur_id, destinataire_id, type, contenu, type_media, fichier_id)
             VALUES (:exp, :dest, "prive", :contenu, :media, :fichier)',
            [
                ':exp'     => $this->expediteurId,
                ':dest'    => $this->destinataireId,
                ':contenu' => $this->contenu,
                ':media'   => $this->typeMedia,
                ':fichier' => $this->fichierId,
            ]
        );
        $this->id = (int)$this->db->dernierInsertId();
        return true;
    }
}

// ============================================================

/**
 * Classe MessagePublic — Message dans un cours (visible par toute la promotion)
 */
class MessagePublic extends Message
{
    private int $coursId;

    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
        $this->coursId = (int)($donnees['cours_id'] ?? 0);
        $this->type = 'cours';
    }

    public function envoyer(): bool
    {
        if (empty($this->contenu) && !$this->fichierId) return false;
        $this->db->executer(
            'INSERT INTO messages (expediteur_id, cours_id, type, contenu, type_media, fichier_id)
             VALUES (:exp, :cours, "cours", :contenu, :media, :fichier)',
            [
                ':exp'     => $this->expediteurId,
                ':cours'   => $this->coursId,
                ':contenu' => $this->contenu,
                ':media'   => $this->typeMedia,
                ':fichier' => $this->fichierId,
            ]
        );
        $this->id = (int)$this->db->dernierInsertId();
        return true;
    }
}

// ============================================================

/**
 * Classe MessageConfidentiel — Échange privé entre Doyen et Vice-Doyen
 * Non visible par les autres utilisateurs
 */
class MessageConfidentiel extends Message
{
    private int $destinataireId;

    public function __construct(array $donnees)
    {
        parent::__construct($donnees);
        $this->destinataireId = (int)($donnees['destinataire_id'] ?? 0);
        $this->type = 'confidentiel';
    }

    public function envoyer(): bool
    {
        if (empty($this->contenu)) return false;
        $this->db->executer(
            'INSERT INTO messages (expediteur_id, destinataire_id, type, contenu, type_media)
             VALUES (:exp, :dest, "confidentiel", :contenu, "texte")',
            [
                ':exp'     => $this->expediteurId,
                ':dest'    => $this->destinataireId,
                ':contenu' => $this->contenu,
            ]
        );
        $this->id = (int)$this->db->dernierInsertId();
        return true;
    }
}
